import pytest
from unittest.mock import AsyncMock, patch


@pytest.mark.asyncio
async def test_docker_ps():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {
            "stdout": '{"ID": "abc123", "Image": "nginx", "State": "running"}',
            "stderr": "",
            "returncode": 0,
        }
        from rumbod_cli.tools.docker_ import ps
        result = await ps()
        assert len(result) == 1
        assert result[0]["Image"] == "nginx"


@pytest.mark.asyncio
async def test_docker_ps_all():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {
            "stdout": '{"ID": "def456", "Image": "alpine", "State": "exited"}',
            "stderr": "",
            "returncode": 0,
        }
        from rumbod_cli.tools.docker_ import ps
        result = await ps(all=True)
        assert len(result) == 1
        assert result[0]["State"] == "exited"


@pytest.mark.asyncio
async def test_docker_images():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {
            "stdout": '{"ID": "sha256:abc", "Repository": "ubuntu", "Tag": "latest"}',
            "stderr": "",
            "returncode": 0,
        }
        from rumbod_cli.tools.docker_ import images
        result = await images()
        assert len(result) == 1
        assert result[0]["Repository"] == "ubuntu"


@pytest.mark.asyncio
async def test_docker_not_found():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {"error": "Docker not found. Install docker.io or docker-ce."}
        from rumbod_cli.tools.docker_ import ps
        result = await ps()
        assert "error" in result[0]
        assert "Docker not found" in result[0]["error"]


@pytest.mark.asyncio
async def test_docker_logs():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {"stdout": "log line 1\nlog line 2\n", "stderr": "", "returncode": 0}
        from rumbod_cli.tools.docker_ import logs
        result = await logs("my_container", tail=10)
        assert "log line 1" in result


@pytest.mark.asyncio
async def test_docker_info():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {
            "stdout": '{"ServerVersion": "24.0.0", "Containers": 5}',
            "stderr": "",
            "returncode": 0,
        }
        from rumbod_cli.tools.docker_ import info
        result = await info()
        assert result["ServerVersion"] == "24.0.0"


@pytest.mark.asyncio
async def test_docker_stats():
    with patch("rumbod_cli.tools.docker_._docker_cmd", new_callable=AsyncMock) as mock_cmd:
        mock_cmd.return_value = {
            "stdout": '{"Container": "abc", "CPUPerc": "0.5%"}',
            "stderr": "",
            "returncode": 0,
        }
        from rumbod_cli.tools.docker_ import stats
        result = await stats()
        assert len(result["containers"]) == 1
        assert result["containers"][0]["Container"] == "abc"
