import pytest
from unittest.mock import AsyncMock, patch
import os

os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.task_loop import run_task_loop


@pytest.mark.asyncio
async def test_run_task_loop():
    with patch("rumbod_cli.models.get_provider") as mock_get_provider:
        mock_provider = AsyncMock()
        mock_provider.chat.return_value = '[{"step": 1, "tool": "shell", "args": {"cmd": "echo hello"}, "done": true}]'
        mock_get_provider.return_value = mock_provider

        history = await run_task_loop("test task", max_iter=1)
        assert len(history) == 1
        assert history[0]["step"]["tool"] == "shell"