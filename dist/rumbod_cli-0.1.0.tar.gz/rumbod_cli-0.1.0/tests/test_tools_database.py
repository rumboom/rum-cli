import pytest
import sqlite3
import tempfile
from pathlib import Path


@pytest.fixture
def db_path():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        path = Path(f.name)
    conn = sqlite3.connect(str(path))
    conn.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, email TEXT)")
    conn.execute("INSERT INTO users (name, email) VALUES ('Alice', 'alice@test.com')")
    conn.execute("INSERT INTO users (name, email) VALUES ('Bob', 'bob@test.com')")
    conn.commit()
    conn.close()
    yield path
    path.unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_query_sqlite(db_path):
    from rumbod_cli.tools.database import query_sqlite
    result = await query_sqlite(str(db_path), "SELECT * FROM users ORDER BY id")
    assert result["count"] == 2
    assert len(result["rows"]) == 2
    assert result["rows"][0]["name"] == "Alice"


@pytest.mark.asyncio
async def test_query_sqlite_with_params(db_path):
    from rumbod_cli.tools.database import query_sqlite
    result = await query_sqlite(str(db_path), "SELECT * FROM users WHERE name = ?", ["Bob"])
    assert result["count"] == 1
    assert result["rows"][0]["email"] == "bob@test.com"


@pytest.mark.asyncio
async def test_query_sqlite_write(db_path):
    from rumbod_cli.tools.database import query_sqlite
    result = await query_sqlite(str(db_path), "INSERT INTO users (name, email) VALUES (?, ?)", ["Charlie", "charlie@test.com"])
    assert result["ok"] is True
    assert result["changes"] >= 1

    verify = await query_sqlite(str(db_path), "SELECT COUNT(*) as cnt FROM users")
    assert verify["rows"][0]["cnt"] == 3


@pytest.mark.asyncio
async def test_query_sqlite_not_found():
    from rumbod_cli.tools.database import query_sqlite
    result = await query_sqlite("/nonexistent/path/db.sqlite", "SELECT 1")
    assert "error" in result
    assert "not found" in result["error"].lower()


@pytest.mark.asyncio
async def test_list_tables(db_path):
    from rumbod_cli.tools.database import list_tables
    result = await list_tables(str(db_path))
    names = [r["name"] for r in result]
    assert "users" in names


@pytest.mark.asyncio
async def test_table_schema(db_path):
    from rumbod_cli.tools.database import table_schema
    result = await table_schema(str(db_path), "users")
    assert result["table"] == "users"
    col_names = [c["name"] for c in result["columns"]]
    assert "id" in col_names
    assert "name" in col_names
    assert "email" in col_names


@pytest.mark.asyncio
async def test_table_schema_not_found(db_path):
    from rumbod_cli.tools.database import table_schema
    result = await table_schema(str(db_path), "nonexistent")
    assert result["table"] == "nonexistent"
    assert len(result["columns"]) == 0


@pytest.mark.asyncio
async def test_query_sqlite_columns(db_path):
    from rumbod_cli.tools.database import query_sqlite
    result = await query_sqlite(str(db_path), "SELECT * FROM users LIMIT 1")
    assert "columns" in result
    assert "id" in result["columns"]
    assert "name" in result["columns"]
