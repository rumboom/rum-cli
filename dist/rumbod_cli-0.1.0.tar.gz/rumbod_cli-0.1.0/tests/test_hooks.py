import pytest
from pathlib import Path
import tempfile
import os

os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.hooks import load_hooks, Hook, HookEngine


@pytest.fixture
def temp_hook_dir(monkeypatch):
    with tempfile.TemporaryDirectory() as tmpdir:
        hook_dir = Path(tmpdir) / ".rumbod" / "hooks"
        hook_dir.mkdir(parents=True)
        monkeypatch.chdir(tmpdir)
        yield hook_dir


def test_load_hooks(temp_hook_dir):
    hook_file = temp_hook_dir / "test.toml"
    hook_file.write_text("""
[hook]
name = "test-hook"
trigger = { type = "file_change", patterns = ["*.py"] }
command = "echo {file}"
async = true
""")
    hooks = load_hooks()
    assert len(hooks) == 1
    assert hooks[0].name == "test-hook"
    assert hooks[0].trigger["type"] == "file_change"
    assert hooks[0].command == "echo {file}"


def test_hook_matching(temp_hook_dir):
    hook_file = temp_hook_dir / "test.toml"
    hook_file.write_text("""
[hook]
name = "py-hook"
trigger = { type = "file_change", patterns = ["*.py", "*.ts"] }
command = "lint {file}"
async = true
""")
    engine = HookEngine()
    assert engine._match(engine.hooks[0], "test.py")
    assert engine._match(engine.hooks[0], "test.ts")
    assert not engine._match(engine.hooks[0], "test.txt")


def test_hook_ignores_rumbod_dir(temp_hook_dir):
    hook_file = temp_hook_dir / "test.toml"
    hook_file.write_text("""
[hook]
name = "all-hook"
trigger = { type = "file_change", patterns = ["**/*"] }
command = "echo {file}"
async = true
""")
    engine = HookEngine()
    # _match only does pattern matching; filtering happens in _watch
    assert engine._match(engine.hooks[0], ".rumbod/specs/test.md")
    assert engine._match(engine.hooks[0], "src/.rumbod/test.py")