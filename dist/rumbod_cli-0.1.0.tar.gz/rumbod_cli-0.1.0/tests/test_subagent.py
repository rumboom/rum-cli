from unittest.mock import AsyncMock, patch
import json
import pytest

from rumbod_cli.subagent import SubAgentConfig, SubAgentResult, spawn_agent, _SUB_TOOLS, _extract_json, _repair_json


@pytest.mark.asyncio
async def test_spawn_agent_success():
    provider = AsyncMock()
    provider.chat.return_value = json.dumps([
        {"step": 1, "tool": "shell", "args": {"cmd": "echo hello"}, "expected": "greet", "done": True},
    ])
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("say hello")
    assert result.success is True
    assert result.iterations == 1
    assert len(result.history) == 1
    assert result.history[0]["tool"] == "shell"


@pytest.mark.asyncio
async def test_spawn_agent_multi_step():
    provider = AsyncMock()
    provider.chat.side_effect = [
        json.dumps([
            {"step": 1, "tool": "shell", "args": {"cmd": "echo first"}, "expected": "first step"},
        ]),
        json.dumps([
            {"step": 2, "tool": "shell", "args": {"cmd": "echo second"}, "expected": "done", "done": True},
        ]),
    ]
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("multi-step", SubAgentConfig(max_iter=5))
    assert result.success is True
    assert result.iterations == 2
    assert len(result.history) == 2


@pytest.mark.asyncio
async def test_spawn_agent_unknown_tool():
    provider = AsyncMock()
    provider.chat.return_value = json.dumps([
        {"step": 1, "tool": "nonexistent_tool", "args": {}, "expected": "will fail", "done": True},
    ])
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("test")
    assert result.success is True
    assert "Unknown tool" in result.history[0]["result"]


@pytest.mark.asyncio
async def test_spawn_agent_timeout():
    provider = AsyncMock()
    provider.chat.side_effect = __import__("asyncio").TimeoutError()
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("test", SubAgentConfig(timeout=5))
    assert result.success is False
    assert result.error == "model timeout"


@pytest.mark.asyncio
async def test_spawn_agent_json_error_exhausted():
    provider = AsyncMock()
    provider.chat.return_value = "not valid json"
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("test")
    assert result.success is False
    assert "Failed to parse" in result.summary
    assert "3 retries" in result.summary
    assert provider.chat.call_count == 3


@pytest.mark.asyncio
async def test_spawn_agent_json_retry_recover():
    provider = AsyncMock()
    provider.chat.side_effect = [
        "not json",
        "not json either",
        json.dumps([{"step": 1, "tool": "shell", "args": {"cmd": "echo recovered"}, "expected": "ok", "done": True}]),
    ]
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("test")
    assert result.success is True
    assert result.history[0]["tool"] == "shell"


@pytest.mark.asyncio
async def test_spawn_agent_provider_error():
    provider = AsyncMock()
    provider.chat.side_effect = RuntimeError("provider crashed")
    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("test")
    assert result.success is False
    assert "provider crashed" in result.error


@pytest.mark.asyncio
async def test_spawn_agent_on_step_callback():
    provider = AsyncMock()
    provider.chat.return_value = json.dumps([
        {"step": 1, "tool": "shell", "args": {"cmd": "echo hi"}, "expected": "echo", "done": True},
    ])
    callback_data = []

    def cb(step: dict, expected: str) -> None:
        callback_data.append((step, expected))

    with patch("rumbod_cli.subagent.get_provider", return_value=provider):
        result = await spawn_agent("test", SubAgentConfig(on_step=cb))
    assert result.success is True
    assert len(callback_data) == 1
    assert callback_data[0][0]["tool"] == "shell"
    assert callback_data[0][1] == "echo"


@pytest.mark.asyncio
async def test_spawn_agent_tool_filter():
    provider = AsyncMock()
    provider.chat.return_value = json.dumps([
        {"step": 1, "tool": "web_search", "args": {"query": "test"}, "expected": "search", "done": True},
        {"step": 2, "tool": "shell", "args": {"cmd": "echo x"}, "expected": "", "done": True},
    ])
    with (
        patch("rumbod_cli.subagent.get_provider", return_value=provider),
        patch("rumbod_cli.subagent._SUB_TOOLS", {
            "shell": {"fn": AsyncMock(return_value="ok"), "desc": ""},
            "web_search": {"fn": AsyncMock(return_value="results"), "desc": ""},
        }),
    ):
        result = await spawn_agent("test", SubAgentConfig(tools=["shell"]))
    assert result.success is True
    assert result.history[0]["tool"] == "web_search"
    assert "Unknown tool" in result.history[0]["result"]


@pytest.mark.asyncio
async def test_spawn_agent_config_defaults():
    cfg = SubAgentConfig()
    assert cfg.model == "auto"
    assert cfg.max_iter == 10
    assert cfg.timeout == 120.0
    assert cfg.spec_id is None
    assert cfg.tools is None
    assert cfg.on_step is None
    assert cfg.on_done is None


@pytest.mark.asyncio
async def test_spawn_result_dataclass():
    r = SubAgentResult(success=True, summary="done", history=[], iterations=1)
    assert r.success is True
    assert r.summary == "done"
    assert r.error is None
    r2 = SubAgentResult(success=False, summary="fail", history=[], iterations=0, error="boom")
    assert r2.error == "boom"


def test_extract_json_plain():
    assert _extract_json('[{"step": 1}]') == '[{"step": 1}]'


def test_extract_json_with_fences():
    raw = '```json\n[{"step": 1}]\n```'
    assert _extract_json(raw) == '[{"step": 1}]'


def test_extract_json_with_text():
    raw = 'Here is the plan:\n[{"step": 1, "tool": "shell", "args": {"cmd": "ls"}}]\nDone.'
    assert _extract_json(raw) == '[{"step": 1, "tool": "shell", "args": {"cmd": "ls"}}]'


def test_extract_json_no_brackets():
    assert _extract_json("hello world") == "hello world"


def test_extract_json_empty():
    assert _extract_json("") == ""


def test_repair_json_noop():
    raw = '[{"step": 1, "tool": "shell"}]'
    assert json.loads(_repair_json(raw)) == [{"step": 1, "tool": "shell"}]


def test_repair_json_missing_brace():
    raw = '["step": 1, "tool": "shell", "done": true]'
    result = json.loads(_repair_json(raw))
    assert result == [{"step": 1, "tool": "shell", "done": True}]


def test_repair_json_single_quotes():
    raw = "[{'step': 1, 'tool': 'shell'}]"
    result = json.loads(_repair_json(raw))
    assert result == [{"step": 1, "tool": "shell"}]


def test_repair_json_double_comma():
    raw = '[{"step": 1, "tool": "shell"},, {"step": 2, "done": true}]'
    result = json.loads(_repair_json(raw))
    assert result == [{"step": 1, "tool": "shell"}, {"step": 2, "done": True}]


def test_repair_json_trailing_comma():
    raw = '[{"step": 1, "tool": "shell",}]'
    result = json.loads(_repair_json(raw))
    assert result == [{"step": 1, "tool": "shell"}]


def test_repair_json_missing_closing_brace():
    raw = '["step": 1, "tool": "shell", "done": true]'
    result = json.loads(_repair_json(raw))
    assert result == [{"step": 1, "tool": "shell", "done": True}]


def test_repair_json_complex():
    raw = '["step": 1, "tool": "shell", "args": {"cmd": "echo hello"}, "expected": "first"]'
    result = json.loads(_repair_json(raw))
    assert result[0]["step"] == 1
    assert result[0]["expected"] == "first"





def test_sub_tools_defined():
    assert "shell" in _SUB_TOOLS
    assert "git_status" in _SUB_TOOLS
    assert "git_diff" in _SUB_TOOLS
    assert "run_tests" in _SUB_TOOLS
    assert "web_search" in _SUB_TOOLS
    assert "web_fetch" in _SUB_TOOLS
    assert "read_file" in _SUB_TOOLS
    assert "write_file" in _SUB_TOOLS
    assert "list_files" in _SUB_TOOLS
    assert "glob_files" in _SUB_TOOLS
