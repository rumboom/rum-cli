import json
from pathlib import Path
import time
import pytest

from rumbod_cli.apiusage import (
    _USAGE_FILE,
    _read,
    _write,
    record_usage,
    get_usage_summary,
    format_usage,
    reset_usage,
)

USAGE_ALT = Path("/tmp/test_rumbod_apiusage.json")


@pytest.fixture(autouse=True)
def isolate():
    old = _USAGE_FILE.read_text() if _USAGE_FILE.exists() else None
    existed = _USAGE_FILE.exists()
    if existed:
        _USAGE_FILE.unlink()
    yield
    if existed and old:
        _USAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _USAGE_FILE.write_text(old)


def test_record_and_read():
    record_usage(100, 50, "test-model")
    data = get_usage_summary()
    assert data["total_calls"] == 1
    assert data["total_prompt_tokens"] == 100
    assert data["total_completion_tokens"] == 50
    assert data["total_tokens"] == 150
    assert "test-model" in data["models"]
    assert data["models"]["test-model"]["calls"] == 1


def test_multiple_calls_sum():
    record_usage(100, 50, "model-a")
    record_usage(200, 30, "model-b")
    record_usage(10, 5, "model-a")
    data = get_usage_summary()
    assert data["total_calls"] == 3
    assert data["total_prompt_tokens"] == 310
    assert data["total_completion_tokens"] == 85
    assert data["total_tokens"] == 395
    assert data["models"]["model-a"]["calls"] == 2
    assert data["models"]["model-a"]["total_tokens"] == 165
    assert data["models"]["model-b"]["calls"] == 1
    assert data["models"]["model-b"]["total_tokens"] == 230


def test_reset():
    record_usage(100, 50, "m")
    reset_usage()
    data = get_usage_summary()
    assert data["total_calls"] == 0
    assert data["total_tokens"] == 0
    assert data["models"] == {}


def test_persistence():
    record_usage(50, 25, "persist-model")
    data1 = get_usage_summary()
    data2 = _read()
    assert data1 == data2
    assert data2["total_calls"] == 1
    assert data2["models"]["persist-model"]["total_tokens"] == 75


def test_format_usage():
    record_usage(1000, 500, "nvidia/llama-3.3-nemotron-super-49b-v1")
    text = format_usage()
    assert "1,000" in text
    assert "500" in text
    assert "1,500" in text
    assert "1 calls" in text
    assert "super-49b" in text or "llama" in text


def test_format_usage_empty():
    text = format_usage()
    assert "0" in text
    assert "calls" in text


def test_format_usage_custom_data():
    data = {
        "total_calls": 5,
        "total_prompt_tokens": 500,
        "total_completion_tokens": 250,
        "total_tokens": 750,
        "since": "2026-01-01T00:00:00Z",
        "models": {"m1": {"calls": 3, "prompt_tokens": 300, "completion_tokens": 150, "total_tokens": 450}},
    }
    text = format_usage(data)
    assert "5" in text
    assert "500" in text
    assert "Since" in text


def test_file_creation():
    assert _USAGE_FILE.exists() is False
    _read()
    assert _USAGE_FILE.exists() is True
    data = json.loads(_USAGE_FILE.read_text())
    assert data["total_calls"] == 0


def test_record_with_zero():
    record_usage(0, 0, "zero-model")
    data = get_usage_summary()
    assert data["total_calls"] == 1
    assert data["total_tokens"] == 0


def test_multi_model_breakdown():
    models = [("a", 10, 5), ("b", 20, 10), ("a", 30, 15), ("c", 40, 20)]
    for m, p, c in models:
        record_usage(p, c, m)
    data = get_usage_summary()
    assert data["models"]["a"]["calls"] == 2
    assert data["models"]["a"]["prompt_tokens"] == 40
    assert data["models"]["b"]["calls"] == 1
    assert data["models"]["c"]["calls"] == 1
    assert data["total_tokens"] == sum(p + c for _, p, c in models)


def test_since_timestamp():
    before = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    record_usage(1, 1, "ts")
    data = get_usage_summary()
    assert data["since"] >= before


def test_reset_does_not_affect_subsequent():
    record_usage(10, 5, "x")
    reset_usage()
    record_usage(20, 10, "y")
    data = get_usage_summary()
    assert data["total_calls"] == 1
    assert data["total_tokens"] == 30
    assert "x" not in data["models"]
