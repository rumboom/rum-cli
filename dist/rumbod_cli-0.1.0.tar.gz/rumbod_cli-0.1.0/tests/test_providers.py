import httpx
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import os

from rumbod_cli.models import OpenAIProvider, AnthropicProvider, ProviderError


@pytest.mark.asyncio
async def test_openai_provider_chat():
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "choices": [{"message": {"content": "hello from openai"}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        }
        mock_post.return_value = mock_resp

        p = OpenAIProvider("gpt-4o", api_key="sk-test-key-12345")
        result = await p.chat([{"role": "user", "content": "hi"}])
        assert result == "hello from openai"


@pytest.mark.asyncio
async def test_openai_provider_stream_chat():
    with patch("httpx.AsyncClient.stream") as mock_stream:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()

        async def mock_aiter():
            yield 'data: {"choices": [{"delta": {"content": "hello"}}]}'
            yield 'data: {"choices": [{"delta": {"content": " world"}}]}'
            yield "data: [DONE]"

        mock_resp.aiter_lines = mock_aiter
        mock_stream.return_value = mock_resp

        p = OpenAIProvider("gpt-4o", api_key="sk-test-key-12345")
        chunks = []
        async for chunk in p.stream_chat([{"role": "user", "content": "hi"}]):
            chunks.append(chunk)
        assert chunks == ["hello", " world"]


@pytest.mark.asyncio
async def test_openai_provider_chat_with_tools():
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "choices": [{
                "message": {
                    "content": None,
                    "tool_calls": [{
                        "id": "call_1",
                        "function": {"name": "run_shell", "arguments": '{"cmd": "echo hi"}'},
                    }],
                }
            }],
            "usage": {"prompt_tokens": 20, "completion_tokens": 10},
        }
        mock_post.return_value = mock_resp

        p = OpenAIProvider("gpt-4o", api_key="sk-test-key-12345")
        text, calls = await p.chat_with_tools([{"role": "user", "content": "run cmd"}])
        assert text is None
        assert len(calls) == 1
        assert calls[0].name == "run_shell"
        assert calls[0].arguments == {"cmd": "echo hi"}


@pytest.mark.asyncio
async def test_openai_provider_missing_key():
    with patch.dict(os.environ, {}, clear=True):
        with pytest.raises(ProviderError, match="API_KEY"):
            OpenAIProvider("gpt-4o")


@pytest.mark.asyncio
async def test_openai_provider_retry_on_429():
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 429
        mock_resp.text = "Too Many Requests"
        mock_post.return_value = mock_resp

        p = OpenAIProvider("gpt-4o", api_key="sk-test-key-12345")
        with pytest.raises(httpx.HTTPStatusError):
            await p.chat([{"role": "user", "content": "hi"}])


@pytest.mark.asyncio
async def test_anthropic_provider_chat():
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "content": [{"type": "text", "text": "hello from claude"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        mock_post.return_value = mock_resp

        p = AnthropicProvider("claude-sonnet-4-20250514", api_key="sk-ant-test-key-12345")
        result = await p.chat([{"role": "user", "content": "hi"}])
        assert result == "hello from claude"


@pytest.mark.asyncio
async def test_anthropic_provider_system_message():
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "content": [{"type": "text", "text": "ok"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        mock_post.return_value = mock_resp

        p = AnthropicProvider("claude-sonnet-4-20250514", api_key="sk-ant-test-key-12345")
        result = await p.chat([
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "hi"},
        ])
        assert result == "ok"
        called_payload = mock_post.call_args[1]["json"]
        assert "system" in called_payload
        assert called_payload["system"] == "You are a helpful assistant."


@pytest.mark.asyncio
async def test_anthropic_provider_stream_chat():
    p = AnthropicProvider("claude-sonnet-4-20250514", api_key="sk-ant-test-key-12345")

    async def mock_aiter():
        yield 'event: content_block_delta'
        yield 'data: {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "hello"}}'
        yield 'event: content_block_delta'
        yield 'data: {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": " world"}}'
        yield 'event: message_stop'
        yield 'data: {"type": "message_stop"}'

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.aiter_lines = mock_aiter
    mock_ctx = MagicMock()
    mock_ctx.__aenter__.return_value = mock_resp
    mock_ctx.__aexit__.return_value = None
    p.client = MagicMock()
    p.client.stream.return_value = mock_ctx

    chunks = []
    async for chunk in p.stream_chat([{"role": "user", "content": "hi"}]):
        chunks.append(chunk)
    assert chunks == ["hello", " world"]


@pytest.mark.asyncio
async def test_anthropic_provider_missing_key():
    with patch.dict(os.environ, {}, clear=True):
        with pytest.raises(ProviderError, match="API_KEY"):
            AnthropicProvider("claude-sonnet-4-20250514")


@pytest.mark.asyncio
async def test_get_provider_openai():
    from rumbod_cli.models import get_provider
    provider = get_provider("openai:gpt-4o", api_key="sk-test-key-12345")
    assert isinstance(provider, OpenAIProvider)


@pytest.mark.asyncio
async def test_get_provider_anthropic():
    from rumbod_cli.models import get_provider
    provider = get_provider("anthropic:claude-sonnet-4-20250514", api_key="sk-ant-test-key-12345")
    assert isinstance(provider, AnthropicProvider)


@pytest.mark.asyncio
async def test_get_provider_auto_with_openai_key():
    from rumbod_cli.models import get_provider, OpenAIProvider
    with patch("rumbod_cli.models.OPENAI_API_KEY", "sk-test-key-12345"):
        with patch("rumbod_cli.models.NVIDIA_API_KEY", ""):
            with patch("rumbod_cli.models.ANTHROPIC_API_KEY", ""):
                provider = get_provider("auto")
                assert isinstance(provider, OpenAIProvider)


@pytest.mark.asyncio
async def test_get_provider_auto_with_anthropic_key():
    from rumbod_cli.models import get_provider
    with patch("rumbod_cli.models.OPENAI_API_KEY", ""):
        with patch("rumbod_cli.models.ANTHROPIC_API_KEY", "sk-ant-test-key-12345"):
            with patch("rumbod_cli.models.NVIDIA_API_KEY", ""):
                provider = get_provider("auto")
                assert isinstance(provider, AnthropicProvider)


@pytest.mark.asyncio
async def test_provider_from_spec_nvidia():
    from rumbod_cli.models import get_provider, NvidiaProvider
    p = get_provider("nvidia:test-model")
    assert isinstance(p, NvidiaProvider)


@pytest.mark.asyncio
async def test_provider_from_spec_unknown():
    from rumbod_cli.models import get_provider
    p = get_provider("unknown:model")
    assert p is not None
