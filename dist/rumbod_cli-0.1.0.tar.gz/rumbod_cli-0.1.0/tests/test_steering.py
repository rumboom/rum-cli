import pytest
from pathlib import Path
import tempfile
import os

os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.steering import load_steering, match_steering, get_steering_for_files


@pytest.fixture
def temp_steering_dir(monkeypatch):
    with tempfile.TemporaryDirectory() as tmpdir:
        steer_dir = Path(tmpdir) / ".rumbod" / "steering"
        steer_dir.mkdir(parents=True)
        monkeypatch.chdir(tmpdir)
        yield steer_dir


def test_load_steering(temp_steering_dir):
    (temp_steering_dir / "python.md").write_text("""---
globs:
  - "**/*.py"
---
# Python Rules
Use type hints.
""")
    rules = load_steering()
    assert "python" in rules
    assert "Use type hints." in rules["python"]


def test_match_steering(temp_steering_dir):
    (temp_steering_dir / "python.md").write_text("""---
globs:
  - "**/*.py"
---
Python Rules
""")
    (temp_steering_dir / "rust.md").write_text("""---
globs:
  - "**/*.rs"
---
Rust Rules
""")
    rules = load_steering()
    matched = match_steering("src/main.py", rules)
    assert len(matched) == 1
    assert "Python Rules" in matched[0]

    matched = match_steering("src/main.rs", rules)
    assert len(matched) == 1
    assert "Rust Rules" in matched[0]


def test_get_steering_for_files(temp_steering_dir):
    (temp_steering_dir / "python.md").write_text("""---
globs:
  - "**/*.py"
---
Python Rules
""")
    (temp_steering_dir / "general.md").write_text("""---
globs:
  - "**/*"
---
General Rules
""")
    result = get_steering_for_files(["src/main.py", "README.md"])
    assert "Python Rules" in result
    assert "General Rules" in result