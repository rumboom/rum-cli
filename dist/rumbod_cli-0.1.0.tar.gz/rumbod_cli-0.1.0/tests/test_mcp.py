import pytest
import os

os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.mcp import MCPClient, MCPServer


def test_add_server():
    client = MCPClient()
    client.add_server("test", ["echo", "hello"])
    assert "test" in client.servers
    assert client.servers["test"].command == ["echo", "hello"]


def test_add_server_with_env():
    client = MCPClient()
    client.add_server("test", ["echo", "hello"], {"FOO": "bar"})
    assert client.servers["test"].env == {"FOO": "bar"}