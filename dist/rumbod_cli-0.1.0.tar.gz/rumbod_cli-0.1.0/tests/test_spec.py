import pytest
from pathlib import Path
import tempfile
import os

os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.spec import new_spec, list_specs, get_spec, approve_spec, verify_spec, Spec


@pytest.fixture
def temp_spec_dir(monkeypatch):
    with tempfile.TemporaryDirectory() as tmpdir:
        spec_dir = Path(tmpdir) / ".rumbod" / "specs"
        spec_dir.mkdir(parents=True)
        monkeypatch.chdir(tmpdir)
        yield spec_dir


def test_new_spec(temp_spec_dir):
    spec = new_spec("Test Feature")
    assert spec.id.startswith("feat-")
    assert spec.title == "Test Feature"
    assert spec.status == "draft"
    assert spec.path().exists()


def test_list_specs(temp_spec_dir):
    new_spec("First Spec")
    new_spec("Second Spec")
    specs = list_specs()
    assert len(specs) == 2
    titles = {s.title for s in specs}
    assert titles == {"First Spec", "Second Spec"}


def test_get_spec(temp_spec_dir):
    spec = new_spec("Find Me")
    found = get_spec(spec.id)
    assert found is not None
    assert found.title == "Find Me"
    
    not_found = get_spec("feat-nonexistent")
    assert not_found is None


def test_approve_spec(temp_spec_dir):
    spec = new_spec("To Approve")
    approved = approve_spec(spec.id)
    assert approved.status == "approved"


def test_verify_spec(temp_spec_dir):
    spec = new_spec("To Verify")
    verified = verify_spec(spec.id)
    assert verified.status == "verified"


def test_spec_persistence(temp_spec_dir):
    spec = new_spec("Persistent")
    spec_id = spec.id
    
    # Reload
    spec2 = get_spec(spec_id)
    assert spec2 is not None
    assert spec2.title == "Persistent"
    assert spec2.status == "draft"