import json
from pathlib import Path
import pytest

from rumbod_cli.apikeys import (
    _KEYS_FILE, _read, _write,
    ApiKeyEntry, all_keys, add_key, remove_key, remove_key_by_label,
    env_key_entry, get_working_keys, count_keys, reset_keys,
    set_key_working, update_key_status, get_next_key,
    _HIDDEN_KEY,
)


@pytest.fixture(autouse=True)
def isolate():
    old = _KEYS_FILE.read_text() if _KEYS_FILE.exists() else None
    existed = _KEYS_FILE.exists()
    if existed:
        _KEYS_FILE.unlink()
    yield
    if existed and old:
        _KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
        _KEYS_FILE.write_text(old)


def test_add_and_list():
    add_key("nvapi-aaaa1234bbbb5678cccc")
    keys = all_keys()
    assert len(keys) == 1
    assert keys[0].key == "nvapi-aaaa1234bbbb5678cccc"
    assert "nvapi-" in keys[0].masked
    assert "cccc" in keys[0].masked


def test_add_duplicate():
    add_key("nvapi-test123456789012")
    with pytest.raises(ValueError, match="already exists"):
        add_key("nvapi-test123456789012")


def test_add_empty():
    with pytest.raises(ValueError, match="empty"):
        add_key("")


def test_add_whitespace():
    add_key("  nvapi-key123456789012  \n  ")
    assert all_keys()[0].key == "nvapi-key123456789012"


def test_remove_by_index():
    add_key("nvapi-one123456789012")
    add_key("nvapi-two123456789012")
    assert remove_key(0) is True
    keys = all_keys()
    assert len(keys) == 1
    assert keys[0].key == "nvapi-two123456789012"


def test_remove_invalid_index():
    assert remove_key(99) is False


def test_remove_by_label():
    add_key("nvapi-key123456789012", label="my first key")
    assert remove_key_by_label("my first key") is True
    assert len(all_keys()) == 0


def test_remove_by_masked():
    add_key("nvapi-key123456789012")
    keys = all_keys()
    masked = keys[0].masked
    assert remove_key_by_label(masked) is True
    assert len(all_keys()) == 0


def test_count_keys():
    assert count_keys() == 0
    add_key("nvapi-one123456789012")
    assert count_keys() == 1
    add_key("nvapi-two123456789012")
    assert count_keys() == 2


def test_reset():
    add_key("nvapi-one123456789012")
    add_key("nvapi-two123456789012")
    reset_keys()
    assert count_keys() == 0
    assert all_keys() == []


def test_set_working():
    add_key("nvapi-test-key123456789012")
    set_key_working(0, True)
    assert all_keys()[0].working is True
    set_key_working(0, False, "rate limited")
    assert all_keys()[0].working is False
    assert "rate limited" in all_keys()[0].error


def test_update_status():
    add_key("nvapi-test-key123456789012")
    update_key_status("nvapi-test-key123456789012", True)
    assert all_keys()[0].working is True
    update_key_status("nvapi-test-key123456789012", False, "timeout")
    assert all_keys()[0].working is False


def test_env_key_entry(monkeypatch):
    monkeypatch.setenv("RUMBOD_NVIDIA_API_KEY", "nvapi-env-key1234567890")
    entry = env_key_entry()
    assert entry.label == "env:RUMBOD_NVIDIA_API_KEY"
    assert entry.working is True
    assert "nvapi" in entry.masked or "SET" in entry.masked


def test_env_key_entry_not_set(monkeypatch):
    monkeypatch.delenv("RUMBOD_NVIDIA_API_KEY", raising=False)
    entry = env_key_entry()
    assert entry.working is False
    assert entry.masked == "NOT SET"


def test_get_working_keys_env(monkeypatch):
    monkeypatch.setenv("RUMBOD_NVIDIA_API_KEY", "nvapi-env-key1234567890")
    add_key("nvapi-stored-key123456789012")
    keys = get_working_keys()
    assert len(keys) == 2


def test_get_working_keys_exclude_env():
    add_key("nvapi-stored-1123456789012")
    add_key("nvapi-stored-2123456789012")
    keys = get_working_keys(exclude_env=True)
    assert len(keys) == 2


def test_get_working_keys_filters_failed():
    add_key("nvapi-good123456789012")
    add_key("nvapi-bad123456789012")
    set_key_working(1, False, "401")
    keys = get_working_keys(exclude_env=True)
    assert len(keys) == 1
    assert "nvapi-good123456789012" in keys[0]


def test_round_robin_basic(monkeypatch):
    monkeypatch.setenv("RUMBOD_NVIDIA_API_KEY", "nvapi-env")
    add_key("nvapi-a1234567890123456")
    add_key("nvapi-b1234567890123456")
    first = get_next_key(exclude_env=True)
    second = get_next_key(exclude_env=True)
    third = get_next_key(exclude_env=True)
    assert first != second or count_keys() == 1
    assert first == third  # wraps around after 2


def test_round_robin_includes_env(monkeypatch):
    monkeypatch.setenv("RUMBOD_NVIDIA_API_KEY", "nvapi-env")
    add_key("nvapi-stored123456789012")
    keys_seen = set()
    for _ in range(6):
        keys_seen.add(get_next_key())
    assert len(keys_seen) == 2  # both env and stored


def test_get_next_none():
    assert get_next_key(exclude_env=True) is None


def test_apikey_entry_dataclass():
    entry = ApiKeyEntry(key="nvapi-test1234567890")
    assert entry.masked == "nvapi-...7890"
    assert entry.added_at != ""
    assert entry.working is None
    assert entry.error is None


def test_apikey_entry_custom_masked():
    entry = ApiKeyEntry(key="nvapi-test1234567890", masked="custom")
    assert entry.masked == "custom"


def test_file_created_automatically():
    assert _KEYS_FILE.exists() is False
    _read()
    assert _KEYS_FILE.exists() is True
    data = json.loads(_KEYS_FILE.read_text())
    assert "keys" in data
    assert "round_robin_index" in data
