from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock
import pytest


@pytest.fixture
def mock_chat():
    return MagicMock()


@pytest.fixture
def interactive(mock_chat):
    from rumbod_cli.interactive import RumbodInteractive
    app = RumbodInteractive()
    app.query_one = MagicMock(return_value=mock_chat)
    app._agent_status = "ready"
    app._cancel_requested = False
    app.provider = MagicMock()
    app.model_name = "nvidia/test-model"
    app.cfg = MagicMock()
    app.cfg.model.default = "nvidia/test-model"
    app.messages = [{"role": "system", "content": "You are a helpful assistant."}]
    app.conversation = []
    app._loading_done = True
    return app


# ── Module-level helpers ──

def test_read_ponytail_mode(tmp_path):
    from rumbod_cli.interactive import _read_ponytail_mode, PONYTAIL_STATE
    with patch("rumbod_cli.interactive.PONYTAIL_STATE", str(tmp_path / ".ponytail-active")):
        f = tmp_path / ".ponytail-active"
        f.write_text("lite")
        assert _read_ponytail_mode() == "lite"


def test_read_ponytail_mode_fallback():
    from rumbod_cli.interactive import _read_ponytail_mode
    with patch("rumbod_cli.interactive.PONYTAIL_STATE", "/nonexistent/path"):
        assert _read_ponytail_mode() == "off"


def test_write_ponytail_mode(tmp_path):
    from rumbod_cli.interactive import _write_ponytail_mode, PONYTAIL_STATE
    target = tmp_path / "sub" / ".ponytail-active"
    with patch("rumbod_cli.interactive.PONYTAIL_STATE", str(target)):
        _write_ponytail_mode("full")
        assert target.read_text() == "full"


def test_read_ponytail_skill_exists(tmp_path):
    from rumbod_cli.interactive import _read_ponytail_skill
    skill_dir = tmp_path / ".claude" / "skills" / "ponytail"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# Ponytail Skill")
    with patch.object(Path, "expanduser", return_value=skill_dir / "SKILL.md"):
        assert _read_ponytail_skill() == "# Ponytail Skill"


def test_read_ponytail_skill_missing(tmp_path):
    from rumbod_cli.interactive import _read_ponytail_skill
    with patch.object(Path, "expanduser", return_value=tmp_path / "nonexistent" / "SKILL.md"):
        assert _read_ponytail_skill() is None


# ── on_input_submitted routing ──

def test_on_input_submitted_empty(interactive, mock_chat):
    event = MagicMock()
    event.value = ""
    event.input.id = "msg-input"
    interactive.on_input_submitted(event)
    # Should return without clearing or dispatching
    assert mock_chat.write.call_count == 0


def test_on_input_submitted_slash(interactive, mock_chat):
    with patch.object(interactive, "handle_slash") as mock_handle:
        event = MagicMock()
        event.value = "/help"
        event.input.id = "msg-input"
        interactive.on_input_submitted(event)
        mock_handle.assert_called_once_with("/help")


def test_on_input_submitted_message(interactive, mock_chat):
    with patch.object(interactive, "handle_message") as mock_handle:
        event = MagicMock()
        event.value = "hello"
        event.input.id = "msg-input"
        interactive.on_input_submitted(event)
        mock_handle.assert_called_once_with("hello")


# ── handle_slash routing ──

@pytest.mark.parametrize("cmd", ["/exit", "/quit"])
def test_handle_slash_exit(interactive, cmd):
    with patch.object(interactive, "exit") as mock_exit:
        interactive.handle_slash(cmd)
        mock_exit.assert_called_once()


def test_handle_slash_help(interactive, mock_chat):
    interactive.handle_slash("/help")
    assert mock_chat.write.call_count > 0
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Available Commands" in str(c) for c in calls)


def test_handle_slash_model_current(interactive, mock_chat):
    interactive.handle_slash("/model")
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Current model" in str(c) for c in calls)


def test_handle_slash_compact(interactive, mock_chat):
    with patch("rumbod_cli.interactive.clear_conversation") as mock_clear:
        interactive.messages = [{"role": "system", "content": "sys"}, {"role": "user", "content": "msg"}]
        interactive.conversation = [{"role": "user", "content": "msg"}]
        interactive.handle_slash("/compact")
        assert len(interactive.messages) == 1
        assert interactive.messages[0]["role"] == "system"
        assert len(interactive.conversation) == 0
        mock_clear.assert_called_once()


def test_handle_slash_sessions_empty(interactive, mock_chat):
    with patch("rumbod_cli.interactive.list_sessions", return_value=[]):
        interactive.handle_slash("/sessions")
        calls = [c[0][0] for c in mock_chat.write.call_args_list]
        assert any("No saved sessions" in str(c) for c in calls)


def test_handle_slash_doctor(interactive, mock_chat):
    with patch.object(interactive, "_run_doctor") as mock_doctor:
        interactive.handle_slash("/doctor")
        mock_doctor.assert_called_once()


def test_handle_slash_clear(interactive, mock_chat):
    interactive.handle_slash("/clear")
    mock_chat.clear.assert_called_once()


def test_handle_slash_web_search_no_arg(interactive, mock_chat):
    interactive.handle_slash("/web_search")
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Usage" in str(c) for c in calls)


def test_handle_slash_web_search_with_arg(interactive, mock_chat):
    with patch.object(interactive, "_run_web_search") as mock_run:
        interactive.handle_slash("/web_search climate change")
        mock_run.assert_called_once_with("climate change", mock_chat)


def test_handle_slash_spawn_no_arg(interactive, mock_chat):
    interactive.handle_slash("/spawn")
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Usage" in str(c) for c in calls)


def test_handle_slash_cancel_when_ready(interactive, mock_chat):
    interactive._agent_status = "ready"
    interactive.handle_slash("/cancel")
    assert interactive._cancel_requested is False


def test_handle_slash_cancel_when_busy(interactive, mock_chat):
    interactive._agent_status = "thinking..."
    interactive.handle_slash("/cancel")
    assert interactive._cancel_requested is True


# ── handle_message ──

def test_handle_message_no_provider(interactive, mock_chat):
    interactive.provider = None
    with patch("rumbod_cli.interactive.append_message") as mock_append:
        interactive.handle_message("hi")
        mock_append.assert_not_called()
        calls = [c[0][0] for c in mock_chat.write.call_args_list]
        assert any("No provider configured" in str(c) for c in calls)


def test_handle_message_with_provider(interactive, mock_chat):
    with (
        patch("rumbod_cli.interactive.append_message") as mock_append,
        patch.object(interactive, "_run_chat") as mock_run,
    ):
        interactive.handle_message("hello")
        mock_append.assert_called_once_with("user", "hello")
        assert interactive.messages[-1] == {"role": "user", "content": "hello"}
        assert interactive.conversation[-1] == {"role": "user", "content": "hello"}
        mock_run.assert_called_once()


# ── _prune_context ──

def test_prune_context_under_limit(interactive):
    msgs = [{"role": "system", "content": "sys"}] + [{"role": "user", "content": f"msg{i}"} for i in range(10)]
    interactive.messages = msgs
    interactive.MAX_CONTEXT = 16
    interactive._prune_context()
    assert len(interactive.messages) == 11


def test_prune_context_over_limit(interactive):
    msgs = [{"role": "system", "content": "sys"}] + [{"role": "user", "content": f"msg{i}"} for i in range(30)]
    interactive.messages = msgs
    interactive.conversation = [{"role": "user", "content": f"msg{i}"} for i in range(30)]
    interactive.MAX_CONTEXT = 16
    interactive._prune_context()
    # Should have system + trimmed note + 15 recent = 17
    assert len(interactive.messages) == 17
    assert interactive.messages[1]["role"] == "system"
    assert "trimmed" in interactive.messages[1]["content"]
    assert len(interactive.conversation) == 15


# ── _execute_tool ──

@pytest.mark.asyncio
async def test_execute_tool_shell(interactive):
    with patch("rumbod_cli.tools.shell.run_shell", new_callable=AsyncMock) as mock_shell:
        mock_shell.return_value = {"stdout": "hello\n", "stderr": "", "returncode": 0}
        result = await interactive._execute_tool("shell", "echo hello")
        assert result == "hello"


@pytest.mark.asyncio
async def test_execute_tool_shell_error(interactive):
    with patch("rumbod_cli.tools.shell.run_shell", new_callable=AsyncMock) as mock_shell:
        mock_shell.return_value = {"error": "Command not found"}
        result = await interactive._execute_tool("shell", "noop")
        assert "Error" in result


@pytest.mark.asyncio
async def test_execute_tool_shell_exit_code(interactive):
    with patch("rumbod_cli.tools.shell.run_shell", new_callable=AsyncMock) as mock_shell:
        mock_shell.return_value = {"stdout": "", "stderr": "", "returncode": 1}
        result = await interactive._execute_tool("shell", "false")
        assert "exit code: 1" in result


@pytest.mark.asyncio
async def test_execute_tool_read(interactive, tmp_path):
    f = tmp_path / "test.txt"
    f.write_text("hello world")
    result = await interactive._execute_tool("read", str(f))
    assert result == "hello world"


@pytest.mark.asyncio
async def test_execute_tool_read_not_found(interactive, tmp_path):
    result = await interactive._execute_tool("read", str(tmp_path / "nope.txt"))
    assert "not found" in result


@pytest.mark.asyncio
async def test_execute_tool_read_truncated(interactive, tmp_path):
    f = tmp_path / "big.txt"
    f.write_text("x" * 5000)
    result = await interactive._execute_tool("read", str(f))
    assert len(result) < 4000
    assert "truncated" in result


@pytest.mark.asyncio
async def test_execute_tool_unknown(interactive):
    result = await interactive._execute_tool("unknown", "stuff")
    assert "Unknown tool" in result


# ── _execute_tool_call ──

@pytest.mark.asyncio
async def test_execute_tool_call_run_shell(interactive):
    from rumbod_cli.models import ToolCall
    with patch("rumbod_cli.tools.shell.run_shell", new_callable=AsyncMock) as mock_shell:
        mock_shell.return_value = {"stdout": "ok", "stderr": "", "returncode": 0}
        tc = ToolCall(id="1", name="run_shell", arguments={"command": "echo ok"})
        result = await interactive._execute_tool_call(tc)
        assert result == "ok"


@pytest.mark.asyncio
async def test_execute_tool_call_read_file(interactive, tmp_path):
    from rumbod_cli.models import ToolCall
    f = tmp_path / "test.txt"
    f.write_text("data")
    tc = ToolCall(id="2", name="read_file", arguments={"path": str(f)})
    result = await interactive._execute_tool_call(tc)
    assert result == "data"


@pytest.mark.asyncio
async def test_execute_tool_call_read_file_not_found(interactive):
    from rumbod_cli.models import ToolCall
    tc = ToolCall(id="3", name="read_file", arguments={"path": "/nonexistent/file"})
    result = await interactive._execute_tool_call(tc)
    assert "not found" in result


@pytest.mark.asyncio
async def test_execute_tool_call_unknown(interactive):
    from rumbod_cli.models import ToolCall
    tc = ToolCall(id="4", name="unknown_tool", arguments={})
    result = await interactive._execute_tool_call(tc)
    assert "Unknown tool" in result


# ── web search/fetch dispatch (via handle_slash) ──

def test_run_web_search_dispatches_correctly(interactive, mock_chat):
    with patch.object(interactive, "_run_web_search") as mock_run:
        interactive.handle_slash("/web_search test query")
        mock_run.assert_called_once_with("test query", mock_chat)


def test_run_web_search_no_arg(interactive, mock_chat):
    interactive.handle_slash("/web_search")
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Usage" in str(c) for c in calls)


def test_run_web_fetch_dispatches_correctly(interactive, mock_chat):
    with patch.object(interactive, "_run_web_fetch") as mock_run:
        interactive.handle_slash("/web_fetch https://example.com")
        mock_run.assert_called_once_with("https://example.com", mock_chat)


# ── handle_spec ──

def test_handle_spec_new(interactive, mock_chat):
    with patch("rumbod_cli.interactive.new_spec") as mock_new:
        mock_new.return_value = MagicMock(id="spec-1")
        interactive.handle_spec("new My Feature", mock_chat)
        mock_new.assert_called_once_with("My Feature")


def test_handle_spec_list(interactive, mock_chat):
    with patch("rumbod_cli.interactive.list_specs") as mock_list:
        mock_list.return_value = [MagicMock(id="s1", title="Spec1")]
        interactive.handle_spec("list", mock_chat)
        mock_list.assert_called_once()


def test_handle_spec_approve_not_found(interactive, mock_chat):
    with patch("rumbod_cli.interactive.approve_spec", return_value=None):
        interactive.handle_spec("approve bad-id", mock_chat)
        calls = [c[0][0] for c in mock_chat.write.call_args_list]
        assert any("Spec not found" in str(c) for c in calls)


def test_handle_spec_unknown_sub(interactive, mock_chat):
    interactive.handle_spec("badsub", mock_chat)
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Usage" in str(c) for c in calls)


# ── handle_apikey dispatch (via handle_slash) ──

def test_handle_apikey_list(interactive, mock_chat):
    with patch.object(interactive, "handle_apikey") as mock_fn:
        interactive.handle_slash("/apikey list")
        mock_fn.assert_called_once_with("list", mock_chat)


def test_handle_apikey_add(interactive, mock_chat):
    with patch.object(interactive, "handle_apikey") as mock_fn:
        interactive.handle_slash("/apikey add sk-test-key-12345")
        mock_fn.assert_called_once_with("add sk-test-key-12345", mock_chat)


def test_handle_apikey_remove(interactive, mock_chat):
    with patch.object(interactive, "handle_apikey") as mock_fn:
        interactive.handle_slash("/apikey remove 0")
        mock_fn.assert_called_once_with("remove 0", mock_chat)


# ── handle_ponytail ──

def test_handle_ponytail_status(interactive, mock_chat):
    with patch("rumbod_cli.interactive._read_ponytail_mode", return_value="off"):
        interactive.handle_ponytail("status", mock_chat)
        calls = [c[0][0] for c in mock_chat.write.call_args_list]
        assert any("off" in str(c).lower() for c in calls)


def test_handle_ponytail_no_arg(interactive, mock_chat):
    with patch("rumbod_cli.interactive._read_ponytail_mode", return_value="lite"):
        interactive.handle_ponytail("", mock_chat)
        calls = [c[0][0] for c in mock_chat.write.call_args_list]
        assert any("lite" in str(c) for c in calls)


# ── handle_provider ──

def test_handle_provider_list(interactive, mock_chat):
    with patch("rumbod_cli.interactive.all_providers") as mock_provs:
        mock_provs.return_value = []
        interactive.handle_provider("list", mock_chat)
        mock_provs.assert_called_once()


def test_handle_provider_unknown_sub(interactive, mock_chat):
    interactive.handle_provider("badsub", mock_chat)
    calls = [c[0][0] for c in mock_chat.write.call_args_list]
    assert any("Usage" in str(c) for c in calls)


# ── _TOOL_RE and _FENCE_RE patterns ──

def test_tool_re_simple():
    from rumbod_cli.interactive import RumbodInteractive
    m = RumbodInteractive._TOOL_RE.search("<shell>echo hi</shell>")
    assert m is not None
    assert m.group(1) == "shell"
    assert m.group(2).strip() == "echo hi"


def test_tool_re_multiline():
    from rumbod_cli.interactive import RumbodInteractive
    m = RumbodInteractive._TOOL_RE.search("<read>\nfile.txt\n</read>")
    assert m is not None
    assert m.group(1) == "read"


def test_fence_re():
    from rumbod_cli.interactive import RumbodInteractive
    m = RumbodInteractive._FENCE_RE.search("```bash\necho hi\n```")
    assert m is not None
    assert m.group(1) == "bash"
    assert "echo hi" in m.group(2)


# ── _run_apikey_test ──

@pytest.mark.asyncio
async def test_run_apikey_test_no_keys(interactive, mock_chat):
    with patch("rumbod_cli.apikeys.all_keys", return_value=[]):
        interactive._run_apikey_test(mock_chat)
        import asyncio
        await asyncio.sleep(0.05)
        calls = [c[0][0] for c in mock_chat.write.call_args_list]
        assert any("No stored keys to test" in str(c) for c in calls)
