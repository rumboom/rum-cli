import pytest
from unittest.mock import AsyncMock, MagicMock, patch


@pytest.mark.asyncio
async def test_list_issues():
    with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_req:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = [
            {"number": 1, "title": "Fix bug", "state": "open", "html_url": "https://github.com/owner/repo/issues/1"},
            {"number": 2, "title": "Add feature", "state": "open", "html_url": "https://github.com/owner/repo/issues/2", "pull_request": {}},
        ]
        mock_req.return_value = mock_resp

        from rumbod_cli.tools.github_ import list_issues
        result = await list_issues("owner/repo")
        assert len(result) == 1
        assert result[0]["number"] == 1


@pytest.mark.asyncio
async def test_list_prs():
    with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_req:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = [
            {"number": 42, "title": "Cool PR", "state": "open", "html_url": "https://github.com/owner/repo/pull/42"},
        ]
        mock_req.return_value = mock_resp

        from rumbod_cli.tools.github_ import list_prs
        result = await list_prs("owner/repo")
        assert len(result) == 1
        assert result[0]["number"] == 42


@pytest.mark.asyncio
async def test_search_repos():
    with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_req:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "items": [{"full_name": "owner/repo", "description": "A repo", "stargazers_count": 100, "html_url": "https://github.com/owner/repo"}],
        }
        mock_req.return_value = mock_resp

        from rumbod_cli.tools.github_ import search_repos
        result = await search_repos("test query")
        assert len(result) == 1
        assert result[0]["name"] == "owner/repo"
        assert result[0]["stars"] == 100


@pytest.mark.asyncio
async def test_github_api_404():
    with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_req:
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_req.return_value = mock_resp

        from rumbod_cli.tools.github_ import list_issues
        result = await list_issues("nonexistent/repo")
        assert "error" in result[0]


@pytest.mark.asyncio
async def test_github_api_401():
    with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_req:
        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_req.return_value = mock_resp

        from rumbod_cli.tools.github_ import list_issues
        result = await list_issues("owner/repo")
        assert "Bad credentials" in result[0].get("error", "")
