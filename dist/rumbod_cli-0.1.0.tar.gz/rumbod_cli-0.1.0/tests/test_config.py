import pytest
from rumbod_cli.config import get_config, Config

def test_config_loads():
    cfg = get_config()
    assert isinstance(cfg, Config)
    assert cfg.model.default == "nvidia:nvidia/llama-3.3-nemotron-super-49b-v1"
    assert cfg.model.temperature == 0.3
    assert cfg.model.max_tokens == 8192

def test_config_fallback_chain():
    cfg = get_config()
    assert len(cfg.model.fallback_chain) == 4
    assert all(m.startswith("nvidia:") for m in cfg.model.fallback_chain)

def test_config_spec_dir():
    cfg = get_config()
    assert cfg.spec.dir == ".rumbod/specs"

def test_config_hooks_dir():
    cfg = get_config()
    assert cfg.hooks.dir == ".rumbod/hooks"

def test_config_steering_dir():
    cfg = get_config()
    assert cfg.steering.dir == ".rumbod/steering"