import pytest
from unittest.mock import AsyncMock, patch, MagicMock
import os

# Set the environment variable before importing
os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.models import NvidiaProvider, FallbackProvider, get_provider


@pytest.mark.asyncio
async def test_nvidia_provider_chat():
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"choices": [{"message": {"content": "pong"}}]}
        mock_post.return_value = mock_resp

        p = NvidiaProvider("test-model")
        result = await p.chat([{"role": "user", "content": "ping"}])
        assert result == "pong"


@pytest.mark.asyncio
async def test_nvidia_provider_stream_chat():
    with patch("httpx.AsyncClient.stream") as mock_stream:
        mock_resp = MagicMock()
        mock_resp.__aenter__.return_value = mock_resp
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        
        # Create async iterator for aiter_lines
        async def mock_aiter():
            yield 'data: {"choices": [{"delta": {"content": "hello"}}]}'
            yield 'data: {"choices": [{"delta": {"content": " world"}}]}'
            yield "data: [DONE]"
        
        mock_resp.aiter_lines = mock_aiter
        mock_stream.return_value = mock_resp

        p = NvidiaProvider("test-model")
        chunks = []
        async for chunk in p.stream_chat([{"role": "user", "content": "ping"}]):
            chunks.append(chunk)
        assert chunks == ["hello", " world"]


@pytest.mark.asyncio
async def test_fallback_provider_chat():
    with patch("rumbod_cli.models.NvidiaProvider.chat") as mock_chat:
        mock_chat.side_effect = [
            Exception("first failed"),
            "success from second",
        ]
        provider = FallbackProvider(["nvidia:model1", "nvidia:model2"])
        result = await provider.chat([{"role": "user", "content": "test"}])
        assert result == "success from second"


@pytest.mark.asyncio
async def test_get_provider_nvidia():
    provider = get_provider("nvidia:moonshotai/kimi-k2.6")
    assert isinstance(provider, NvidiaProvider)


@pytest.mark.asyncio
async def test_get_provider_auto():
    provider = get_provider("auto")
    assert isinstance(provider, NvidiaProvider)