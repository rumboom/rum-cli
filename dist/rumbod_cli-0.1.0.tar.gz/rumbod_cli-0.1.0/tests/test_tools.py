import pytest
import os
from unittest.mock import patch

os.environ["RUMBOD_NVIDIA_API_KEY"] = "test-key-123"

from rumbod_cli.tools.shell import run_shell
from rumbod_cli.tools.git import git_status, git_diff
from rumbod_cli.tools.filesystem import read_file, write_file, list_files, glob_files


@pytest.mark.asyncio
async def test_run_shell_allowed():
    result = await run_shell("echo hello")
    assert result["stdout"].strip() == "hello"
    assert result["returncode"] == 0


@pytest.mark.asyncio
async def test_run_shell_denied():
    result = await run_shell("sudo rm -rf /")
    assert "error" in result
    # sudo is not in allowlist, so it fails there first
    assert "not in allowlist" in result["error"] or "Dangerous" in result["error"]


@pytest.mark.asyncio
async def test_run_shell_not_allowed():
    result = await run_shell("nonexistentcommand123")
    assert "error" in result
    assert "not in allowlist" in result["error"]


@pytest.mark.asyncio
async def test_git_status():
    result = await git_status()
    assert "stdout" in result


@pytest.mark.asyncio
async def test_git_diff():
    result = await git_diff()
    assert "stdout" in result


@pytest.mark.asyncio
async def test_filesystem_read_write(tmp_path):
    with patch("rumbod_cli.tools.filesystem.SECURITY_CONFIG", {"allow_outside_project": True, "allow_outside_home": True, "allow_outside_root": True, "forbid_hidden_files": False, "forbid_sensitive_extensions": False, "sensitive_extensions": [], "max_file_size": 100 * 1024 * 1024, "forbid_archive_extraction": False, "forbid_compressed_files": False}):
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello world")
        
        content = await read_file(str(test_file))
        assert content == "hello world"
        
        new_file = tmp_path / "new.txt"
        result = await write_file(str(new_file), "new content")
        assert result["ok"] is True
        assert await read_file(str(new_file)) == "new content"


@pytest.mark.asyncio
async def test_list_files(tmp_path):
    with patch("rumbod_cli.tools.filesystem.SECURITY_CONFIG", {"allow_outside_project": True, "allow_outside_home": True, "allow_outside_root": True, "forbid_hidden_files": False, "forbid_sensitive_extensions": False, "sensitive_extensions": [], "max_file_size": 100 * 1024 * 1024, "forbid_archive_extraction": False, "forbid_compressed_files": False}):
        (tmp_path / "a.txt").write_text("a")
        (tmp_path / "b.txt").write_text("b")
        files = await list_files(str(tmp_path))
        assert len(files) == 2


@pytest.mark.asyncio
async def test_glob_files(tmp_path):
    with patch("rumbod_cli.tools.filesystem.SECURITY_CONFIG", {"allow_outside_project": True, "allow_outside_home": True, "allow_outside_root": True, "forbid_hidden_files": False, "forbid_sensitive_extensions": False, "sensitive_extensions": [], "max_file_size": 100 * 1024 * 1024, "forbid_archive_extraction": False, "forbid_compressed_files": False}):
        (tmp_path / "a.py").write_text("a")
        (tmp_path / "b.py").write_text("b")
        (tmp_path / "c.txt").write_text("c")
        files = await glob_files("*.py", str(tmp_path))
        assert len(files) == 2
        assert all(f.endswith(".py") for f in files)