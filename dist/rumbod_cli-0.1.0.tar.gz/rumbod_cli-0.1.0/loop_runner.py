#!/usr/bin/env python3
"""
SAFE ANALYTICAL LOOP — report only, no auto-fix.
Generates self-referencing TODO for opencode to execute.

Pattern:
  Step 1..N-2: Fix remaining gaps (opencode reads TODO and dispatches)
  Step N-1:    Verify fixes, update github, write summaries
  Step N:      Generate new TODO list where step N is itself
"""
import ast
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

BASE = Path("/root/rumbod-cli/rumbod_cli")
GITHUB = Path("/root/rumbod-cli-github")
STATE_FILE = Path("/tmp/rumbod_improve_state.json")
TODO_FILE = Path("/tmp/rumbod_todo.md")
STATE_VERSION = 3

# ── Gap definitions ──────────────────────────────────────────────────
# Each gap: (path, category, severity, description, check_func)
SEVERITY = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}

GAPS_DEF = [
    # Error handling - apikeys.py already has proper async locking
    ("apikeys.py", "error_hdl", "low",
     "No validation, the async lock fix still works though",
     lambda c: "validate" not in c),
]

def check_syntax_ok(path):
    try:
        ast.parse(path.read_text())
        return True
    except SyntaxError:
        return False

def run_monitor_check():
    try:
        r = subprocess.run(
            ["python3", str(Path.home() / ".claude/agent-monitor/monitor.py")],
            capture_output=True, text=True, timeout=15,
        )
        return "PASSED" in r.stdout
    except Exception:
        return False

def check_all_files_compile():
    bad = []
    for f in sorted(BASE.rglob("*.py")):
        if not check_syntax_ok(f):
            bad.append(f)
    for f in sorted(Path("/root/rumbod-cli").glob("*.py")):
        if not check_syntax_ok(f):
            bad.append(f)
    return bad

def load_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {"version": STATE_VERSION, "iteration": 0, "previous_fixes": [], "rounds": []}

def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2, default=str))

def generate_todo(state, gaps, compile_errors, monitor_ok):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    iteration = state["iteration"]
    lines = []

    # Steps 1..N-2: gaps
    step = 0
    for path, cat, sev, desc, _ in gaps:
        step += 1
        p = SEVERITY.get(sev, "🟡")
        lines.append(f"### Step {step}: [{cat}] {p} {desc}")
        lines.append(f"File: `{path}`\n")

    # If compile errors, insert early
    if compile_errors:
        for i, f in enumerate(compile_errors):
            lines.insert(i, f"### Step {i+1}: [compile] 🔴 Syntax error in `{f.relative_to(Path('/root/rumbod-cli')) if hasattr(f, 'relative_to') else f}`")
            lines.insert(i+1, "")

    if not gaps and not compile_errors:
        lines.append("### All known gaps closed! 🎉")
        lines.append("")

    # Step N-1: verify
    n_minus_1 = step + 1
    lines.append(f"### Step {n_minus_1}: Verify fixes — update github, write summary")
    lines.append(f"- Compile check on {len(list(BASE.rglob('*.py')))} .py files")
    lines.append(f"- Run agent-monitor health check")
    lines.append(f"- Sync to github repo at {GITHUB}")
    lines.append(f"- Write round summary")
    lines.append("")

    # Step N: recursion
    n = n_minus_1 + 1
    lines.append(f"### Step {n}: RECURSE — loop runner will regenerate this file")
    lines.append(f"Next iteration: {iteration + 1}")
    lines.append("")
    lines.append("---")
    lines.append(f"*Self-referencing loop iteration {iteration} — {now}*")
    lines.append(f"*Gaps: {len(gaps)} | Compile errors: {len(compile_errors)} | Monitor: {'✅' if monitor_ok else '❌'}*")
    lines.append("")
    lines.append("## 🚀 Execution for opencode")
    lines.append("For each gap step above (1..N-2):")
    lines.append("- Read the file")
    lines.append("- Apply the fix using tools available")
    lines.append("- Verify syntax with `python3 -c \"compile(open(...).read(), ..., 'exec')\"`")
    lines.append("- After all fixes, do Step N-1 (verify + github sync)")
    lines.append("- Step N happens automatically — loop_runner rewrites this file")
    lines.append("")
    lines.append("## ⚠️  Root cause detection on interrupt")
    lines.append("If interrupted:")
    lines.append(f"1. Check {STATE_FILE} for last iteration number")
    lines.append(f"2. Check /tmp/rumbod-loop.log for errors")
    lines.append("3. If opencode context exhausted: report to user with iteration number")
    lines.append("4. Resume by reading this file and continuing from step 1")

    return "\n".join(lines)

def sync_to_github():
    for f in BASE.rglob("*.py"):
        rel = f.relative_to(BASE)
        dest = GITHUB / "rumbod_cli" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if f.read_bytes() != (dest.read_bytes() if dest.exists() else b""):
            dest.write_bytes(f.read_bytes())
    runner = Path("/root/rumbod-cli/loop_runner.py")
    dest = GITHUB / "loop_runner.py"
    if runner.read_bytes() != (dest.read_bytes() if dest.exists() else b""):
        dest.write_bytes(runner.read_bytes())

def main():
    state = load_state()
    iteration = state["iteration"]
    compile_history = state.get("compile_history", [])

    while True:
        iteration += 1
        state["iteration"] = iteration

        # ── Analyze (no modifications) ──
        gaps = []
        for path, cat, sev, desc, check in GAPS_DEF:
            full_path = Path(BASE / path) if (BASE / path).exists() else Path(GITHUB / "rumbod_cli" / path)
            if full_path.exists():
                content = full_path.read_text()
                if check(content):
                    gaps.append((path, cat, sev, desc, check))

        compile_errors = check_all_files_compile()
        monitor_ok = run_monitor_check()

        # ── Track compile history ──
        if compile_errors:
            compile_history.append((iteration, [str(f) for f in compile_errors]))
            compile_history = compile_history[-10:]
            state["compile_history"] = compile_history

        # ── Generate self-referencing TODO ──
        todo = generate_todo(state, gaps, compile_errors, monitor_ok)
        TODO_FILE.write_text(todo)

        # ── Status line ──
        now = datetime.now(timezone.utc).strftime("%H:%M:%S")
        total_gaps = len(gaps)
        total_compile = len(compile_errors)
        tag = f"gaps={total_gaps}, compile={total_compile}, monitor={'OK' if monitor_ok else 'FAIL'}"
        print(f"[{now}] Iter {iteration}: {tag}")
        sys.stdout.flush()

        # ── Persist ──
        state["last_status"] = tag
        state["last_updated"] = str(datetime.now(timezone.utc))
        save_state(state)

        # ── Sleep ──
        if compile_errors:
            time.sleep(3)
        elif gaps:
            time.sleep(5)
        else:
            time.sleep(60)

if __name__ == "__main__":
    main()
