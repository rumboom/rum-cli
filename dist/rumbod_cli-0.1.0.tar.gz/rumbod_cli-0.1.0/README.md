# rumbod-cli

Kiro-inspired agent CLI with NVIDIA NIM free tier as primary provider.

## Overview

rumbod-cli is a powerful AI agent command-line interface designed for developers who want to build, test, and deploy AI-powered features. It combines the best practices from Kiro's development workflow with NVIDIA's cutting-edge NIM (NVIDIA Inference Microservices) platform, providing a seamless experience for building intelligent applications.

## Key Features

### 1. Interactive TUI
- **Full-screen chat interface** with real-time messaging
- **15+ slash commands** for quick access to all functionality
- **Model switching**, **web search**, **sub-agent spawning**, **API usage tracking**, and more
- **Persistent conversation memory** across sessions

### 2. Sub-Agent System
- **Plan→execute loops** with JSON repair and 5-attempt recovery
- **Tool-based execution** with 20+ built-in tools
- **Context-aware sub-agents** that can work independently
- **Error handling and retry mechanisms** for robust operation

### 3. Web Tools
- **Web search** (DuckDuckGo Lite, ad-filtered)
- **Web fetch** (httpx + BeautifulSoup for content extraction)
- **Registered as sub-agent tools** and slash commands
- **Safe browsing** with content filtering

### 4. NVIDIA NIM First
- **NvidiaProvider**, **FallbackProvider**, **MultiKeyProvider**
- **Automatic key rotation** and fallback chain
- **Tenacity retry** with exponential backoff
- **Token usage tracking** and cost optimization

### 5. Provider Configuration
- **Separate models** for main agent vs sub-agents
- **Round-robin** provider selection
- **Provider testing** and validation
- **Runtime configuration** via CLI/TUI commands

### 6. API Key Management
- **Persistent key store** (`.rumbod/apikeys.json`)
- **CRUD operations** for API keys
- **Live NIM testing** for key validation
- **Round-robin key rotation** for redundancy

### 7. API Usage Tracking
- **Per-model token counters**
- **Persistent tracking** across sessions and sub-agents
- **Usage reports** and analytics
- **Cost optimization** recommendations

### 8. Conversation Memory
- **JSONL per project** for conversation storage
- **Session management** with `/sessions` command
- **Memory compaction** to reduce storage usage
- **Cross-session continuity** with `--session` flag

### 9. Specs / Hooks / Steering / MCP / Powers / Task Loop
- **Kiro-inspired developer agent pattern**
- **Feature specifications** for structured requirements
- **File watcher hooks** for automated actions
- **Context injection rules** for project-specific behavior
- **Model Context Protocol** client support
- **Capability bundles** for reusable functionality
- **Task loop** for iterative development

## Quick Start

### Installation
```bash
# Clone the repository
git clone <repo>
cd rumbod-cli

# Install dependencies
uv sync

# Set your NVIDIA API key (required)
export RUMBOD_NVIDIA_API_KEY="nvapi-..."
```

### Basic Usage
```bash
# Interactive TUI - Full-featured chat interface
rum-interactive-cli

# CLI chat with project context
rum-cli chat "explain this codebase"

# Spawn a sub-agent for complex tasks
rum-cli spawn "find all TODO comments and report"

# Manage providers
rum-cli provider set-main nvidia/llama-3.3-nemotron-super-49b-v1
rum-cli provider set-sub nvidia/nvidia-nemotron-nano-9b-v2
rum-cli provider list
rum-cli provider test

# API usage tracking
rum-cli apiusage

# API key management
rum-cli apikey add nvapi-xxxx-xxxx
rum-cli apikey test
```

### Configuration
```bash
# Copy example configuration
cp rumbod.toml.example rumbod.toml

# Edit rumbod.toml with your preferences
# (or rely on defaults)
```

## Directory Structure
```
.rumbod/
├── apikeys.json          # Persistent API key storage
├── logs/                 # Execution logs
│   ├── monitor.jsonl     # Monitor logs
│   └── events.jsonl      # Event logs
├── providers.json        # Provider configuration
├── specs/                # Feature specifications
│   ├── feat-xxxx-xxxx.md # Specification files
├── hooks/                # File watcher hooks
│   ├── *.toml           # Hook configuration files
├── steering/             # Context injection rules
│   ├── *.toml           # Steering rule files
├── powers/               # Capability bundles
│   ├── *.json           # Power configuration files
├── mcp/                  # MCP server configurations
│   ├── *.json           # MCP server configs
└── sessions/             # Conversation sessions
    ├── *.jsonl          # Session files
```

## Commands

### rum-interactive-cli
Full-featured TUI with all commands and slash commands:

| Command | Description |
|---------|-------------|
| `/help` | Show help and available commands |
| `/model <model>` | Switch to a different model |
| `/web_search <query>` | Search the web |
| `/spawn <task>` | Spawn a sub-agent |
| `/apiusage` | Show API usage statistics |
| `/apikey` | API key management |
| `/provider` | Provider configuration management |
| `/sessions` | List and manage conversation sessions |
| `/compact` | Clear old session data |

### rum-cli
CLI-based commands for programmatic access:

| Command | Description |
|---------|-------------|
| `rum-cli chat <msg>` | CLI chat with context + memory |
| `rum-cli spawn <task>` | Deploy sub-agent |
| `rum-cli doctor` | Verify NIM connectivity |
| `rum-cli models` | List free NIM models |
| `rum-cli apiusage` | Token usage report |
| `rum-cli apikey` | API key management |
| `rum-cli provider` | Provider config management |
| `rum-cli conversation` | Memory management |

## Configuration File

### rumbod.toml

```toml
# Main configuration
[model]
default = "nvidia/llama-3.3-nemotron-super-49b-v1"

# Provider configuration
[providers.main]
model = "nvidia/llama-3.3-nemotron-super-49b-v1"
role = "main"

[providers.subagent]
model = "nvidia/nvidia-nemotron-nano-9b-v2"
role = "subagent"

# API key configuration
[api_keys]
primary = "env:RUMBOD_NVIDIA_API_KEY"
fallback = "key:0"

# Task loop configuration
[task_loop]
max_iterations = 20
timeout_per_step = 120

# Logging configuration
[logging]
level = "info"
file = ".rumbod/logs/monitor.jsonl"
```

## Development

### Running Tests
```bash
# Run all tests
python3 -m pytest tests/ -v

# Run specific test modules
python3 -m pytest tests/test_subagent.py -v
python3 -m pytest tests/test_models.py -v
```

### Adding New Tools
1. Create a new file in `rumbod_cli/tools/` (e.g., `new_tool.py`)
2. Implement async functions with proper error handling
3. Add the tool to `rumbod_cli/task_loop.py` TOOLS dictionary
4. Add tool to `rumbod_cli/subagent.py` _SUB_TOOLS dictionary
5. Write tests in `tests/test_tools.py`

### Adding New Commands
1. Add command to `rumbod_cli/cli.py` using Typer decorators
2. Implement command logic with proper error handling
3. Add command to help documentation
4. Write tests if applicable

### Contributing
1. Fork the repository
2. Create a feature branch
3. Implement your changes
4. Write tests for new functionality
5. Update documentation
6. Submit a pull request

## Troubleshooting

### Common Issues

#### "ModuleNotFoundError: No module named 'watchfiles'"
```bash
pip install watchfiles --break-system-packages
```

#### "ModuleNotFoundError: No module named 'tomli'"
```bash
pip install tomli --break-system-packages
```

#### "ModuleNotFoundError: No module named 'textual'"
```bash
pip install textual --break-system-packages
```

#### "ModuleNotFoundError: No module named 'rich'"
```bash
pip install rich --break-system-packages
```

### Getting Help
- **GitHub Issues**: Report bugs and request features
- **Documentation**: Check the docs/ directory for detailed guides
- **Community**: Join the discussion forum for tips and best practices

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Inspired by Kiro's development workflow
- Built on NVIDIA NIM platform
- Thanks to the open-source community for valuable tools and libraries
- Special thanks to all contributors and testers