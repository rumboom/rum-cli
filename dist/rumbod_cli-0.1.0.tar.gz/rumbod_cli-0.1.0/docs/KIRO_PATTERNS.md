# Kiro IDE Patterns Analysis

This document extracts architectural patterns from the Kiro IDE (kirodotdev/Kiro) for replication in rumbod-cli.

## 1. Specs System (`.kiro/specs/`)

### Structure
Each spec lives in `.kiro/specs/<feature-name>/` with three files:
- `requirements.md` - User stories, acceptance criteria (EARS format)
- `design.md` - Architecture, components, interfaces, data models
- `tasks.md` - Implementation plan with checkboxes, requirement traceability

### Frontmatter
Specs use YAML frontmatter for metadata:
```yaml
---
id: feat-xxx
title: Feature Title
status: draft|approved|implemented|verified
created: ISO8601
updated: ISO8601
acceptance_criteria: [...]
---
```

### Lifecycle
```
draft → approved → implemented → verified
```
Each transition is explicit. Tasks reference requirements by ID.

## 2. Hooks System (`.kiro/hooks/`)

### Trigger Types
- `file_change` - Watch glob patterns, execute on match
- `scheduled` - Cron-based execution
- `event` - GitHub events, CLI commands

### Configuration (TOML)
```toml
[hook]
name = "lint-on-save"
trigger = { type = "file_change", patterns = ["**/*.py", "**/*.ts"] }
command = "ruff check {file}"
async = true
```

### Execution
- Async by default (fire-and-forget)
- Sync option for blocking operations
- Variable interpolation: `{file}`, `{cwd}`, `{timestamp}`

## 3. Steering System (`.kiro/steering/`)

### Glob Injection
Markdown files with frontmatter globs:
```markdown
---
globs:
  - "**/*.py"
  - "**/tests/**"
---
# Python Coding Standards
...
```

### Matching Logic
- Load all steering files at startup
- For each file operation, match path against globs
- Inject matched content into system prompt
- Multiple matches concatenated

## 4. MCP Integration (`.kiro/mcp/`)

### Server Types
- **stdio** - Local subprocess (most common)
- **SSE** - Remote HTTP streaming

### Tool Registry
- Connect to server → `initialize` → `tools/list`
- Cache tool schemas with server prefix: `server.tool`
- Call via `tools/call` with JSON-RPC 2.0

### Configuration
```json
{
  "servers": {
    "filesystem": { "command": ["npx", "-y", "@modelcontextprotocol/server-filesystem", "/workspace"] }
  }
}
```

## 5. Powers (`.kiro/powers/`)

### Bundle Concept
A "power" combines:
- Context files (auto-injected)
- Tool allowlist
- Prompt fragment (prepended to system prompt)

### TOML Format
```toml
[power]
name = "python-dev"
description = "Python development power"
context_files = ["pyproject.toml", "src/**/*.py"]
tools = ["shell", "git", "tests", "filesystem"]
prompt_fragment = "Follow PEP 8. Use type hints. Prefer pytest."
```

## 6. Agent Task Loop

### Plan → Act → Observe → Refine
1. **Plan** - LLM generates structured JSON plan with tool calls
2. **Act** - Execute tools sequentially
3. **Observe** - Collect results, check for completion
4. **Refine** - Re-plan based on observations, loop

### Plan Format
```json
[
  {"step": 1, "tool": "shell", "args": {"cmd": "pytest"}, "expected": "tests pass"},
  {"step": 2, "tool": "write_file", "args": {"path": "foo.py", "content": "..."}, "expected": "file created"}
]
```

### Termination
- `done: true` in step
- Max iterations reached
- Error threshold exceeded

## 7. Model Provider Abstraction

### Interface
```python
class ModelProvider:
    async def chat(messages: list[dict], **params) -> str
    async def stream_chat(messages: list[dict], **params) -> AsyncIterator[str]
```

### Fallback Chain
- Primary model → fallback1 → fallback2 → ...
- Rotate on 429, 5xx, timeout
- Configurable per task type (coding, chat, analysis)

## 8. Key Architectural Decisions to Replicate

| Pattern | Kiro Implementation | Rumbod Adaptation |
|---------|---------------------|-------------------|
| Config | JSON + env vars | TOML + pydantic-settings |
| Specs | Markdown + YAML FM | Same, in `.rumbod/specs/` |
| Hooks | TOML + watchfiles | Same, in `.rumbod/hooks/` |
| Steering | Markdown + globs FM | Same, in `.rumbod/steering/` |
| MCP | JSON-RPC stdio/SSE | Same, minimal client |
| Powers | TOML bundles | Same, in `.rumbod/powers/` |
| Task Loop | Plan/Act/Observe | Same, async with tools |
| Models | Provider abstraction | NVIDIA NIM first + fallbacks |

## 9. Differences from Kiro

| Aspect | Kiro | Rumbod |
|--------|------|--------|
| Language | TypeScript/Node | Python 3.11+ |
| Primary Provider | AWS Bedrock | NVIDIA NIM (free tier) |
| Key Rotation | AWS IAM | Hardcoded list (dev) |
| UI | VS Code Extension | CLI (Typer + Rich) |
| Package Manager | npm/pnpm | uv |
| Testing | Jest + fast-check | pytest + hypothesis |