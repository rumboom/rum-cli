from dataclasses import dataclass
from typing import Any
import json, os, asyncio

@dataclass
class MCPServer:
    name: str
    command: list[str]
    env: dict = None

class MCPClient:
    def __init__(self):
        self.servers: dict[str, MCPServer] = {}
        self.tools: dict[str, Any] = {}

    def add_server(self, name: str, command: list[str], env: dict = None):
        self.servers[name] = MCPServer(name, command, env or {})

    async def connect_stdio(self, name: str):
        server = self.servers[name]
        proc = await asyncio.create_subprocess_exec(
            *server.command,
            env={**os.environ, **(server.env or {})},
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        # send initialize
        init = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}}}
        proc.stdin.write((json.dumps(init) + "\n").encode())
        await proc.stdin.drain()
        # read response (simplified)
        line = await proc.stdout.readline()
        # list tools
        list_tools = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
        proc.stdin.write((json.dumps(list_tools) + "\n").encode())
        await proc.stdin.drain()
        line = await proc.stdout.readline()
        try:
            resp = json.loads(line)
            for t in resp.get("result", {}).get("tools", []):
                self.tools[f"{name}.{t['name']}"] = {"server": name, "schema": t}
        except Exception:
            pass
        return proc

    async def call_tool(self, server: str, tool: str, args: dict) -> Any:
        proc = await self.connect_stdio(server)
        call = {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": tool, "arguments": args}}
        proc.stdin.write((json.dumps(call) + "\n").encode())
        await proc.stdin.drain()
        line = await proc.stdout.readline()
        proc.terminate()
        try:
            return json.loads(line).get("result")
        except Exception:
            return None