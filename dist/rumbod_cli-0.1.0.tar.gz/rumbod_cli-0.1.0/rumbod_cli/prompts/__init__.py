"""Prompts package for rumbod-cli."""
from rumbod_cli.prompts.system_prompts import SYSTEM_PROMPTS

__all__ = ["SYSTEM_PROMPTS"]