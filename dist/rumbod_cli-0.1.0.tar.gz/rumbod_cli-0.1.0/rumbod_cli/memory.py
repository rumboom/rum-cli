import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

CONVERSATIONS_DIR = Path(".rumbod/logs/conversations")


def _ensure_dir() -> Path:
    CONVERSATIONS_DIR.mkdir(parents=True, exist_ok=True)
    return CONVERSATIONS_DIR


def _project_key() -> str:
    cwd = Path.cwd().resolve()
    parts = [p for p in cwd.parts if p != "/"]
    suffix = parts[-2:] if len(parts) >= 2 else parts
    digest = hashlib.md5(str(cwd).encode()).hexdigest()[:8]
    return "_".join(suffix) + "_" + digest


def _session_path(session_id: Optional[str] = None) -> Path:
    if session_id is None:
        session_id = _project_key()
    return _ensure_dir() / f"{session_id}.jsonl"


def load_conversation(session_id: Optional[str] = None) -> list[dict]:
    path = _session_path(session_id)
    messages: list[dict] = []
    if path.exists():
        with path.open() as f:
            for line in f:
                line = line.strip()
                if line:
                    messages.append(json.loads(line))
    return messages


def append_message(
    role: str, content: str, session_id: Optional[str] = None
) -> None:
    path = _session_path(session_id)
    entry = {
        "role": role,
        "content": content,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    with path.open("a") as f:
        f.write(json.dumps(entry) + "\n")


def clear_conversation(session_id: Optional[str] = None) -> None:
    path = _session_path(session_id)
    if path.exists():
        path.unlink()


def list_sessions() -> list[dict]:
    _ensure_dir()
    sessions: list[dict] = []
    for path in sorted(CONVERSATIONS_DIR.glob("*.jsonl"), reverse=True):
        with path.open() as f:
            count = sum(1 for _ in f)
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        sessions.append(
            {
                "id": path.stem,
                "messages": count,
                "updated": mtime.isoformat(),
                "path": str(path),
            }
        )
    return sessions
