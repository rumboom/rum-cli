import json
import threading
import time
from pathlib import Path

_USAGE_FILE = Path(".rumbod/logs/apiusage.json")
_FILE_LOCK = threading.Lock()


def _ensure_file():
    _USAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not _USAGE_FILE.exists():
        _write({
            "total_prompt_tokens": 0,
            "total_completion_tokens": 0,
            "total_tokens": 0,
            "total_calls": 0,
            "models": {},
            "since": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        })


def _read() -> dict:
    _ensure_file()
    try:
        return json.loads(_USAGE_FILE.read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        return _reset_data()


def _write(data: dict):
    _USAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
    _USAGE_FILE.write_text(json.dumps(data, indent=2))


def _reset_data() -> dict:
    data = {
        "total_prompt_tokens": 0,
        "total_completion_tokens": 0,
        "total_tokens": 0,
        "total_calls": 0,
        "models": {},
        "since": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _write(data)
    return data


def record_usage(
    prompt_tokens: int,
    completion_tokens: int,
    model: str = "unknown",
):
    with _FILE_LOCK:
        data = _read()
        data["total_prompt_tokens"] += prompt_tokens
        data["total_completion_tokens"] += completion_tokens
        data["total_tokens"] += prompt_tokens + completion_tokens
        data["total_calls"] += 1
        model_key = model
        if model_key not in data["models"]:
            data["models"][model_key] = {
                "calls": 0,
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
            }
        data["models"][model_key]["calls"] += 1
        data["models"][model_key]["prompt_tokens"] += prompt_tokens
        data["models"][model_key]["completion_tokens"] += completion_tokens
        data["models"][model_key]["total_tokens"] += prompt_tokens + completion_tokens
        _write(data)


def get_usage_summary() -> dict:
    with _FILE_LOCK:
        return _read()


def format_usage(data: dict | None = None) -> str:
    if data is None:
        data = get_usage_summary()
    lines = [
        f"Total API calls:  {data['total_calls']}",
        f"Prompt tokens:    {data['total_prompt_tokens']:,}",
        f"Completion tokens: {data['total_completion_tokens']:,}",
        f"Total tokens:     {data['total_tokens']:,}",
        f"Since:            {data.get('since', 'N/A')}",
    ]
    models = data.get("models", {})
    if models:
        lines.append("")
        lines.append("Per-model breakdown:")
        for m, stats in sorted(models.items()):
            lines.append(
                f"  {m}: {stats['calls']} calls, "
                f"{stats['prompt_tokens']:,} prompt + "
                f"{stats['completion_tokens']:,} completion = "
                f"{stats['total_tokens']:,} total"
            )
    return "\n".join(lines)


def reset_usage():
    with _FILE_LOCK:
        _reset_data()
