import asyncio
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from rumbod_cli.context import scan_project, build_system_prompt
from rumbod_cli.models import get_provider, normalize_model
from rumbod_cli.providers import get_next_provider_for_role
from rumbod_cli.tools.shell import run_shell
from rumbod_cli.tools.git import git_status, git_diff
from rumbod_cli.tools.tests import run_tests
from rumbod_cli.tools.websearch import web_search, web_fetch
from rumbod_cli.tools.filesystem import read_file, write_file, list_files, glob_files
from rumbod_cli.tools.file import (
    read_json_file,
    write_json_file,
    find_files,
    get_file_info,
    copy_file,
    move_file,
    delete_file,
    create_directory,
    list_directory,
    search_text_in_files,
)
from rumbod_cli.tools.process import (
    run_process,
    list_processes,
    get_process_info,
    kill_process,
    monitor_process,
    run_script,
    check_port,
    get_system_info,
)
from rumbod_cli.tools.network import (
    check_host,
    ping_host,
    resolve_dns,
    http_request,
    https_check,
    port_scan,
    get_ip_info,
    test_connectivity,
)

_SUB_TOOLS = {
    # Original tools
    "shell": {"fn": run_shell, "desc": "Run shell command"},
    "git_status": {"fn": git_status, "desc": "Git status"},
    "git_diff": {"fn": git_diff, "desc": "Git diff"},
    "run_tests": {"fn": run_tests, "desc": "Run test suite"},
    "web_search": {"fn": web_search, "desc": "Web search"},
    "web_fetch": {"fn": web_fetch, "desc": "Fetch and read a URL"},
    "read_file": {"fn": read_file, "desc": "Read file"},
    "write_file": {"fn": write_file, "desc": "Write file"},
    "list_files": {"fn": list_files, "desc": "List files"},
    "glob_files": {"fn": glob_files, "desc": "Glob files"},
    # New file tools
    "read_json_file": {"fn": read_json_file, "desc": "Read JSON file"},
    "write_json_file": {"fn": write_json_file, "desc": "Write JSON file"},
    "find_files": {"fn": find_files, "desc": "Find files matching pattern"},
    "get_file_info": {"fn": get_file_info, "desc": "Get file information"},
    "copy_file": {"fn": copy_file, "desc": "Copy file"},
    "move_file": {"fn": move_file, "desc": "Move file"},
    "delete_file": {"fn": delete_file, "desc": "Delete file"},
    "create_directory": {"fn": create_directory, "desc": "Create directory"},
    "list_directory": {"fn": list_directory, "desc": "List directory contents"},
    "search_text_in_files": {"fn": search_text_in_files, "desc": "Search text in files"},
    # New process tools
    "run_process": {"fn": run_process, "desc": "Run process with timeout"},
    "list_processes": {"fn": list_processes, "desc": "List running processes"},
    "get_process_info": {"fn": get_process_info, "desc": "Get process information"},
    "kill_process": {"fn": kill_process, "desc": "Kill process"},
    "monitor_process": {"fn": monitor_process, "desc": "Monitor process in real-time"},
    "run_script": {"fn": run_script, "desc": "Run Python script"},
    "check_port": {"fn": check_port, "desc": "Check if port is in use"},
    "get_system_info": {"fn": get_system_info, "desc": "Get system information"},
    # New network tools
    "check_host": {"fn": check_host, "desc": "Check if host is reachable"},
    "ping_host": {"fn": ping_host, "desc": "Ping host"},
    "resolve_dns": {"fn": resolve_dns, "desc": "Resolve DNS for host"},
    "http_request": {"fn": http_request, "desc": "Make HTTP request"},
    "https_check": {"fn": https_check, "desc": "Check HTTPS URL"},
    "port_scan": {"fn": port_scan, "desc": "Scan ports on host"},
    "get_ip_info": {"fn": get_ip_info, "desc": "Get IP address information"},
    "test_connectivity": {"fn": test_connectivity, "desc": "Test connectivity to host"},
}


@dataclass
class SubAgentConfig:
    model: str = "auto"
    max_iter: int = 10
    timeout: float = 120.0
    spec_id: str | None = None
    tools: list[str] | None = None
    on_step: Callable[[dict, str], None] | None = None
    on_done: Callable[["SubAgentResult"], None] | None = None


@dataclass
class SubAgentResult:
    success: bool
    summary: str
    history: list
    iterations: int
    error: str | None = None


def _extract_json(text: str) -> str:
    text = text.strip()
    lines = text.split("\n")
    if lines and lines[0].startswith("```"):
        text = "\n".join(lines[1:])
    lines = text.split("\n")
    if lines and lines[-1].startswith("```"):
        text = "\n".join(lines[:-1])
    text = text.strip()
    start = text.find("[")
    end = text.rfind("]")
    if start != -1 and end != -1 and end > start:
        text = text[start : end + 1]
    return text


def _unwrap_naked_dict(text: str) -> str:
    text = text.strip()
    if not text.startswith("["):
        return text
    import re as _re
    keys = "(?:step|tool|args|expected|done)"
    m = _re.match(r'\[\s*("' + keys + r'")', text)
    if not m:
        return text
    depth = 0
    in_str = False
    escape = False
    for i, ch in enumerate(text):
        if escape:
            escape = False
            continue
        if ch == "\\" and in_str:
            escape = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                inner = text[1:i]
                inner = inner.rstrip("}")
                return "[{" + inner + "}]"
    return text


def _repair_json(text: str) -> str:
    for attempt in range(5):
        try:
            json.loads(text)
            return text
        except json.JSONDecodeError:
            pass
        if attempt == 0:
            import re as _re
            text = _re.sub(r',\s*,', ',', text)
            text = _re.sub(r',\s*}', '}', text)
            text = _re.sub(r',\s*]', ']', text)
        elif attempt == 1:
            text = _unwrap_naked_dict(text)
        elif attempt == 2:
            text = text.replace("'", '"')
        elif attempt == 3:
            text = _re.sub(r',?\s*}\]?\s*$', '}]', text.strip())
        else:
            text = text.replace("'", '"')
    return text


async def spawn_agent(task: str, config: SubAgentConfig | None = None) -> SubAgentResult:
    if config is None:
        config = SubAgentConfig()
    
    # Validate input parameters
    if not task or not isinstance(task, str):
        return SubAgentResult(
            success=False, summary="Invalid task: must be a non-empty string", history=[],
            iterations=0, error="invalid task",
        )
    
    if not isinstance(config, SubAgentConfig):
        return SubAgentResult(
            success=False, summary="Invalid configuration", history=[],
            iterations=0, error="invalid config",
        )
    
    try:
        ctx = scan_project(Path.cwd())
    except Exception as e:
        return SubAgentResult(
            success=False, summary=f"Failed to scan project: {str(e)}", history=[],
            iterations=0, error=f"project scan: {str(e)}",
        )
    
    # Get provider with better error handling
    if config.model == "auto":
        try:
            result = await get_next_provider_for_role("subagent")
            if result:
                model, api_key = result
                provider = get_provider(normalize_model(model), api_key=api_key)
            else:
                provider = get_provider("auto")
        except Exception as e:
            return SubAgentResult(
                success=False, summary=f"Failed to get sub-agent provider: {str(e)}", history=[],
                iterations=0, error=f"provider: {str(e)}",
            )
    else:
        try:
            provider = get_provider(config.model)
        except Exception as e:
            return SubAgentResult(
                success=False, summary=f"Failed to get provider: {str(e)}", history=[],
                iterations=0, error=f"provider: {str(e)}",
            )
    
    history: list[dict] = []
    tool_map = {k: v for k, v in _SUB_TOOLS.items() if config.tools is None or k in config.tools}
    tool_descs = ", ".join(tool_map.keys())

    base_system = build_system_prompt(ctx, "subagent")
    system = f"""{base_system}

You are a sub-agent spawned to complete a specific delegated task.
Available tools: {tool_descs}.
You MUST reason step by step and return a JSON plan array.
Each plan item: {{"step": int, "tool": "tool_name", "args": {{}}, "expected": "what this step achieves", "done": false}}
Set "done": true on the FINAL step when the task is complete.
IMPORTANT: When the task is done, the last step's "expected" field should contain a concise summary of what was accomplished."""

    if config.spec_id:
        try:
            from rumbod_cli.spec import get_spec as _get_spec
            sp = _get_spec(config.spec_id)
            if sp:
                system += f"\n\nActive Spec: {sp.title}\n{sp.content}"
        except Exception as e:
            print(f"[WARN] Failed to load spec {config.spec_id}: {str(e)}")

    deadline = time.monotonic() + config.timeout
    iter_count = 0
    parse_failures = 0

    while iter_count < config.max_iter:
        if time.monotonic() > deadline:
            return SubAgentResult(
                success=False, summary="Sub-agent timed out", history=history,
                iterations=iter_count, error="timeout",
            )

        plan_prompt = (
            f"Task: {task}\n"
            f"Completed steps: {json.dumps(history[-5:])}\n\n"
            "Return a JSON array of plan steps for the NEXT work to complete the task. "
            "IMPORTANT: Return ONLY valid JSON with no markdown fences, no explanation. "
            "If the task is already done, return [{\"step\": 1, \"tool\": \"shell\", \"args\": {\"cmd\": \"echo done\"}, \"expected\": \"<summary>\", \"done\": true}]"
        )

        try:
            plan_text = await asyncio.wait_for(
                provider.chat([{"role": "system", "content": system}, {"role": "user", "content": plan_prompt}]),
                timeout=config.timeout,
            )
        except asyncio.TimeoutError:
            if history:
                break
            return SubAgentResult(
                success=False, summary="Sub-agent failed to start", history=history,
                iterations=iter_count, error="model timeout",
            )
        except Exception as e:
            return SubAgentResult(
                success=False, summary=f"Model error: {str(e)}", history=history,
                iterations=iter_count, error=str(e),
            )

        plan_text = _repair_json(_extract_json(plan_text))
        try:
            plan = json.loads(plan_text)
            if isinstance(plan, dict):
                plan = [plan]
            if not isinstance(plan, list):
                raise ValueError("response is not a list")
        except (json.JSONDecodeError, ValueError):
            parse_failures += 1
            if parse_failures >= 3:
                if history:
                    break
                return SubAgentResult(
                    success=False, summary="Failed to parse agent response after 3 retries",
                    history=history, iterations=iter_count, error=plan_text[:300],
                )
            system += (
                f"\n\n[parse error {parse_failures}] Your response was not valid JSON. "
                "Return ONLY a raw JSON array with no markdown, no commentary."
            )
            continue

        for step in plan:
            if not isinstance(step, dict):
                continue
            step_num = step.get("step", iter_count + 1)
            tool_name = step.get("tool", "")
            args = step.get("args", {})
            expected = step.get("expected", "")
            is_done = step.get("done", False)

            if tool_name not in tool_map:
                result_text = f"Unknown tool: {tool_name}. Available: {tool_descs}"
            else:
                try:
                    raw = await tool_map[tool_name]["fn"](**args)
                    result_text = str(raw)[:2000]
                except Exception as e:
                    result_text = f"Error: {str(e)}"

            step_record = {"step": step_num, "tool": tool_name, "args": args, "result": result_text}
            history.append(step_record)

            if config.on_step:
                try:
                    config.on_step(step_record, expected)
                except Exception as e:
                    print(f"[WARN] Step callback failed: {str(e)}")

            if is_done:
                summary = expected or result_text[:300]
                return SubAgentResult(
                    success=True, summary=summary, history=history,
                    iterations=iter_count + 1,
                )

        iter_count += 1

    if history:
        last = history[-1]
        summary = last.get("result", "completed")[:300]
        return SubAgentResult(
            success=True, summary=summary, history=history,
            iterations=iter_count,
        )

    return SubAgentResult(
        success=False, summary="No work was performed", history=history,
        iterations=0, error="empty",
    )
