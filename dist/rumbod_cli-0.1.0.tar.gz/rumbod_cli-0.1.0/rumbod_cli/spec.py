from pathlib import Path
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import yaml, uuid

SPEC_DIR = Path(".rumbod/specs")
SPEC_DIR.mkdir(parents=True, exist_ok=True)

@dataclass
class Spec:
    id: str
    title: str
    status: str = "draft"
    created: str = ""
    updated: str = ""
    acceptance_criteria: list = None
    content: str = ""

    def __post_init__(self):
        if self.acceptance_criteria is None:
            self.acceptance_criteria = []
        now = datetime.now(timezone.utc).isoformat()
        if not self.created:
            self.created = now
        self.updated = now

    def path(self) -> Path:
        slug = self.title.lower().replace(" ", "-")[:50]
        return SPEC_DIR / f"{self.id}-{slug}.md"

    def save(self):
        fm = {k: v for k, v in asdict(self).items() if k != "content"}
        txt = "---\n" + yaml.dump(fm, sort_keys=False) + "---\n" + self.content
        self.path().write_text(txt)

    @classmethod
    def load(cls, path: Path):
        txt = path.read_text()
        if txt.startswith("---"):
            parts = txt.split("---", 2)
            fm = yaml.safe_load(parts[1])
            content = parts[2].strip() if len(parts) > 2 else ""
            fm["content"] = content
            return cls(**fm)
        return cls(id=path.stem, title=path.stem, content=txt)

def new_spec(title: str) -> Spec:
    title = title.strip()
    if not title:
        raise ValueError("Spec title cannot be empty")
    spec = Spec(id=f"feat-{uuid.uuid4().hex[:6]}", title=title, content="# Spec\n\n## Acceptance Criteria\n- [ ] \n")
    spec.save()
    return spec

def list_specs() -> list[Spec]:
    specs = []
    for p in SPEC_DIR.glob("*.md"):
        try:
            specs.append(Spec.load(p))
        except Exception:
            continue
    return sorted(specs, key=lambda s: s.updated, reverse=True)

def get_spec(spec_id: str) -> Spec | None:
    for p in SPEC_DIR.glob(f"{spec_id}-*.md"):
        return Spec.load(p)
    return None

def approve_spec(spec_id: str) -> Spec | None:
    spec = get_spec(spec_id)
    if spec:
        spec.status = "approved"
        spec.save()
    return spec

def verify_spec(spec_id: str) -> Spec | None:
    spec = get_spec(spec_id)
    if spec:
        spec.status = "verified"
        spec.save()
    return spec