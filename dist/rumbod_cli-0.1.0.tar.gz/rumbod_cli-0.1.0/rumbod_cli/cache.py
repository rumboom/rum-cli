import json
import hashlib
import time
import asyncio
from pathlib import Path
from typing import Any, Dict, Optional, Union

CACHE_DIR = Path(".rumbod/cache")
CACHE_DIR.mkdir(parents=True, exist_ok=True)

CACHE_EXPIRY = {
    "short": 300,      # 5 minutes
    "medium": 3600,    # 1 hour
    "long": 86400,     # 24 hours
}
class CacheEntry:
    def __init__(self, key: str, value: Any, expiry: str = "medium"):
        self.key = key
        self.value = value
        self.expiry = expiry
        self.created_at = time.time()
        self.expires_at = self.created_at + CACHE_EXPIRY.get(expiry, CACHE_EXPIRY["medium"])
    
    def is_expired(self) -> bool:
        return time.time() > self.expires_at
    
    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "value": self.value,
            "expiry": self.expiry,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "CacheEntry":
        entry = cls(data["key"], data["value"], data["expiry"])
        entry.created_at = data["created_at"]
        entry.expires_at = data["expires_at"]
        return entry
class CacheManager:
    def __init__(self, cache_dir: Path = CACHE_DIR):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_cache_file(self, key: str) -> Path:
        # Create a safe filename from the key
        safe_key = hashlib.md5(key.encode()).hexdigest()
        return self.cache_dir / f"{safe_key}.cache"
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from cache."""
        cache_file = self._get_cache_file(key)
        if not cache_file.exists():
            return default
        
        try:
            with open(cache_file, "r") as f:
                data = json.load(f)
            
            entry = CacheEntry.from_dict(data)
            
            if entry.is_expired():
                # Delete expired cache entry
                cache_file.unlink()
                return default
            
            return entry.value
        except Exception:
            # If cache is corrupted, delete it and return default
            try:
                cache_file.unlink()
            except Exception:
                pass
            return default
    
    def set(self, key: str, value: Any, expiry: str = "medium") -> None:
        """Set a value in cache."""
        cache_file = self._get_cache_file(key)
        
        entry = CacheEntry(key, value, expiry)
        
        try:
            with open(cache_file, "w") as f:
                json.dump(entry.to_dict(), f)
        except Exception:
            # If cache write fails, just ignore it
            pass
    
    def delete(self, key: str) -> None:
        """Delete a value from cache."""
        cache_file = self._get_cache_file(key)
        try:
            cache_file.unlink()
        except Exception:
            pass
    
    def clear(self) -> None:
        """Clear all cache entries."""
        for cache_file in self.cache_dir.glob("*.cache"):
            try:
                cache_file.unlink()
            except Exception:
                pass
    
    def get_stats(self) -> dict:
        """Get cache statistics."""
        try:
            cache_files = list(self.cache_dir.glob("*.cache"))
            total_size = sum(f.stat().st_size for f in cache_files)
            
            return {
                "total_entries": len(cache_files),
                "total_size_bytes": total_size,
                "cache_dir": str(self.cache_dir),
            }
        except Exception:
            return {"error": "Failed to get cache statistics"}
# Global cache instance
_cache_manager = CacheManager()
def cached(key: str, expiry: str = "medium", generate_key: Optional[callable] = None):
    """Decorator to cache function results."""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Generate cache key
            if generate_key:
                cache_key = generate_key(*args, **kwargs)
            else:
                # Use function name and arguments to generate key
                import inspect
                sig = inspect.signature(func)
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()
                args_dict = dict(bound_args.arguments)
                # Remove 'self' if present
                args_dict.pop('self', None)
                args_dict.pop('cls', None)
                cache_key = f"{func.__name__}:{hash(json.dumps(args_dict, sort_keys=True))}"
            
            # Try to get from cache
            result = _cache_manager.get(cache_key)
            if result is not None:
                return result
            
            # Call function and cache result
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            _cache_manager.set(cache_key, result, expiry)
            return result
        
        return wrapper
    return decorator
# Convenience functions for common cache operations
def cache_get(key: str, default: Any = None) -> Any:
    """Get a value from cache."""
    return _cache_manager.get(key, default)

def cache_set(key: str, value: Any, expiry: str = "medium") -> None:
    """Set a value in cache."""
    _cache_manager.set(key, value, expiry)

def cache_delete(key: str) -> None:
    """Delete a value from cache."""
    _cache_manager.delete(key)

def cache_clear() -> None:
    """Clear all cache entries."""
    _cache_manager.clear()

def cache_stats() -> dict:
    """Get cache statistics."""
    return _cache_manager.get_stats()