import threading
from pathlib import Path
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class ModelConfig(BaseModel):
    default: str = "nvidia:nvidia/llama-3.3-nemotron-super-49b-v1"
    provider_priority: list[str] = ["nvidia", "openai", "anthropic"]
    temperature: float = 0.3
    max_tokens: int = 8192
    timeout: float = 120.0
    max_retries: int = 3
    fallback_chain: list[str] = [
        "nvidia:nvidia/nvidia-nemotron-nano-9b-v2",
        "nvidia:nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",
        "nvidia:nvidia/llama-3.1-nemotron-nano-8b-v1",
        "nvidia:nvidia/nemotron-3-nano-30b-a3b",
    ]
    # Enhanced model configuration options
    enable_streaming: bool = False
    stream_timeout: float = 60.0
    max_parallel_requests: int = 3
    request_timeout: float = 120.0
    retry_delay: float = 1.0
    max_retry_delay: float = 30.0
    enable_token_usage_tracking: bool = True
    usage_tracking_interval: float = 60.0
    # Tool configuration
    default_tools: list[str] = []
    tool_timeout: float = 120.0
    # Security configuration
    enable_input_validation: bool = True
    enable_output_sanitization: bool = True
    max_input_length: int = 10000
    max_output_length: int = 10000
    # Performance configuration
    enable_caching: bool = True
    cache_expiry: str = "medium"
    enable_parallel_processing: bool = True
    max_concurrent_tasks: int = 5
    task_timeout: float = 60.0
    # Logging configuration
    log_level: str = "info"
    log_format: str = "json"
    enable_console_logging: bool = True
    enable_file_logging: bool = True
    log_file_size: int = 10 * 1024 * 1024  # 10 MB
    log_backup_count: int = 5

class SpecConfig(BaseModel):
    dir: str = ".rumbod/specs"
    auto_create: bool = True
    template: str = "default"
    validation_enabled: bool = True
    max_spec_size: int = 1024 * 1024  # 1 MB

class HooksConfig(BaseModel):
    enabled: bool = True
    dir: str = ".rumbod/hooks"
    watch_patterns: list[str] = ["*.toml", "*.yaml", "*.yml"]
    ignore_patterns: list[str] = [".git", ".rumbod", "__pycache__", "node_modules"]
    max_hooks_per_batch: int = 10
    hook_timeout: float = 30.0

class SteeringConfig(BaseModel):
    dir: str = ".rumbod/steering"
    auto_inject: bool = True
    inject_patterns: list[str] = ["*.py", "*.md", "*.txt"]
    exclude_patterns: list[str] = [".rumbod", "__pycache__"]
    max_context_tokens: int = 4000

class MCPConfig(BaseModel):
    servers: dict = Field(default_factory=dict)
    auto_discover: bool = True
    discovery_timeout: float = 10.0
    max_connections: int = 5
    connection_timeout: float = 30.0

class PowersConfig(BaseModel):
    enabled: bool = True
    dir: str = ".rumbod/powers"
    auto_load: bool = True
    validation_enabled: bool = True
    max_power_size: int = 1024 * 1024  # 1 MB

class Config(BaseSettings):
    model: ModelConfig = ModelConfig()
    spec: SpecConfig = SpecConfig()
    hooks: HooksConfig = HooksConfig()
    steering: SteeringConfig = SteeringConfig()
    mcp: MCPConfig = MCPConfig()
    powers: PowersConfig = PowersConfig()
    log_dir: str = ".rumbod/logs"
    
    # Enhanced configuration options
    environment: str = "development"
    debug: bool = False
    profiling_enabled: bool = False
    metrics_enabled: bool = False
    metrics_endpoint: str = "http://localhost:9090"
    
    # Security configuration
    security: dict = Field(default_factory=dict)
    
    # Performance configuration
    performance: dict = Field(default_factory=dict)
    
    # Integration configuration
    integrations: dict = Field(default_factory=dict)
    
    # Custom configuration
    custom: dict = Field(default_factory=dict)

    model_config = SettingsConfigDict(
        env_prefix="RUMBOD_",
        env_nested_delimiter="__",
        extra="ignore",
    )

_config = None
_CONFIG_LOCK = threading.Lock()

def get_config() -> Config:
    global _config
    if _config is None:
        with _CONFIG_LOCK:
            if _config is None:
                _config = Config()
    return _config