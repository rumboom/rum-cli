"""Tools package for rumbod-cli."""
from rumbod_cli.tools.shell import run_shell
from rumbod_cli.tools.git import git_status, git_diff
from rumbod_cli.tools.tests import run_tests
from rumbod_cli.tools.websearch import web_search, web_fetch
from rumbod_cli.tools.filesystem import read_file, write_file, list_files, glob_files
from rumbod_cli.tools.file import (
    read_file as read_json_file,
    write_file as write_json_file,
    find_files,
    get_file_info,
    copy_file,
    move_file,
    delete_file,
    create_directory,
    list_directory,
    search_text_in_files,
)
from rumbod_cli.tools.process import (
    run_process,
    list_processes,
    get_process_info,
    kill_process,
    monitor_process,
    run_script,
    check_port,
    get_system_info,
)
from rumbod_cli.tools.network import (
    check_host,
    ping_host,
    resolve_dns,
    http_request,
    https_check,
    port_scan,
    get_ip_info,
    test_connectivity,
)
from rumbod_cli.tools.github_ import list_issues, list_prs, create_issue, list_repos, search_repos, get_repo
from rumbod_cli.tools.docker_ import ps as docker_ps, images as docker_images, logs as docker_logs, stats as docker_stats, info as docker_info
from rumbod_cli.tools.database import query_sqlite, list_tables, table_schema

__all__ = [
    "run_shell",
    "git_status",
    "git_diff",
    "run_tests",
    "web_search",
    "web_fetch",
    "read_file",
    "write_file",
    "list_files",
    "glob_files",
    # File tools
    "read_json_file",
    "write_json_file",
    "find_files",
    "get_file_info",
    "copy_file",
    "move_file",
    "delete_file",
    "create_directory",
    "list_directory",
    "search_text_in_files",
    # Process tools
    "run_process",
    "list_processes",
    "get_process_info",
    "kill_process",
    "monitor_process",
    "run_script",
    "check_port",
    "get_system_info",
    # Network tools
    "check_host",
    "ping_host",
    "resolve_dns",
    "http_request",
    "https_check",
    "port_scan",
    "get_ip_info",
    "test_connectivity",
    # GitHub tools
    "list_issues",
    "list_prs",
    "create_issue",
    "list_repos",
    "search_repos",
    "get_repo",
    # Docker tools
    "docker_ps",
    "docker_images",
    "docker_logs",
    "docker_stats",
    "docker_info",
    # Database tools
    "query_sqlite",
    "list_tables",
    "table_schema",
]