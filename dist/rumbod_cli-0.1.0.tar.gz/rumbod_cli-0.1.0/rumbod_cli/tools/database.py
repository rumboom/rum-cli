import sqlite3
import asyncio
from pathlib import Path
from typing import Any


async def query_sqlite(db_path: str, sql: str, params: list | None = None) -> dict:
    resolved = Path(db_path).expanduser().resolve()
    if not resolved.exists():
        return {"error": f"Database not found: {db_path}"}
    try:
        loop = asyncio.get_event_loop()
        def _run():
            conn = sqlite3.connect(str(resolved))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            if sql.strip().upper().startswith(("SELECT", "PRAGMA", "EXPLAIN")):
                rows = [dict(row) for row in cursor.fetchall()]
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                conn.close()
                return {"rows": rows, "columns": columns, "count": len(rows)}
            else:
                conn.commit()
                changes = conn.total_changes
                conn.close()
                return {"changes": changes, "ok": True}
        return await loop.run_in_executor(None, _run)
    except Exception as e:
        return {"error": str(e)}


async def list_tables(db_path: str) -> list[dict]:
    result = await query_sqlite(db_path, "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    if "error" in result:
        return [result]
    return result.get("rows", [])


async def table_schema(db_path: str, table: str) -> dict:
    result = await query_sqlite(db_path, f"PRAGMA table_info({table})")
    if "error" in result:
        return {"error": result["error"]}
    return {"columns": result.get("rows", []), "table": table}
