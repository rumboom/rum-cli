import asyncio
import subprocess
import psutil
import signal
import time
from pathlib import Path

async def run_process(cmd: str, timeout: int = 120, background: bool = False):
    """Run a process with timeout and background support."""
    try:
        # Validate command
        if not cmd or not isinstance(cmd, str):
            return {"error": "Command must be a non-empty string"}
        
        # Check for dangerous commands
        dangerous_commands = ["rm -rf /", "rm -rf /*", "mkfs", "fdisk", "chmod 777 /", ">:2>"]
        for dangerous in dangerous_commands:
            if dangerous in cmd:
                return {"error": f"Dangerous command detected: {dangerous}"}
        
        # Split command into parts
        parts = cmd.split()
        if not parts:
            return {"error": "Empty command"}
        
        # Check if command is in allowlist
        allowlist = {"ls", "cat", "grep", "rg", "fd", "find", "pytest", "python", "python3", "node", "npm", "cargo", "go", "git", "ruff", "black", "uv", "pip", "tree", "mkdir", "touch", "cp", "mv", "rm", "echo", "head", "tail", "less", "more", "wc", "sort", "uniq", "awk", "sed", "cut", "tr", "xargs", "ps", "kill", "curl", "wget", "jq", "yq", "systemctl", "journalctl", "docker", "apt", "apt-get", "nvidia-smi", "ffmpeg", "which", "file", "stat", "du", "df", "env", "export", "source", "alias", "type", "command", "id", "go"}
        
        if parts[0] not in allowlist:
            return {"error": f"Command '{parts[0]}' not in allowlist"}
        
        if background:
            # Run in background
            proc = await asyncio.create_subprocess_exec(
                *parts,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            return {
                "pid": proc.pid,
                "command": cmd,
                "status": "running",
                "started_at": time.time(),
            }
        else:
            # Run in foreground with timeout
            proc = await asyncio.wait_for(
                asyncio.create_subprocess_exec(
                    *parts,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                ),
                timeout=timeout,
            )
            stdout, stderr = await proc.communicate()
            return {
                "stdout": stdout.decode(),
                "stderr": stderr.decode(),
                "returncode": proc.returncode,
                "command": cmd,
                "status": "completed" if proc.returncode == 0 else "failed",
            }
    except asyncio.TimeoutError:
        return {"error": f"Command timed out after {timeout} seconds"}
    except Exception as e:
        return {"error": f"Failed to run command: {str(e)}"}

async def list_processes(filter: str = ""):
    """List running processes."""
    try:
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                pinfo = proc.info
                if filter and filter.lower() not in pinfo['name'].lower():
                    continue
                processes.append({
                    "pid": pinfo['pid'],
                    "name": pinfo['name'],
                    "cpu_percent": pinfo['cpu_percent'],
                    "memory_percent": pinfo['memory_percent'],
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return sorted(processes, key=lambda x: x['cpu_percent'], reverse=True)
    except Exception as e:
        return {"error": f"Failed to list processes: {str(e)}"}

async def get_process_info(pid: int):
    """Get information about a specific process."""
    try:
        proc = psutil.Process(pid)
        return {
            "pid": proc.pid,
            "name": proc.name(),
            "cmdline": proc.cmdline(),
            "cpu_percent": proc.cpu_percent(),
            "memory_percent": proc.memory_percent(),
            "status": proc.status(),
            "create_time": proc.create_time(),
            "num_threads": proc.num_threads(),
            "num_fds": proc.num_fds(),
        }
    except psutil.NoSuchProcess:
        return {"error": f"Process with PID {pid} not found"}
    except Exception as e:
        return {"error": f"Failed to get process info: {str(e)}"}

async def kill_process(pid: int, signal_type: str = "SIGTERM"):
    """Kill a process."""
    try:
        proc = psutil.Process(pid)
        sig = getattr(signal, signal_type, signal.SIGTERM)
        proc.terminate()
        proc.wait(timeout=10)
        return {"ok": True, "pid": pid, "signal": signal_type}
    except psutil.NoSuchProcess:
        return {"error": f"Process with PID {pid} not found"}
    except psutil.TimeoutExpired:
        try:
            proc.kill()
            return {"ok": True, "pid": pid, "signal": "SIGKILL"}
        except Exception as e:
            return {"error": f"Failed to kill process {pid}: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to kill process {pid}: {str(e)}"}

async def monitor_process(pid: int, interval: float = 1.0):
    """Monitor a process in real-time."""
    try:
        proc = psutil.Process(pid)
        while True:
            try:
                yield {
                    "pid": proc.pid,
                    "name": proc.name(),
                    "cpu_percent": proc.cpu_percent(),
                    "memory_percent": proc.memory_percent(),
                    "status": proc.status(),
                    "timestamp": time.time(),
                }
                await asyncio.sleep(interval)
            except psutil.NoSuchProcess:
                break
            except Exception:
                await asyncio.sleep(interval)
    except Exception as e:
        raise e

async def run_script(script_path: str, args: list = None, timeout: int = 120):
    """Run a Python script."""
    try:
        if not Path(script_path).exists():
            return {"error": f"Script not found: {script_path}"}
        
        cmd = ["python3", script_path]
        if args:
            cmd.extend(args)
        
        proc = await asyncio.wait_for(
            asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            ),
            timeout=timeout,
        )
        stdout, stderr = await proc.communicate()
        return {
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
            "returncode": proc.returncode,
            "command": " ".join(cmd),
            "status": "completed" if proc.returncode == 0 else "failed",
        }
    except asyncio.TimeoutError:
        return {"error": f"Script timed out after {timeout} seconds"}
    except Exception as e:
        return {"error": f"Failed to run script: {str(e)}"}

async def check_port(port: int):
    """Check if a port is in use."""
    try:
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex(('localhost', port))
        sock.close()
        return {"in_use": result == 0, "port": port}
    except Exception as e:
        return {"error": f"Failed to check port: {str(e)}"}

async def get_system_info():
    """Get system information."""
    try:
        import platform
        import psutil
        
        return {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "total_memory": psutil.virtual_memory().total,
            "available_memory": psutil.virtual_memory().available,
            "cpu_count": psutil.cpu_count(),
            "cpu_percent": psutil.cpu_percent(),
            "load_average": psutil.getloadavg() if hasattr(psutil, 'getloadavg') else None,
        }
    except Exception as e:
        return {"error": f"Failed to get system info: {str(e)}"}