from rumbod_cli.tools.shell import run_shell

async def run_tests():
    for cmd in ["pytest -xvs", "npm test", "cargo test", "go test ./..."]:
        r = await run_shell(cmd)
        if r.get("returncode") is not None and r["returncode"] == 0:
            return {"passed": True, "output": r["stdout"]}
    return {"passed": False, "output": "no test runner found or all failed"}

async def run_pytest(args: str = "-xvs"):
    return await run_shell(f"pytest {args}")

async def run_jest():
    return await run_shell("npm test")