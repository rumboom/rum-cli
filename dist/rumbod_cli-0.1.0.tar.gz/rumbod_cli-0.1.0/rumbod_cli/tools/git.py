from rumbod_cli.tools.shell import run_shell

async def git_status():
    return await run_shell("git status --short")

async def git_diff():
    return await run_shell("git diff --stat")