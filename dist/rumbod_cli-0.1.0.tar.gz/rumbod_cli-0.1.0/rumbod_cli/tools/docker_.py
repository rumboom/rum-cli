import asyncio
import json


async def _docker_cmd(args: list[str], timeout: int = 30) -> dict:
    try:
        proc = await asyncio.create_subprocess_exec(
            "docker", *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return {
            "stdout": stdout.decode().strip(),
            "stderr": stderr.decode().strip(),
            "returncode": proc.returncode or 0,
        }
    except FileNotFoundError:
        return {"error": "Docker not found. Install docker.io or docker-ce."}
    except asyncio.TimeoutError:
        return {"error": "Docker command timed out"}
    except Exception as e:
        return {"error": str(e)}


async def ps(all: bool = False) -> list[dict]:
    cmd = ["ps", "--no-trunc", "--format", "{{json .}}"]
    if all:
        cmd.append("-a")
    result = await _docker_cmd(cmd)
    if "error" in result:
        return [result]
    containers = []
    for line in result["stdout"].split("\n"):
        line = line.strip()
        if line:
            try:
                containers.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return containers


async def images() -> list[dict]:
    result = await _docker_cmd(["images", "--no-trunc", "--format", "{{json .}}"])
    if "error" in result:
        return [result]
    imgs = []
    for line in result["stdout"].split("\n"):
        line = line.strip()
        if line:
            try:
                imgs.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return imgs


async def logs(container: str, tail: int = 50) -> str:
    result = await _docker_cmd(["logs", "--tail", str(tail), container])
    if "error" in result:
        return result["error"]
    return result["stdout"] or result["stderr"]


async def stats() -> dict:
    result = await _docker_cmd(["stats", "--no-stream", "--format", "{{json .}}"])
    if "error" in result:
        return {"error": result["error"]}
    containers = []
    for line in result["stdout"].split("\n"):
        line = line.strip()
        if line:
            try:
                containers.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return {"containers": containers}


async def info() -> dict:
    result = await _docker_cmd(["info", "--format", "{{json .}}"])
    if "error" in result:
        return {"error": result["error"]}
    try:
        return json.loads(result["stdout"])
    except json.JSONDecodeError:
        return {"raw": result["stdout"][:1000]}
