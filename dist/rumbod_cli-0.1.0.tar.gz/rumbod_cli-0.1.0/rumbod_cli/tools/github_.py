import os
import httpx

_GITHUB_TOKEN = os.environ.get("RUMBOD_GITHUB_TOKEN", "").strip()
_GITHUB_API = "https://api.github.com"


def _headers() -> dict:
    h = {"Accept": "application/vnd.github.v3+json", "User-Agent": "rumbod-cli"}
    if _GITHUB_TOKEN:
        h["Authorization"] = f"Bearer {_GITHUB_TOKEN}"
    return h


async def github_api(method: str, path: str, data: dict | None = None) -> dict:
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.request(method, f"{_GITHUB_API}/{path.lstrip('/')}", headers=_headers(), json=data)
        if resp.status_code == 404:
            return {"error": "Not found"}
        if resp.status_code == 403:
            return {"error": "Rate limited or forbidden"}
        if resp.status_code == 401:
            return {"error": "Bad credentials — check RUMBOD_GITHUB_TOKEN"}
        resp.raise_for_status()
        return resp.json()


async def list_issues(repo: str, state: str = "open", limit: int = 10) -> list[dict]:
    data = await github_api("GET", f"repos/{repo}/issues?state={state}&per_page={limit}&sort=updated")
    if isinstance(data, dict) and "error" in data:
        return [data]
    return [
        {"number": i["number"], "title": i["title"], "state": i["state"], "url": i["html_url"]}
        for i in data if "pull_request" not in i
    ][:limit]


async def list_prs(repo: str, state: str = "open", limit: int = 10) -> list[dict]:
    data = await github_api("GET", f"repos/{repo}/pulls?state={state}&per_page={limit}")
    if isinstance(data, dict) and "error" in data:
        return [data]
    return [
        {"number": p["number"], "title": p["title"], "state": p["state"], "url": p["html_url"]}
        for p in data
    ][:limit]


async def create_issue(repo: str, title: str, body: str = "", labels: list[str] | None = None) -> dict:
    payload = {"title": title, "body": body}
    if labels:
        payload["labels"] = labels
    return await github_api("POST", f"repos/{repo}/issues", payload)


async def list_repos(owner: str, limit: int = 20) -> list[dict]:
    data = await github_api("GET", f"users/{owner}/repos?per_page={limit}&sort=updated")
    if isinstance(data, dict) and "error" in data:
        return [data]
    return [
        {"name": r["name"], "description": r.get("description", ""), "stars": r["stargazers_count"], "url": r["html_url"]}
        for r in data
    ][:limit]


async def get_repo(repo: str) -> dict:
    return await github_api("GET", f"repos/{repo}")


async def search_repos(query: str, limit: int = 10) -> list[dict]:
    data = await github_api("GET", f"search/repositories?q={query}&per_page={limit}")
    if isinstance(data, dict) and "error" in data:
        return [data]
    items = data.get("items", [])
    return [
        {"name": r["full_name"], "description": r.get("description", ""), "stars": r["stargazers_count"], "url": r["html_url"]}
        for r in items
    ][:limit]
