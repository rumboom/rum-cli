import asyncio
import shlex
import re
from pathlib import Path

# Shell redirect patterns to strip before exec (exec doesn't support them)
_REDIRECT_RE = re.compile(r'\s*(?:2>|1>|>|>>|&>|2>&1|2>&-|&>-)\s*(?:/\S+)?(?:\s+|$)')


def _strip_redirects(cmd: str) -> str:
    """Remove shell redirects like 2>/dev/null, >/dev/null, 2>&1, etc."""
    return _REDIRECT_RE.sub(' ', cmd).strip()

# Allowlist of safe commands for the agent
ALLOW = {
    "cd", "ls", "cat", "grep", "rg", "fd", "find", "tree", "stat", "du", "df", "file",
    "head", "tail", "less", "more", "wc", "sort", "uniq", "cut", "tr", "xargs",
    "pytest", "python", "python3", "node", "npm", "cargo", "go", "git",
    "ruff", "black", "uv", "pip",
    "ps", "kill", "nvidia-smi", "env", "export", "source", "alias", "type", "command", "id",
    "curl", "wget", "jq", "yq",
    "docker",
    "apt", "apt-get",
    "ffmpeg",
    "echo", "mkdir", "touch", "cp", "mv", "rm",
}

# Deny list — literal substrings that are always unsafe
DENY = {
    "rm -rf /", "rm -rf /*", "rm -rf .", "rm -rf ..",
    "dd if=", "dd of=", "mkfs", "fdisk", "parted", "shred", "wipefs",
    "chmod 777 /", "chmod 000 /", "chmod -R 777", "chmod -R 000",
    "nc ", "netcat", "ssh ", "scp ", "rsync ", "telnet",
    "eval ", "exec ", "system(", "subprocess.call(", "subprocess.Popen(",
    "sudo ", "su ", "doas ", "pkexec",
    "mount ", "umount ", "fsck ",
    "arpspoof ", "dnsspoof ", "ettercap ", "wireshark",
    "minerd ", "cgminer ", "bfgminer",
    "encrypt ", "decrypt ", "ransom",
}

# System directories that agent should never write to
_RESTRICTED_PREFIXES = ("/etc", "/sys", "/proc", "/boot", "/dev", "/lib", "/usr", "/bin", "/sbin")


async def _validate_command(cmd: str, cwd: str) -> tuple[bool, str]:
    """Validate command for security issues."""
    parts = shlex.split(cmd)
    if not parts:
        return False, "Empty command"

    if len(cmd) > 2000:
        return False, "Command too long (max 2000 characters)"

    if len(parts) > 30:
        return False, "Too many arguments (max 30)"

    # Allowlist check
    if parts[0] not in ALLOW:
        return False, f"Command '{parts[0]}' not in allowlist"

    full_cmd = " ".join(parts)

    # Deny-list check (literal substrings)
    for deny in DENY:
        if deny in full_cmd:
            return False, f"Dangerous pattern detected: {deny}"

    # Shell injection patterns (only the truly dangerous ones)
    inj = re.search(r'[\$`;]', full_cmd)
    if inj:
        return False, f"Shell injection character detected: {inj.group()}"

    # Block write to system directories
    if parts[0] in ("cp", "mv", "rm", "touch", "mkdir", "write_file"):
        for part in parts:
            expanded = Path(part).expanduser().resolve()
            for prefix in _RESTRICTED_PREFIXES:
                if str(expanded).startswith(prefix):
                    return False, f"Cannot write to system path: {prefix}"

    return True, ""


async def run_shell(cmd: str, cwd: str = ".", timeout: int = 120):
    """Run shell command with security validation."""
    try:
        # Strip shell redirects (not supported in exec mode)
        clean_cmd = _strip_redirects(cmd)

        is_valid, error_msg = await _validate_command(clean_cmd, cwd)
        if not is_valid:
            return {"error": error_msg}

        parts = shlex.split(clean_cmd)

        # Extra safety for destructive commands
        if parts[0] == "rm":
            full = " ".join(parts)
            if full == "rm -rf /" or full == "rm -rf /*":
                return {"error": "Potentially dangerous rm command detected"}

        # Build command — use shell=True for cd support
        if parts[0] == "cd":
            if len(parts) > 1:
                target = Path(parts[1]).expanduser()
                target.mkdir(parents=True, exist_ok=True)
                return {"stdout": str(target.resolve()), "stderr": "", "returncode": 0}
            return {"stdout": str(Path(cwd).resolve()), "stderr": "", "returncode": 0}

        proc = await asyncio.create_subprocess_exec(
            *parts,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return {
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
            "returncode": proc.returncode or 0,
        }
    except asyncio.TimeoutError:
        return {"error": "Command timed out"}
    except Exception as e:
        return {"error": f"Failed to execute command: {str(e)}"}
