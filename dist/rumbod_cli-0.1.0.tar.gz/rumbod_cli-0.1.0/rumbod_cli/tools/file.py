from pathlib import Path
import json
import yaml
import os

async def read_file(path: str):
    """Read file content with support for multiple formats."""
    try:
        p = Path(path).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        if not p.exists():
            return {"error": f"File not found: {path}"}
        
        # Try to detect file type
        if p.suffix.lower() in ['.json']:
            return json.loads(p.read_text())
        elif p.suffix.lower() in ['.yaml', '.yml']:
            return yaml.safe_load(p.read_text())
        else:
            return p.read_text()
    except json.JSONDecodeError as e:
        return {"error": f"Invalid JSON in file {path}: {str(e)}"}
    except yaml.YAMLError as e:
        return {"error": f"Invalid YAML in file {path}: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to read file {path}: {str(e)}"}

async def write_file(path: str, content, format: str = "auto"):
    """Write content to file with support for multiple formats."""
    try:
        p = Path(path).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        p.parent.mkdir(parents=True, exist_ok=True)
        
        # Determine file format
        if format == "auto":
            if path.lower().endswith('.json'):
                format = "json"
            elif path.lower().endswith(('.yaml', '.yml')):
                format = "yaml"
            else:
                format = "text"
        
        if format == "json":
            p.write_text(json.dumps(content, indent=2))
        elif format == "yaml":
            p.write_text(yaml.dump(content, default_flow_style=False))
        else:
            p.write_text(str(content))
        
        return {"ok": True, "path": str(p), "format": format}
    except Exception as e:
        return {"error": f"Failed to write file {path}: {str(e)}"}

async def find_files(pattern: str, directory: str = "."):
    """Find files matching a pattern."""
    try:
        p = Path(directory).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        import fnmatch
        matches = []
        for root, dirs, files in os.walk(p):
            for file in files:
                if fnmatch.fnmatch(file, pattern):
                    matches.append(str(Path(root) / file))
        
        return matches
    except Exception as e:
        return {"error": f"Failed to find files: {str(e)}"}

async def get_file_info(path: str):
    """Get information about a file."""
    try:
        p = Path(path).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        if not p.exists():
            return {"error": f"File not found: {path}"}
        
        stat = p.stat()
        return {
            "name": p.name,
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "created": stat.st_ctime,
            "is_file": p.is_file(),
            "is_dir": p.is_dir(),
            "extension": p.suffix.lower(),
        }
    except Exception as e:
        return {"error": f"Failed to get file info: {str(e)}"}

async def copy_file(src: str, dst: str):
    """Copy a file from source to destination."""
    try:
        src_path = Path(src).expanduser().resolve()
        dst_path = Path(dst).expanduser().resolve()
        cwd = Path.cwd().resolve()
        
        for path in [src_path, dst_path]:
            if not str(path).startswith(str(cwd) + "/") and str(path) != str(cwd):
                return {"error": f"Path {path} is outside the project root {cwd}"}
        
        if not src_path.exists():
            return {"error": f"Source file not found: {src}"}
        
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        dst_path.write_bytes(src_path.read_bytes())
        
        return {"ok": True, "source": str(src_path), "destination": str(dst_path)}
    except Exception as e:
        return {"error": f"Failed to copy file: {str(e)}"}

async def move_file(src: str, dst: str):
    """Move a file from source to destination."""
    try:
        src_path = Path(src).expanduser().resolve()
        dst_path = Path(dst).expanduser().resolve()
        cwd = Path.cwd().resolve()
        
        for path in [src_path, dst_path]:
            if not str(path).startswith(str(cwd) + "/") and str(path) != str(cwd):
                return {"error": f"Path {path} is outside the project root {cwd}"}
        
        if not src_path.exists():
            return {"error": f"Source file not found: {src}"}
        
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        src_path.rename(dst_path)
        
        return {"ok": True, "source": str(src_path), "destination": str(dst_path)}
    except Exception as e:
        return {"error": f"Failed to move file: {str(e)}"}

async def delete_file(path: str):
    """Delete a file."""
    try:
        p = Path(path).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        if not p.exists():
            return {"error": f"File not found: {path}"}
        
        p.unlink()
        return {"ok": True, "path": str(p)}
    except Exception as e:
        return {"error": f"Failed to delete file: {str(e)}"}

async def create_directory(path: str):
    """Create a directory."""
    try:
        p = Path(path).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        p.mkdir(parents=True, exist_ok=True)
        return {"ok": True, "path": str(p)}
    except Exception as e:
        return {"error": f"Failed to create directory: {str(e)}"}

async def list_directory(path: str = "."):
    """List contents of a directory."""
    try:
        p = Path(path).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        if not p.exists():
            return {"error": f"Directory not found: {path}"}
        
        if not p.is_dir():
            return {"error": f"Path is not a directory: {path}"}
        
        contents = []
        for item in p.iterdir():
            stat = item.stat()
            contents.append({
                "name": item.name,
                "is_file": item.is_file(),
                "is_dir": item.is_dir(),
                "size": stat.st_size if item.is_file() else 0,
                "modified": stat.st_mtime,
            })
        
        return contents
    except Exception as e:
        return {"error": f"Failed to list directory: {str(e)}"}

async def search_text_in_files(pattern: str, directory: str = "."):
    """Search for text pattern in files."""
    try:
        p = Path(directory).expanduser().resolve()
        cwd = Path.cwd().resolve()
        if not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            return {"error": f"Path {p} is outside the project root {cwd}"}
        
        import re
        results = []
        for root, dirs, files in os.walk(p):
            for file in files:
                file_path = Path(root) / file
                try:
                    content = file_path.read_text()
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    if matches:
                        results.append({
                            "file": str(file_path),
                            "matches": len(matches),
                            "preview": content[:200],
                        })
                except Exception:
                    continue
        
        return results
    except Exception as e:
        return {"error": f"Failed to search text in files: {str(e)}"}

# Aliases for imports from subagent.py and task_loop.py
read_json_file = read_file
write_json_file = write_file