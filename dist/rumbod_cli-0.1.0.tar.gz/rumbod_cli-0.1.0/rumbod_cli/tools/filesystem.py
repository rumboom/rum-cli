from pathlib import Path
import os

# Security configuration
SECURITY_CONFIG = {
    "allow_outside_project": False,
    "allow_outside_home": False,
    "allow_outside_root": False,
    "forbid_hidden_files": True,
    "forbid_sensitive_extensions": True,
    "sensitive_extensions": [".env", ".key", ".pem", ".crt", ".p12", ".pfx"],
    "max_file_size": 100 * 1024 * 1024,  # 100 MB
    "forbid_archive_extraction": True,
    "forbid_compressed_files": False,
}

def _safe_resolve(path: str, check_security: bool = True) -> Path:
    """Resolve path with security checks."""
    p = Path(path).expanduser().resolve()
    cwd = Path.cwd().resolve()
    
    if check_security:
        # Check if path is outside project root
        if SECURITY_CONFIG["allow_outside_project"]:
            pass
        elif not str(p).startswith(str(cwd) + "/") and str(p) != str(cwd):
            raise PermissionError(f"Path {p} is outside the project root {cwd}")
        
        # Check if path is outside home directory
        if SECURITY_CONFIG["allow_outside_home"]:
            pass
        elif str(p).startswith(str(Path.home().resolve()) + "/"):
            raise PermissionError(f"Path {p} is outside the home directory")
        
        # Check if path is outside root directory
        if SECURITY_CONFIG["allow_outside_root"]:
            pass
        elif str(p).startswith(str(Path("/").resolve()) + "/") and not str(cwd).startswith(str(p) + "/"):
            raise PermissionError(f"Path {p} is outside the root directory")
        
        # Check for hidden files
        if SECURITY_CONFIG["forbid_hidden_files"]:
            if any(part.startswith(".") for part in p.parts if part not in [".", ".."]):
                raise PermissionError(f"Hidden files are not allowed: {p}")
        
        # Check for sensitive file extensions
        if SECURITY_CONFIG["forbid_sensitive_extensions"]:
            for ext in SECURITY_CONFIG["sensitive_extensions"]:
                if p.suffix.lower() == ext:
                    raise PermissionError(f"File with sensitive extension not allowed: {p}")
        
        # Check file size for reading
        if p.exists() and p.is_file() and p.stat().st_size > SECURITY_CONFIG["max_file_size"]:
            raise PermissionError(f"File too large: {p} ({p.stat().st_size} bytes)")
    
    return p

async def read_file(path: str):
    try:
        p = _safe_resolve(path)
        return p.read_text() if p.exists() else ""
    except Exception as e:
        return {"error": str(e)}

async def write_file(path: str, content: str):
    try:
        p = _safe_resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return {"ok": True, "path": str(p)}
    except Exception as e:
        return {"error": str(e)}

async def list_files(dir: str = "."):
    try:
        p = _safe_resolve(dir)
        return [str(x) for x in p.iterdir()]
    except Exception as e:
        return {"error": str(e)}

async def glob_files(pattern: str, dir: str = "."):
    try:
        p = _safe_resolve(dir)
        return [str(x) for x in p.rglob(pattern)]
    except Exception as e:
        return {"error": str(e)}

async def delete_file(path: str):
    try:
        p = _safe_resolve(path)
        if p.exists():
            p.unlink()
            return {"ok": True}
        return {"error": "not found"}
    except Exception as e:
        return {"error": str(e)}

async def mkdir(path: str):
    try:
        p = _safe_resolve(path)
        p.mkdir(parents=True, exist_ok=True)
        return {"ok": True}
    except Exception as e:
        return {"error": str(e)}
