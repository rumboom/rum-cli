import httpx
from bs4 import BeautifulSoup

_SCRAPE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}


async def web_search(query: str, max_results: int = 5) -> list[str]:
    """Search the web using DuckDuckGo lite and return result snippets."""
    url = "https://lite.duckduckgo.com/lite/"
    async with httpx.AsyncClient(follow_redirects=True, timeout=15.0) as client:
        r = await client.post(url, data={"q": query}, headers=_SCRAPE_HEADERS)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    results: list[str] = []

    seen_urls: set[str] = set()
    tables = soup.find_all("table")
    if len(tables) > 2:
        zero_click = tables[1]
        zc_link = zero_click.find("a")
        if zc_link:
            zc_href = zc_link.get("href", "")
            if "y.js" not in zc_href:
                zc_title = zc_link.get_text(strip=True)
                zc_td = zero_click.find_all("td")
                zc_snippet = zc_td[-1].get_text(strip=True) if len(zc_td) > 1 else ""
                line = zc_title
                if zc_snippet and zc_snippet != zc_title:
                    line += f" — {zc_snippet[:150]}"
                line += f"\n  URL: {zc_href}"
                results.append(line)
                seen_urls.add(zc_href)

        result_table = tables[2]
        for tr in result_table.find_all("tr"):
            for td in tr.find_all("td"):
                link = td.find("a")
                if not link:
                    continue
                href = link.get("href", "")
                if "y.js" in href or href in seen_urls:
                    continue
                title = link.get_text(strip=True)
                if not title or len(title) < 3:
                    continue
                seen_urls.add(href)
                line = f"{title}\n  URL: {href}"
                results.append(line)
                if len(results) >= max_results:
                    return results

    if not results:
        for a in soup.select("a[href^='http']"):
            href = a.get("href", "")
            if "y.js" in href:
                continue
            text = a.get_text(strip=True)
            if text and len(text) > 10:
                results.append(f"{text}\n  URL: {href}")
                if len(results) >= max_results:
                    break
    return results or ["No results found."]


async def web_fetch(url: str, max_chars: int = 5000) -> str:
    """Fetch a URL and return readable text content."""
    async with httpx.AsyncClient(follow_redirects=True, timeout=20.0) as client:
        r = await client.get(url, headers=_SCRAPE_HEADERS)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "iframe", "noscript"]):
        tag.decompose()
    title = soup.title.get_text(strip=True) if soup.title else ""
    body_text = soup.get_text(separator="\n", strip=True)
    lines = [l.strip() for l in body_text.split("\n") if l.strip()]
    text = "\n".join(lines[:200])
    if len(text) > max_chars:
        text = text[:max_chars] + "\n... [truncated]"
    result = f"Title: {title}\n\n{text}" if title else text
    return result