import asyncio
import socket
import urllib.parse
import requests
from pathlib import Path

async def check_host(host: str):
    """Check if a host is reachable."""
    try:
        # Validate host
        if not host or not isinstance(host, str):
            return {"error": "Host must be a non-empty string"}
        
        # Parse URL
        parsed = urllib.parse.urlparse(host)
        if not parsed.scheme:
            host = "https://" + host
            parsed = urllib.parse.urlparse(host)
        
        # Resolve hostname
        try:
            ip = socket.gethostbyname(parsed.hostname)
        except socket.gaierror:
            return {"error": f"Could not resolve hostname: {parsed.hostname}"}
        
        # Test connection
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((ip, 443 if parsed.scheme == "https" else 80))
            sock.close()
            
            return {
                "host": parsed.hostname,
                "ip": ip,
                "port": 443 if parsed.scheme == "https" else 80,
                "reachable": result == 0,
                "scheme": parsed.scheme,
            }
        except Exception as e:
            return {"error": f"Connection test failed: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to check host: {str(e)}"}

async def ping_host(host: str, count: int = 4):
    """Ping a host."""
    try:
        # Validate host
        if not host or not isinstance(host, str):
            return {"error": "Host must be a non-empty string"}
        
        # Use ping command
        cmd = ["ping", "-c", str(count), host]
        
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        
        return {
            "host": host,
            "command": " ".join(cmd),
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
            "returncode": proc.returncode,
            "status": "success" if proc.returncode == 0 else "failed",
        }
    except Exception as e:
        return {"error": f"Failed to ping host: {str(e)}"}

async def resolve_dns(host: str):
    """Resolve DNS for a host."""
    try:
        # Validate host
        if not host or not isinstance(host, str):
            return {"error": "Host must be a non-empty string"}
        
        # Get all records
        import socket
        try:
            addr_info = socket.getaddrinfo(host, None)
            records = []
            for info in addr_info:
                records.append({
                    "family": info[0],
                    "type": info[1],
                    "proto": info[2],
                    "port": info[4][1] if len(info) > 4 else None,
                    "canonical_name": info[3],
                })
            
            return {
                "host": host,
                "records": records,
                "count": len(records),
            }
        except socket.gaierror as e:
            return {"error": f"DNS resolution failed: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to resolve DNS: {str(e)}"}

async def http_request(url: str, method: str = "GET", headers: dict = None, timeout: int = 30):
    """Make an HTTP request."""
    try:
        # Validate URL
        if not url or not isinstance(url, str):
            return {"error": "URL must be a non-empty string"}
        
        # Validate method
        if method not in ["GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS"]:
            return {"error": f"Invalid HTTP method: {method}"}
        
        # Make request
        response = requests.request(
            method=method,
            url=url,
            headers=headers or {},
            timeout=timeout,
        )
        
        return {
            "url": url,
            "method": method,
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "content": response.text[:1000] if len(response.text) > 1000 else response.text,
            "content_type": response.headers.get("Content-Type", ""),
            "content_length": len(response.text),
            "is_success": 200 <= response.status_code < 300,
        }
    except requests.exceptions.Timeout:
        return {"error": f"Request timed out after {timeout} seconds"}
    except requests.exceptions.ConnectionError as e:
        return {"error": f"Connection error: {str(e)}"}
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to make HTTP request: {str(e)}"}

async def https_check(url: str):
    """Check if an HTTPS URL is valid and accessible."""
    try:
        # Validate URL
        if not url or not isinstance(url, str):
            return {"error": "URL must be a non-empty string"}
        
        # Parse URL
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https":
            return {"error": "URL must use HTTPS protocol"}
        
        # Check SSL certificate
        import ssl
        import socket
        
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        
        try:
            sock.connect((parsed.hostname, 443))
            ssl_sock = context.wrap_socket(sock, server_hostname=parsed.hostname)
            
            # Try to get server certificate
            cert = ssl_sock.getpeercert()
            
            ssl_sock.close()
            
            return {
                "url": url,
                "hostname": parsed.hostname,
                "ssl_valid": True,
                "certificate": cert,
                "accessible": True,
            }
        except Exception as e:
            return {"error": f"SSL check failed: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to check HTTPS: {str(e)}"}

async def port_scan(host: str, ports: list):
    """Scan ports on a host."""
    try:
        # Validate host
        if not host or not isinstance(host, str):
            return {"error": "Host must be a non-empty string"}
        
        # Validate ports
        if not ports or not isinstance(ports, list):
            return {"error": "Ports must be a non-empty list"}
        
        # Resolve hostname
        try:
            ip = socket.gethostbyname(host)
        except socket.gaierror:
            return {"error": f"Could not resolve hostname: {host}"}
        
        # Scan ports
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip, port))
                sock.close()
                if result == 0:
                    open_ports.append(port)
            except Exception:
                continue
        
        return {
            "host": host,
            "ip": ip,
            "scanned_ports": ports,
            "open_ports": open_ports,
            "total_ports": len(ports),
            "open_count": len(open_ports),
        }
    except Exception as e:
        return {"error": f"Failed to scan ports: {str(e)}"}

async def get_ip_info(ip: str):
    """Get information about an IP address."""
    try:
        # Validate IP
        if not ip or not isinstance(ip, str):
            return {"error": "IP must be a non-empty string"}
        
        # Check if it's a valid IP
        try:
            socket.inet_aton(ip)
        except socket.error:
            return {"error": f"Invalid IP address: {ip}"}
        
        # Get hostname
        try:
            hostname = socket.gethostbyaddr(ip)[0]
        except socket.herror:
            hostname = None
        
        return {
            "ip": ip,
            "hostname": hostname,
            "type": "IPv4",
        }
    except Exception as e:
        return {"error": f"Failed to get IP info: {str(e)}"}

async def test_connectivity(host: str, port: int = 80, timeout: int = 5):
    """Test connectivity to a host and port."""
    try:
        # Validate inputs
        if not host or not isinstance(host, str):
            return {"error": "Host must be a non-empty string"}
        
        if not isinstance(port, int) or port < 1 or port > 65535:
            return {"error": "Port must be a valid port number (1-65535)"}
        
        # Test connection
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()
            
            return {
                "host": host,
                "port": port,
                "reachable": result == 0,
                "response_time": timeout if result != 0 else "unknown",
                "status": "success" if result == 0 else "failed",
            }
        except Exception as e:
            return {"error": f"Connection test failed: {str(e)}"}
    except Exception as e:
        return {"error": f"Failed to test connectivity: {str(e)}"}