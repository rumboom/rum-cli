import asyncio
import json
import time
import os as _os
from pathlib import Path
from dataclasses import dataclass, asdict

_PROV_FILE = Path(".rumbod/providers.json")

ROLES = ("main", "subagent", "both")


@dataclass
class ProviderEntry:
    model: str
    api_key_ref: str = "env"
    role: str = "both"
    label: str = ""
    added_at: str = ""
    working: bool | None = None
    error: str | None = None
    last_tested: str | None = None

    def __post_init__(self):
        if not self.label:
            short = self.model.split("/")[-1] if "/" in self.model else self.model
            self.label = f"{short} ({self.api_key_ref})"
        if not self.added_at:
            self.added_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        if self.role not in ROLES:
            self.role = "both"


def _ensure_file():
    _PROV_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not _PROV_FILE.exists():
        _write({"providers": [], "rr_index": 0})


def _read() -> dict:
    _ensure_file()
    try:
        return json.loads(_PROV_FILE.read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        data = {"providers": [], "rr_index": 0}
        _write(data)
        return data


def _write(data: dict):
    _PROV_FILE.parent.mkdir(parents=True, exist_ok=True)
    _PROV_FILE.write_text(json.dumps(data, indent=2))


def all_providers() -> list[ProviderEntry]:
    data = _read()
    return [ProviderEntry(**p) for p in data.get("providers", [])]


def add_provider(model: str, api_key_ref: str = "env", role: str = "both", label: str = "") -> ProviderEntry:
    if not model:
        raise ValueError("Model cannot be empty")
    if role not in ROLES:
        raise ValueError(f"Role must be one of: {', '.join(ROLES)}")
    data = _read()
    entry = ProviderEntry(model=model, api_key_ref=api_key_ref, role=role, label=label)
    data["providers"].append(asdict(entry))
    _write(data)
    return entry


def remove_provider(index: int) -> bool:
    data = _read()
    if 0 <= index < len(data["providers"]):
        data["providers"].pop(index)
        if data["rr_index"] >= len(data["providers"]):
            data["rr_index"] = 0
        _write(data)
        return True
    return False


def get_providers_for_role(role: str) -> list[ProviderEntry]:
    if role not in ROLES:
        return []
    return [p for p in all_providers() if p.role in (role, "both")]


async def resolve_api_key(key_ref: str) -> str | None:
    if key_ref == "env":
        raw = _os.environ.get("RUMBOD_NVIDIA_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
        return raw or None
    if key_ref.startswith("key:"):
        try:
            from rumbod_cli.apikeys import all_keys as _all_keys
            idx = int(key_ref.split(":", 1)[1])
            keys = await _all_keys()
            if 0 <= idx < len(keys):
                return keys[idx].key
        except (ValueError, IndexError):
            pass
    return None


_RR_LOCK = asyncio.Lock()
_RR_INDEX: int = 0


async def get_next_provider_for_role(role: str) -> tuple[str, str | None] | None:
    global _RR_INDEX
    providers = get_providers_for_role(role)
    if not providers:
        return None
    async with _RR_LOCK:
        if _RR_INDEX >= len(providers):
            _RR_INDEX = 0
        entry = providers[_RR_INDEX]
        _RR_INDEX = (_RR_INDEX + 1) % len(providers)
        api_key = await resolve_api_key(entry.api_key_ref)
        return (entry.model, api_key)


async def get_provider_for_role(role: str):
    from rumbod_cli.models import get_provider as _get_provider, normalize_model
    result = await get_next_provider_for_role(role)
    if result is None:
        return _get_provider("auto")
    model, api_key = result
    return _get_provider(normalize_model(model), api_key=api_key)


def count_providers() -> int:
    return len(all_providers())


def set_provider_working(index: int, working: bool, error: str | None = None):
    data = _read()
    if 0 <= index < len(data["providers"]):
        data["providers"][index]["working"] = working
        data["providers"][index]["error"] = error
        data["providers"][index]["last_tested"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _write(data)


async def test_provider(entry: ProviderEntry) -> tuple[bool, str | None]:
    import httpx
    from rumbod_cli.apiusage import record_usage

    api_key = resolve_api_key(entry.api_key_ref)
    if not api_key:
        return False, "No API key resolved"

    async with httpx.AsyncClient(timeout=30.0) as client:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": entry.model,
            "messages": [{"role": "user", "content": "ping. Reply only: pong"}],
            "max_tokens": 16,
            "stream": False,
        }
        try:
            resp = await client.post(
                "https://integrate.api.nvidia.com/v1/chat/completions",
                headers=headers, json=payload,
            )
            if resp.status_code == 200:
                data = resp.json()
                usage = data.get("usage")
                if usage:
                    await record_usage(
                        prompt_tokens=usage.get("prompt_tokens", 0),
                        completion_tokens=usage.get("completion_tokens", 0),
                        model=entry.model,
                    )
                return True, None
            detail = resp.text[:150]
            if resp.status_code == 401:
                return False, "401 Unauthorized"
            elif resp.status_code == 402:
                return False, "402 Payment Required"
            elif resp.status_code == 403:
                return False, "403 Forbidden"
            elif resp.status_code == 404:
                return False, "404 Model not found"
            else:
                return False, f"{resp.status_code}: {detail}"
        except httpx.TimeoutException:
            return False, "Connection timed out"
        except Exception as e:
            return False, str(e)[:150]


async def test_all_providers() -> list[dict]:
    results = []
    for i, entry in enumerate(all_providers()):
        ok, err = await test_provider(entry)
        set_provider_working(i, ok, err)
        results.append({"index": i, "label": entry.label, "model": entry.model, "working": ok, "error": err})
    return results


def reset_providers():
    _write({"providers": [], "rr_index": 0})
