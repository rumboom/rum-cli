"""Command overlay menu for rum-interactive-cli — live-search command palette."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Input, ListItem, ListView, Static

from .constants import SLASH_COMMANDS


class MenuInput(Input):
    """Input that forwards up/down to the list."""

    def _on_key(self, event) -> None:
        if event.key in ("up", "down"):
            event.stop()
            lst = self.screen.query_one("#cmd-list", ListView)
            ix = lst.index if lst.index is not None else -1
            nxt = max(0, ix - 1) if event.key == "up" else min(len(lst._nodes) - 1, ix + 1)
            lst.index = nxt
            return
        super()._on_key(event)


class CommandMenu(ModalScreen):
    """Overlay command palette with live search — triggered by typing /."""

    def __init__(self, initial: str = ""):
        super().__init__()
        self._initial = initial
        self.matched: list[str] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="cmd-menu"):
            yield MenuInput(placeholder="Search commands...", id="cmd-search", value=self._initial)
            yield ListView(id="cmd-list")

    async def on_mount(self) -> None:
        await self._rebuild_list("")
        search = self.query_one("#cmd-search", Input)
        search.focus()
        search.cursor_position = len(search.value)

    async def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "cmd-search":
            await self._rebuild_list(event.value)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "cmd-search":
            self._dismiss_selected()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        self._dismiss_selected()

    def _dismiss_selected(self) -> None:
        lst = self.query_one("#cmd-list", ListView)
        search = self.query_one("#cmd-search", Input)
        raw = search.value.strip()
        ix = lst.index
        if ix is None:
            ix = 0 if self.matched else None
        if ix is not None and ix < len(self.matched):
            cmd = self.matched[ix]
            name = cmd.lstrip("/")
            if raw.lower() != name and raw.lower().startswith(name + " "):
                cmd = "/" + raw
            self.dismiss(cmd)
        else:
            self.dismiss(None)

    async def _rebuild_list(self, filter_text: str) -> None:
        listv = self.query_one("#cmd-list", ListView)
        await listv.clear()
        self.matched = []
        q = filter_text.lower()
        for cmd, desc in SLASH_COMMANDS.items():
            if q in cmd.lower() or q in desc.lower():
                self.matched.append(cmd)
                label = f"[bold]{cmd:<22}[/bold] {desc}"
                listv.append(ListItem(Static(label)))
        if not self.matched:
            listv.append(ListItem(Static("[dim]No matching commands[/dim]")))
        if self.matched:
            listv.index = 0

    BINDINGS = [("escape", "dismiss", "Close menu")]

    CSS = """
    Screen {
        background: transparent !important;
    }
    #cmd-menu {
        width: 60%;
        height: 70%;
        margin-top: 3;
        background: rgba(10, 10, 25, 0.96);
        border: thick #e94560;
        padding: 0;
    }
    #cmd-search {
        dock: top;
        margin: 1 1 0 1;
        background: #1a1a3e;
        border: solid #4a4a6a;
    }
    #cmd-search:focus {
        border: solid #e94560;
    }
    #cmd-list {
        height: 1fr;
        margin: 1 1 1 1;
    }
    ListItem {
        padding: 0 1;
    }
    ListItem:hover {
        background: $boost;
    }
    ListItem.-highlight {
        background: #e94560;
    }
    """
