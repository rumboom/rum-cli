import shlex
from pathlib import Path
from dataclasses import dataclass
from watchfiles import watch
import subprocess, threading, tomli

HOOK_DIR = Path(".rumbod/hooks")
HOOK_DIR.mkdir(parents=True, exist_ok=True)

@dataclass
class Hook:
    name: str
    trigger: dict
    command: str
    async_exec: bool = True

def load_hooks() -> list[Hook]:
    hooks = []
    for p in HOOK_DIR.glob("*.toml"):
        try:
            data = tomli.loads(p.read_text())
            h = data.get("hook", {})
            hooks.append(Hook(
                name=h.get("name", p.stem),
                trigger=h.get("trigger", {}),
                command=h.get("command", ""),
                async_exec=h.get("async", True)
            ))
        except Exception:
            pass
    return hooks

class HookEngine:
    def __init__(self):
        self.hooks = load_hooks()
        self._thread = None
        self._stop = threading.Event()

    def start(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._watch, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def _watch(self):
        if not HOOK_DIR.exists():
            return
        try:
            for changes in watch(str(HOOK_DIR.resolve()), stop_event=self._stop):
                for change, path in changes:
                    if any(x in path for x in [".pyc", ".pyo", ".git", ".rumbod", "__pycache__", "node_modules"]):
                        continue
                    for hook in self.hooks:
                        if self._match(hook, path):
                            self._run(hook, path)
        except OSError:
            pass

    def _match(self, hook: Hook, path: str) -> bool:
        trig = hook.trigger
        if trig.get("type") == "file_change":
            import fnmatch
            for pat in trig.get("patterns", []):
                if fnmatch.fnmatch(path, pat):
                    return True
        return False

    def _run(self, hook: Hook, filepath: str):
        cmd = hook.command.replace("{file}", shlex.quote(filepath)).replace("{cwd}", str(Path.cwd()))
        if hook.async_exec:
            subprocess.Popen(cmd, shell=True)
        else:
            subprocess.run(cmd, shell=True, timeout=30)

engine = HookEngine()