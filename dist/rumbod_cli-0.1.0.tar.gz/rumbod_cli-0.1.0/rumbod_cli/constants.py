"""Shared constants for rumbod-cli."""
import os

# Rum home directory — completely separate from ~/.claude/ (Claude Code)
RUM_HOME = os.path.join(os.path.expanduser("~"), ".rum")
RUM_SKILLS = os.path.join(RUM_HOME, "skills")
RUM_KB_PATH = os.path.join(RUM_HOME, "knowledge-base.md")
RUM_KB_OPS = os.path.join(RUM_HOME, "knowledge-ops.py")
RUM_MONITOR = os.path.join(RUM_HOME, "agent-monitor", "monitor.py")
RUM_PONYTAIL = os.path.join(RUM_HOME, "ponytail", "SKILL.md")

SLASH_COMMANDS: dict[str, str] = {
    "/help": "Show this help message",
    "/model": "Show or change the current model (/model list, /model <name>)",
    "/models": "Interactive model picker",
    "/context": "Show project context summary",
    "/compact": "Clear conversation history",
    "/sessions": "List and manage sessions",
    "/doctor": "Run diagnostics on provider connectivity",
    "/spec": "Manage specs (/spec new <title>, /spec list, /spec approve <id>, /spec verify <id>)",
    "/web_search": "Search the web (<query>)",
    "/web_fetch": "Fetch and read a URL (<url>)",
    "/spawn": "Spawn a sub-agent to work on a task (/spawn <task>)",
    "/task": "Run autonomous multi-step task loop (/task <description>)",
    "/kb": "Query knowledge base (/kb stats, /kb apiusage, /kb run_shell, /kb add <title>|BUG|<body>)",
    "/skill": "Load skills (/skill list, /skill load <name>)",
    "/monitor": "Run agent performance health check (/monitor, /monitor --fix)",
    "/apiusage": "Show API token usage across all sessions",
    "/apikey": "Manage API keys (/apikey list/add/remove/test)",
    "/provider": "Manage providers (/provider list/add/remove/set-main/set-sub/test)",
    "/ponytail": "Manage ponytail lazy dev mode (/ponytail status|lite|full|ultra|off|skill)",
    "/upgrade": "Self-upgrade the package (uv tool upgrade rumbod-cli)",
    "/exit": "Exit the interactive session",
    "/quit": "Exit the interactive session",
    "/clear": "Clear the screen",
    "/cancel": "Cancel the current in-progress operation",
    "/github": "GitHub integration (/github issues <repo>, /github prs <repo>, /github create-issue <repo> <title>, /github repos <owner>, /github search <query>, /github repo <repo>)",
    "/docker": "Docker management (/docker ps, /docker images, /docker logs <container>, /docker stats, /docker info)",
    "/db": "Database query (/db query <path> <sql>, /db tables <path>, /db schema <path> <table>)",
    "/strategies": "Find and list Claude Code strategy files in /root/ECC/",
}

PONYTAIL_STATE_FILE = os.path.join(RUM_HOME, ".ponytail-active")
