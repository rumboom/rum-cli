"""Interactive model picker screen."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Input, ListItem, ListView, Static

from .models import NIM_FREE_MODELS, OPENAI_MODELS, ANTHROPIC_MODELS


class ModelMenu(ModalScreen):
    """Overlay model picker — triggered by /models."""

    def __init__(self):
        super().__init__()
        self._all: list[str] = []
        self._filtered: list[str] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="model-menu"):
            yield Input(placeholder="Search models...", id="model-search")
            yield ListView(id="model-list")

    async def on_mount(self) -> None:
        self._all = []
        for label, models in [
            ("── NVIDIA NIM Free ──", NIM_FREE_MODELS),
            ("── OpenAI ──", OPENAI_MODELS),
            ("── Anthropic ──", ANTHROPIC_MODELS),
        ]:
            self._all.append(label)
            for mid, ctx in models.items():
                self._all.append(f"{mid}  ({ctx:,} ctx)")
        await self._rebuild("")
        search = self.query_one("#model-search", Input)
        search.focus()

    async def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "model-search":
            await self._rebuild(event.value)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "model-search":
            self._dismiss_selected()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        self._dismiss_selected()

    def _dismiss_selected(self) -> None:
        lst = self.query_one("#model-list", ListView)
        ix = lst.index
        if ix is None:
            ix = 0 if self._filtered else None
        if ix is not None and ix < len(self._filtered):
            entry = self._filtered[ix]
            if "──" in entry:
                self.dismiss(None)
                return
            mid = entry.split("  (")[0]
            self.dismiss(mid)
        else:
            self.dismiss(None)

    async def _rebuild(self, q: str) -> None:
        listv = self.query_one("#model-list", ListView)
        await listv.clear()
        self._filtered = []
        ql = q.lower()
        for entry in self._all:
            if ql in entry.lower():
                self._filtered.append(entry)
                label = f"[bold #888]{entry}[/bold #888]" if entry.startswith("──") else entry
                listv.append(ListItem(Static(label)))
        if not self._filtered:
            listv.append(ListItem(Static("[dim]No matching models[/dim]")))
        if self._filtered:
            listv.index = 0

    BINDINGS = [("escape", "dismiss", "Close")]

    CSS = """
    Screen {
        background: transparent !important;
    }
    #model-menu {
        width: 70%;
        height: 75%;
        margin-top: 2;
        background: rgba(10, 10, 25, 0.96);
        border: thick #e94560;
        padding: 0;
    }
    #model-search {
        dock: top;
        margin: 1 1 0 1;
        background: #1a1a3e;
        border: solid #4a4a6a;
    }
    #model-search:focus {
        border: solid #e94560;
    }
    #model-list {
        height: 1fr;
        margin: 1 1 1 1;
    }
    ListItem {
        padding: 0 1;
    }
    ListItem:hover {
        background: $boost;
    }
    ListItem.-highlight {
        background: #e94560;
    }
    """
