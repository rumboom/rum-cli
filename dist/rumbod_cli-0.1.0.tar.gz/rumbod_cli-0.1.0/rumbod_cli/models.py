import os, json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterator
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
from rumbod_cli.apiusage import record_usage

NVIDIA_API_KEY = os.environ.get("RUMBOD_NVIDIA_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
OPENAI_API_KEY = os.environ.get("RUMBOD_OPENAI_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
ANTHROPIC_API_KEY = os.environ.get("RUMBOD_ANTHROPIC_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")

if not NVIDIA_API_KEY:
    print("[WARN] RUMBOD_NVIDIA_API_KEY not set. NIM calls will fail.")

NIM_FREE_MODELS = {
    "nvidia/llama-3.3-nemotron-super-49b-v1": 131_072,
    "nvidia/nvidia-nemotron-nano-9b-v2": 128_000,
    "nvidia/nemotron-3-nano-30b-a3b": 128_000,
    "nvidia/llama-3.1-nemotron-nano-8b-v1": 128_000,
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning": 128_000,
}

OPENAI_MODELS = {
    "openai/gpt-4o": 128_000,
    "openai/gpt-4o-mini": 128_000,
    "openai/o3-mini": 200_000,
    "openai/gpt-4.1": 1_000_000,
    "openai/gpt-4.1-mini": 1_000_000,
    "openai/gpt-4.1-nano": 1_000_000,
}

ANTHROPIC_MODELS = {
    "anthropic/claude-sonnet-4-20250514": 200_000,
    "anthropic/claude-haiku-3-5-20241022": 200_000,
}

class ProviderError(Exception):
    """Base exception for provider-related errors."""
    pass

class ModelNotAvailableError(ProviderError):
    """Exception raised when the requested model is not available."""
    pass

class APIKeyError(ProviderError):
    """Exception raised when API key is invalid or exhausted."""
    pass

class NetworkError(ProviderError):
    """Exception raised for network-related errors."""
    pass

class RateLimitError(ProviderError):
    """Exception raised when rate limit is exceeded."""
    pass

class InvalidResponseError(ProviderError):
    """Exception raised when the response from the model provider is invalid."""
    pass

@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict

class ModelProvider(ABC):
    @abstractmethod
    async def chat(self, messages: list[dict], **params) -> str:
        ...

    @abstractmethod
    async def stream_chat(self, messages: list[dict], **params) -> AsyncIterator[str]:
        ...

    async def chat_with_tools(self, messages: list[dict], tools: list[dict] | None = None, **params) -> tuple[str | None, list[ToolCall]]:
        """Returns (text_content, list_of_tool_calls). One of them will be non-empty."""
        raise NotImplementedError

class NvidiaProvider(ModelProvider):
    def __init__(self, model_id: str, base_url: str = "https://integrate.api.nvidia.com/v1", api_key: str | None = None):
        self.model_id = model_id
        self.base_url = base_url.rstrip("/")
        self.client = httpx.AsyncClient(timeout=120.0, follow_redirects=True)
        self._api_key = api_key or NVIDIA_API_KEY
        if not self._api_key:
            raise APIKeyError("RUMBOD_NVIDIA_API_KEY is empty. Export it before running.")
        
        # Validate model ID
        if not model_id or not isinstance(model_id, str):
            raise ModelNotAvailableError(f"Invalid model ID: {model_id}")
        
        # Check if model is in the free models list
        if model_id not in NIM_FREE_MODELS:
            print(f"[INFO] Model '{model_id}' may require a paid NVIDIA NIM subscription.")

    def _headers(self) -> dict:
        raw = f"Bearer {self._api_key}"
        return {
            "Authorization": raw,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @retry(
        wait=wait_exponential_jitter(initial=1, max=30),
        stop=stop_after_attempt(3),
        retry=retry_if_exception_type((httpx.HTTPStatusError, httpx.TimeoutException)),
        reraise=True,
    )
    async def chat(self, messages: list[dict], **params) -> str:
        payload = {
            "model": self.model_id,
            "messages": messages,
            "temperature": params.get("temperature", 0.3),
            "max_tokens": params.get("max_tokens", 8192),
            "stream": False,
        }
        resp = await self.client.post(f"{self.base_url}/chat/completions", headers=self._headers(), json=payload)
        if resp.status_code in (429, 500, 502, 503, 504):
            detail = resp.text[:300]
            raise httpx.HTTPStatusError(f"NIM {resp.status_code}: {detail}", request=resp.request, response=resp)
        resp.raise_for_status()
        data = resp.json()
        if "choices" not in data or not data["choices"]:
            raise ProviderError(f"NIM returned unexpected response: {json.dumps(data)[:300]}")
        usage = data.get("usage")
        if usage:
            record_usage(
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                model=self.model_id,
            )
        return data["choices"][0]["message"]["content"]

    async def chat_with_tools(self, messages: list[dict], tools: list[dict] | None = None, **params) -> tuple[str | None, list[ToolCall]]:
        payload = {
            "model": self.model_id,
            "messages": messages,
            "temperature": params.get("temperature", 0.3),
            "max_tokens": params.get("max_tokens", 8192),
            "stream": False,
        }
        
        if tools:
            if not isinstance(tools, list):
                raise ValueError("Tools must be a list")
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        
        try:
            resp = await self.client.post(f"{self.base_url}/chat/completions", headers=self._headers(), json=payload)
        except httpx.TimeoutException as e:
            raise NetworkError(f"Request timeout for model '{self.model_id}' with tools: {str(e)}") from e
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:
                raise RateLimitError(f"Rate limit exceeded for model '{self.model_id}' with tools. Please try again later.") from e
            elif e.response.status_code == 401:
                raise APIKeyError(f"Invalid API key for model '{self.model_id}' with tools. Please check your RUMBOD_NVIDIA_API_KEY.") from e
            else:
                raise NetworkError(f"Network error for model '{self.model_id}' with tools: {str(e)}") from e
        except Exception as e:
            raise NetworkError(f"Unexpected error for model '{self.model_id}' with tools: {str(e)}") from e
        
        # Handle different response status codes
        if resp.status_code == 429:
            raise RateLimitError(f"Rate limit exceeded for model '{self.model_id}' with tools. Please try again later.")
        elif resp.status_code == 401:
            raise APIKeyError(f"Invalid API key for model '{self.model_id}' with tools. Please check your RUMBOD_NVIDIA_API_KEY.")
        elif resp.status_code in (500, 502, 503, 504):
            raise NetworkError(f"Service unavailable for model '{self.model_id}' with tools. Please try again later.")
        
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise NetworkError(f"HTTP error for model '{self.model_id}' with tools: {str(e)}") from e
        
        try:
            data = resp.json()
        except json.JSONDecodeError as e:
            raise InvalidResponseError(f"Invalid JSON response from model '{self.model_id}' with tools: {str(e)}") from e
        
        # Validate response structure
        if "choices" not in data or not data["choices"]:
            raise InvalidResponseError(f"NIM returned unexpected response for model '{self.model_id}' with tools: {json.dumps(data)[:300]}")
        
        if not isinstance(data["choices"], list) or len(data["choices"]) == 0:
            raise InvalidResponseError(f"Invalid choices format in response for model '{self.model_id}' with tools")
        
        if not isinstance(data["choices"][0], dict) or "message" not in data["choices"][0]:
            raise InvalidResponseError(f"Invalid message format in response for model '{self.model_id}' with tools")
        
        msg = data["choices"][0]["message"]
        text = msg.get("content")
        tcs = msg.get("tool_calls")
        calls = []
        if tcs:
            if not isinstance(tcs, list):
                raise InvalidResponseError(f"Invalid tool_calls format in response for model '{self.model_id}' with tools")
            
            for i, tc in enumerate(tcs):
                if not isinstance(tc, dict) or "id" not in tc or "function" not in tc:
                    raise InvalidResponseError(f"Invalid tool call format at index {i} in response for model '{self.model_id}' with tools")
                
                args = {}
                try:
                    args = json.loads(tc["function"]["arguments"])
                except Exception:
                    args = {"command": tc["function"]["arguments"]}
                
                if not isinstance(tc["function"]["name"], str):
                    raise InvalidResponseError(f"Invalid tool name at index {i} in response for model '{self.model_id}' with tools")
                
                calls.append(ToolCall(id=tc["id"], name=tc["function"]["name"], arguments=args))
        
        usage = data.get("usage")
        if usage:
            try:
                record_usage(
                    prompt_tokens=usage.get("prompt_tokens", 0),
                    completion_tokens=usage.get("completion_tokens", 0),
                    model=self.model_id,
                )
            except Exception as e:
                print(f"[WARN] Failed to record usage for model '{self.model_id}' with tools: {str(e)}")
        
        return text, calls

    async def stream_chat(self, messages: list[dict], **params) -> AsyncIterator[str]:
        payload = {
            "model": self.model_id,
            "messages": messages,
            "temperature": params.get("temperature", 0.3),
            "max_tokens": params.get("max_tokens", 8192),
            "stream": True,
        }
        last_usage = None
        async with self.client.stream("POST", f"{self.base_url}/chat/completions", headers=self._headers(), json=payload) as resp:
            if resp.status_code in (429, 500, 502, 503, 504):
                raise httpx.HTTPStatusError(f"NIM {resp.status_code}", request=resp.request, response=resp)
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    raw = line[6:]
                    if raw.strip() == "[DONE]":
                        break
                    try:
                        chunk = json.loads(raw)
                        usage = chunk.get("usage")
                        if usage:
                            last_usage = usage
                        delta = chunk["choices"][0]["delta"]
                        if "content" in delta:
                            yield delta["content"]
                    except Exception:
                        pass
        if last_usage:
            record_usage(
                prompt_tokens=last_usage.get("prompt_tokens", 0),
                completion_tokens=last_usage.get("completion_tokens", 0),
                model=self.model_id,
            )

class OpenAIProvider(ModelProvider):
    def __init__(self, model_id: str, api_key: str | None = None):
        self.model_id = model_id
        self._api_key = api_key or OPENAI_API_KEY
        if not self._api_key:
            raise ProviderError("RUMBOD_OPENAI_API_KEY is empty. Export it before running.")
        self.client = httpx.AsyncClient(timeout=120.0, follow_redirects=True)

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    @retry(
        wait=wait_exponential_jitter(initial=1, max=30),
        stop=stop_after_attempt(3),
        retry=retry_if_exception_type((httpx.HTTPStatusError, httpx.TimeoutException)),
        reraise=True,
    )
    async def chat(self, messages: list[dict], **params) -> str:
        payload = {
            "model": self.model_id.replace("openai/", ""),
            "messages": messages,
            "temperature": params.get("temperature", 0.3),
            "max_tokens": params.get("max_tokens", 8192),
            "stream": False,
        }
        resp = await self.client.post("https://api.openai.com/v1/chat/completions", headers=self._headers(), json=payload)
        if resp.status_code in (429, 500, 502, 503, 504):
            raise httpx.HTTPStatusError(f"OpenAI {resp.status_code}", request=resp.request, response=resp)
        resp.raise_for_status()
        data = resp.json()
        usage = data.get("usage")
        if usage:
            record_usage(
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                model=self.model_id,
            )
        return data["choices"][0]["message"]["content"]

    async def chat_with_tools(self, messages: list[dict], tools: list[dict] | None = None, **params) -> tuple[str | None, list[ToolCall]]:
        payload = {
            "model": self.model_id.replace("openai/", ""),
            "messages": messages,
            "temperature": params.get("temperature", 0.3),
            "max_tokens": params.get("max_tokens", 8192),
            "stream": False,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        resp = await self.client.post("https://api.openai.com/v1/chat/completions", headers=self._headers(), json=payload)
        if resp.status_code in (429, 500, 502, 503, 504):
            raise httpx.HTTPStatusError(f"OpenAI {resp.status_code}", request=resp.request, response=resp)
        resp.raise_for_status()
        data = resp.json()
        msg = data["choices"][0]["message"]
        text = msg.get("content")
        tcs = msg.get("tool_calls")
        calls = []
        if tcs:
            for tc in tcs:
                args = {}
                try:
                    args = json.loads(tc["function"]["arguments"])
                except Exception:
                    args = {"command": tc["function"]["arguments"]}
                calls.append(ToolCall(id=tc["id"], name=tc["function"]["name"], arguments=args))
        usage = data.get("usage")
        if usage:
            record_usage(
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                model=self.model_id,
            )
        return text, calls

    async def stream_chat(self, messages: list[dict], **params) -> AsyncIterator[str]:
        payload = {
            "model": self.model_id.replace("openai/", ""),
            "messages": messages,
            "temperature": params.get("temperature", 0.3),
            "max_tokens": params.get("max_tokens", 8192),
            "stream": True,
        }
        last_usage = None
        async with self.client.stream("POST", "https://api.openai.com/v1/chat/completions", headers=self._headers(), json=payload) as resp:
            if resp.status_code in (429, 500, 502, 503, 504):
                raise httpx.HTTPStatusError(f"OpenAI {resp.status_code}", request=resp.request, response=resp)
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    raw = line[6:]
                    if raw.strip() == "[DONE]":
                        break
                    try:
                        chunk = json.loads(raw)
                        usage = chunk.get("usage")
                        if usage:
                            last_usage = usage
                        delta = chunk["choices"][0]["delta"]
                        if "content" in delta:
                            yield delta["content"]
                    except Exception:
                        pass
        if last_usage:
            record_usage(
                prompt_tokens=last_usage.get("prompt_tokens", 0),
                completion_tokens=last_usage.get("completion_tokens", 0),
                model=self.model_id,
            )

class AnthropicProvider(ModelProvider):
    def __init__(self, model_id: str, api_key: str | None = None):
        self.model_id = model_id
        self._api_key = api_key or ANTHROPIC_API_KEY
        if not self._api_key:
            raise ProviderError("RUMBOD_ANTHROPIC_API_KEY is empty. Export it before running.")
        self.client = httpx.AsyncClient(timeout=120.0, follow_redirects=True)

    def _headers(self) -> dict:
        return {
            "x-api-key": self._api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

    @retry(
        wait=wait_exponential_jitter(initial=1, max=30),
        stop=stop_after_attempt(3),
        retry=retry_if_exception_type((httpx.HTTPStatusError, httpx.TimeoutException)),
        reraise=True,
    )
    async def chat(self, messages: list[dict], **params) -> str:
        system, msgs = self._split_system(messages)
        body = {
            "model": self.model_id.replace("anthropic/", ""),
            "messages": msgs,
            "max_tokens": params.get("max_tokens", 8192),
        }
        if system:
            body["system"] = system
        resp = await self.client.post("https://api.anthropic.com/v1/messages", headers=self._headers(), json=body)
        if resp.status_code in (429, 500, 502, 503, 504):
            raise httpx.HTTPStatusError(f"Anthropic {resp.status_code}", request=resp.request, response=resp)
        resp.raise_for_status()
        data = resp.json()
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        usage = data.get("usage")
        if usage:
            record_usage(
                prompt_tokens=usage.get("input_tokens", 0),
                completion_tokens=usage.get("output_tokens", 0),
                model=self.model_id,
            )
        return text

    def _split_system(self, messages: list[dict]) -> tuple[str | None, list[dict]]:
        system_parts = [m["content"] for m in messages if m.get("role") == "system"]
        rest = [m for m in messages if m.get("role") != "system"]
        return ("\n".join(system_parts)) if system_parts else None, rest

    async def chat_with_tools(self, messages: list[dict], tools: list[dict] | None = None, **params) -> tuple[str | None, list[ToolCall]]:
        system, msgs = self._split_system(messages)
        body = {
            "model": self.model_id.replace("anthropic/", ""),
            "messages": msgs,
            "max_tokens": params.get("max_tokens", 8192),
        }
        if system:
            body["system"] = system
        if tools:
            body["tools"] = [{"name": t["function"]["name"], "description": t["function"]["description"], "input_schema": t["function"]["parameters"]} for t in tools]
        resp = await self.client.post("https://api.anthropic.com/v1/messages", headers=self._headers(), json=body)
        if resp.status_code in (429, 500, 502, 503, 504):
            raise httpx.HTTPStatusError(f"Anthropic {resp.status_code}", request=resp.request, response=resp)
        resp.raise_for_status()
        data = resp.json()
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        tcs = [b for b in data.get("content", []) if isinstance(b, dict) and b.get("type") == "tool_use"]
        calls = []
        if tcs:
            for tc in tcs:
                calls.append(ToolCall(id=tc["id"], name=tc["name"], arguments=tc.get("input", {})))
        usage = data.get("usage")
        if usage:
            record_usage(
                prompt_tokens=usage.get("input_tokens", 0),
                completion_tokens=usage.get("output_tokens", 0),
                model=self.model_id,
            )
        return text, calls

    async def stream_chat(self, messages: list[dict], **params) -> AsyncIterator[str]:
        system, msgs = self._split_system(messages)
        body = {
            "model": self.model_id.replace("anthropic/", ""),
            "messages": msgs,
            "max_tokens": params.get("max_tokens", 8192),
            "stream": True,
        }
        if system:
            body["system"] = system
        async with self.client.stream("POST", "https://api.anthropic.com/v1/messages", headers=self._headers(), json=body) as resp:
            if resp.status_code in (429, 500, 502, 503, 504):
                raise httpx.HTTPStatusError(f"Anthropic {resp.status_code}", request=resp.request, response=resp)
            resp.raise_for_status()
            current_type = None
            buffer = ""
            async for line in resp.aiter_lines():
                if line.startswith("event: "):
                    current_type = line[7:].strip()
                    buffer = ""
                elif line.startswith("data: "):
                    if current_type == "content_block_delta":
                        try:
                            d = json.loads(line[6:])
                            delta = d.get("delta", {})
                            if delta.get("type") == "text_delta":
                                yield delta.get("text", "")
                        except Exception:
                            pass
                    elif current_type == "message_stop":
                        break

class FallbackProvider(ModelProvider):
    def __init__(self, model_specs: list[str]):
        self.providers = []
        for spec in model_specs:
            if spec.startswith("nvidia:"):
                mid = spec.split(":", 1)[1]
                self.providers.append(NvidiaProvider(mid))

    async def chat(self, messages: list[dict], **params) -> str:
        if not self.providers:
            raise ProviderError("No providers available in fallback chain")
        
        if not messages or not isinstance(messages, list):
            raise ValueError("Messages must be a non-empty list")
        
        last_err = None
        for i, p in enumerate(self.providers):
            try:
                return await p.chat(messages, **params)
            except APIKeyError as e:
                last_err = e
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with API key error: {str(e)}")
                continue
            except ModelNotAvailableError as e:
                last_err = e
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with model error: {str(e)}")
                continue
            except RateLimitError as e:
                last_err = e
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with rate limit error: {str(e)}")
                continue
            except NetworkError as e:
                last_err = e
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with network error: {str(e)}")
                continue
            except InvalidResponseError as e:
                last_err = e
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with response error: {str(e)}")
                continue
            except Exception as e:
                last_err = e
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with unexpected error: {str(e)}")
                continue
        
        if last_err:
            raise ProviderError(f"All providers in fallback chain failed. Last error: {str(last_err)}") from last_err
        raise ProviderError("All providers in fallback chain failed without specific error")

    async def stream_chat(self, messages: list[dict], **params) -> AsyncIterator[str]:
        if not self.providers:
            raise ProviderError("No providers available in fallback chain")
        
        if not messages or not isinstance(messages, list):
            raise ValueError("Messages must be a non-empty list")
        
        for i, p in enumerate(self.providers):
            try:
                async for chunk in p.stream_chat(messages, **params):
                    yield chunk
                return
            except APIKeyError as e:
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with API key error: {str(e)}")
                continue
            except ModelNotAvailableError as e:
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with model error: {str(e)}")
                continue
            except RateLimitError as e:
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with rate limit error: {str(e)}")
                continue
            except NetworkError as e:
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with network error: {str(e)}")
                continue
            except InvalidResponseError as e:
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with response error: {str(e)}")
                continue
            except Exception as e:
                print(f"[INFO] Provider {i+1} ({p.model_id}) failed with unexpected error: {str(e)}")
                continue
        
        return

class MultiKeyProvider(ModelProvider):
    def __init__(self, model_spec: str):
        self.model_spec = model_spec
        self._mid = model_spec.split(":", 1)[1] if ":" in model_spec else "nvidia/llama-3.3-nemotron-super-49b-v1"

    async def chat(self, messages: list[dict], **params) -> str:
        from rumbod_cli.apikeys import get_next_key, update_key_status
        
        if not messages or not isinstance(messages, list):
            raise ValueError("Messages must be a non-empty list")
        
        api_key = await get_next_key()
        if api_key is None:
            raise APIKeyError("No working API keys available. Please add a valid API key.")
        
        prov = NvidiaProvider(self._mid, api_key=api_key)
        try:
            return await prov.chat(messages, **params)
        except APIKeyError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] API key failed: {str(e)}")
            fallback = await get_next_key(exclude_env=True)
            if fallback:
                print(f"[INFO] Trying fallback API key")
                prov2 = NvidiaProvider(self._mid, api_key=fallback)
                return await prov2.chat(messages, **params)
            raise
        except ModelNotAvailableError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Model not available: {str(e)}")
            raise
        except RateLimitError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Rate limit exceeded: {str(e)}")
            raise
        except NetworkError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Network error: {str(e)}")
            raise
        except InvalidResponseError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Invalid response: {str(e)}")
            raise
        except Exception as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Unexpected error: {str(e)}")
            fallback = await get_next_key(exclude_env=True)
            if fallback:
                print(f"[INFO] Trying fallback API key")
                prov2 = NvidiaProvider(self._mid, api_key=fallback)
                return await prov2.chat(messages, **params)
            raise

    async def stream_chat(self, messages: list[dict], **params) -> AsyncIterator[str]:
        from rumbod_cli.apikeys import get_next_key, update_key_status
        
        if not messages or not isinstance(messages, list):
            raise ValueError("Messages must be a non-empty list")
        
        api_key = await get_next_key()
        if api_key is None:
            raise APIKeyError("No working API keys available. Please add a valid API key.")
        
        prov = NvidiaProvider(self._mid, api_key=api_key)
        try:
            async for chunk in prov.stream_chat(messages, **params):
                yield chunk
        except APIKeyError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] API key failed: {str(e)}")
            raise
        except ModelNotAvailableError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Model not available: {str(e)}")
            raise
        except RateLimitError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Rate limit exceeded: {str(e)}")
            raise
        except NetworkError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Network error: {str(e)}")
            raise
        except InvalidResponseError as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Invalid response: {str(e)}")
            raise
        except Exception as e:
            await update_key_status(api_key, False, str(e)[:150])
            print(f"[INFO] Unexpected error: {str(e)}")
            fallback = await get_next_key(exclude_env=True)
            if fallback:
                print(f"[INFO] Trying fallback API key")
                prov2 = NvidiaProvider(self._mid, api_key=fallback)
                async for chunk in prov2.stream_chat(messages, **params):
                    yield chunk
            raise


def normalize_model(model: str) -> str:
    """Normalize a model name to include the nvidia/ prefix if missing."""
    if not model:
        return model
    for prefix in ("nvidia:", "nvidia/", "openai:", "anthropic:"):
        if model.startswith(prefix):
            return model
    return f"nvidia:{model}"


def get_provider(model_spec: str, api_key: str | None = None) -> ModelProvider:
    if not model_spec or not isinstance(model_spec, str):
        raise ValueError("Model specification must be a non-empty string")

    if model_spec == "auto":
        from rumbod_cli.config import get_config
        cfg = get_config()
        priority = getattr(cfg.model, "provider_priority", ["nvidia", "openai", "anthropic"])
        for prov_name in priority:
            if prov_name == "nvidia" and NVIDIA_API_KEY:
                return NvidiaProvider("nvidia/llama-3.3-nemotron-super-49b-v1")
            elif prov_name == "openai" and OPENAI_API_KEY:
                return OpenAIProvider("openai/gpt-4o")
            elif prov_name == "anthropic" and ANTHROPIC_API_KEY:
                return AnthropicProvider("anthropic/claude-sonnet-4-20250514")
        if NVIDIA_API_KEY:
            return NvidiaProvider("nvidia/llama-3.3-nemotron-super-49b-v1")
        raise ProviderError("No API keys configured. Set RUMBOD_NVIDIA_API_KEY, RUMBOD_OPENAI_API_KEY, or RUMBOD_ANTHROPIC_API_KEY.")

    if model_spec.startswith("nvidia:") or model_spec.startswith("nvidia/"):
        if model_spec.startswith("nvidia:"):
            mid = model_spec.split(":", 1)[1]
        else:
            mid = model_spec
        if not mid.startswith("nvidia/"):
            mid = f"nvidia/{mid}"
        if api_key:
            if not isinstance(api_key, str) or not api_key.strip():
                raise APIKeyError("API key must be a non-empty string")
            return NvidiaProvider(mid, api_key=api_key.strip())
        return NvidiaProvider(mid)

    if model_spec.startswith("openai:"):
        mid = model_spec
        return OpenAIProvider(mid, api_key=api_key)

    if model_spec.startswith("anthropic:"):
        mid = model_spec
        return AnthropicProvider(mid, api_key=api_key)

    from rumbod_cli.config import get_config
    cfg = get_config()

    if not hasattr(cfg, 'model') or not hasattr(cfg.model, 'fallback_chain'):
        raise ProviderError("Invalid configuration: missing model.fallback_chain")

    fallback_chain = [model_spec] + cfg.model.fallback_chain
    if not fallback_chain:
        raise ProviderError("Fallback chain cannot be empty")

    return FallbackProvider(fallback_chain)