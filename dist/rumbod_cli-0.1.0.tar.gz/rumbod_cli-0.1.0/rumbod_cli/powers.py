from pathlib import Path
from dataclasses import dataclass
import tomli

POWER_DIR = Path(".rumbod/powers")
POWER_DIR.mkdir(parents=True, exist_ok=True)

@dataclass
class Power:
    name: str
    description: str
    context_files: list[str]
    tools: list[str]
    prompt_fragment: str

def load_powers() -> dict[str, Power]:
    powers = {}
    for p in POWER_DIR.glob("*.toml"):
        try:
            data = tomli.loads(p.read_text())
            pw = data.get("power", {})
            powers[pw["name"]] = Power(
                name=pw["name"],
                description=pw.get("description", ""),
                context_files=pw.get("context_files", []),
                tools=pw.get("tools", []),
                prompt_fragment=pw.get("prompt_fragment", "")
            )
        except Exception:
            pass
    return powers

def get_power(name: str) -> Power | None:
    return load_powers().get(name)