from pathlib import Path
import fnmatch
import yaml

STEERING_DIR = Path(".rumbod/steering")
STEERING_DIR.mkdir(parents=True, exist_ok=True)

def load_steering() -> dict[str, str]:
    rules = {}
    for p in STEERING_DIR.glob("*.md"):
        rules[p.stem] = p.read_text()
    return rules

def match_steering(filepath: str, rules: dict[str, str]) -> list[str]:
    matched = []
    for name, content in rules.items():
        if content.startswith("---"):
            try:
                fm = yaml.safe_load(content.split("---", 2)[1])
                for pat in fm.get("globs", [f"**/{name}.md"]):
                    if fnmatch.fnmatch(filepath, pat):
                        matched.append(content)
            except Exception:
                pass
    return matched

def get_steering_for_files(filepaths: list[str]) -> str:
    rules = load_steering()
    all_matched = []
    for fp in filepaths:
        all_matched.extend(match_steering(fp, rules))
    # deduplicate
    seen = set()
    unique = []
    for m in all_matched:
        if m not in seen:
            seen.add(m)
            unique.append(m)
    return "\n\n".join(unique)