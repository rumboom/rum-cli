import json
import threading
import time
from pathlib import Path
from dataclasses import dataclass, asdict

_KEYS_FILE = Path(".rumbod/apikeys.json")
_FILE_LOCK = threading.Lock()
_RR_LOCK = threading.Lock()
_RR_INDEX: int = 0


@dataclass
class ApiKeyEntry:
    key: str
    label: str = ""
    added_at: str = ""
    working: bool | None = None
    error: str | None = None
    last_tested: str | None = None
    masked: str = ""

    def __post_init__(self):
        if not self.masked and self.key:
            k = self.key.strip()
            self.masked = k[:6] + "..." + k[-4:] if len(k) > 12 else k[:6] + "..."
        if not self.added_at:
            self.added_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _ensure_file():
    _KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not _KEYS_FILE.exists():
        _KEYS_FILE.write_text(json.dumps({"keys": [], "round_robin_index": 0}))


def _read() -> dict:
    with _FILE_LOCK:
        _ensure_file()
        try:
            return json.loads(_KEYS_FILE.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            data = {"keys": [], "round_robin_index": 0}
            _KEYS_FILE.write_text(json.dumps(data))
            return data


def _write(data: dict):
    with _FILE_LOCK:
        _KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
        _KEYS_FILE.write_text(json.dumps(data, indent=2))


def all_keys() -> list[ApiKeyEntry]:
    data = _read()
    return [ApiKeyEntry(**k) for k in data.get("keys", [])]


def add_key(key: str, label: str = "") -> ApiKeyEntry:
    key = key.strip().replace("\n", "").replace("\r", "").replace(" ", "")
    if not key:
        raise ValueError("API key cannot be empty")
    if len(key) < 20:
        raise ValueError(f"API key too short ({len(key)} chars, expected 20+)")
    data = _read()
    for k in data["keys"]:
        if k["key"] == key:
            raise ValueError("API key already exists")
    entry = ApiKeyEntry(key=key, label=label or key[:12] + "...")
    data["keys"].append(asdict(entry))
    _write(data)
    return entry


def remove_key(index: int) -> bool:
    data = _read()
    if 0 <= index < len(data["keys"]):
        data["keys"].pop(index)
        if data["round_robin_index"] >= len(data["keys"]):
            data["round_robin_index"] = 0
        _write(data)
        return True
    return False


def remove_key_by_label(label: str) -> bool:
    data = _read()
    for i, k in enumerate(data["keys"]):
        if k.get("label", "") == label or k.get("masked", "") == label:
            data["keys"].pop(i)
            if data["round_robin_index"] >= len(data["keys"]):
                data["round_robin_index"] = 0
            _write(data)
            return True
    return False


_HIDDEN_KEY = "__env_RUMBOD_NVIDIA_API_KEY__"


def env_key_entry() -> ApiKeyEntry:
    import os
    raw = os.environ.get("RUMBOD_NVIDIA_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
    masked = raw[:6] + "..." + raw[-4:] if len(raw) > 12 else "SET" if raw else "NOT SET"
    return ApiKeyEntry(
        key=_HIDDEN_KEY,
        label="env:RUMBOD_NVIDIA_API_KEY",
        added_at="always",
        working=bool(raw),
        masked=masked,
    )


def get_working_keys(exclude_env: bool = False) -> list[str]:
    import os
    keys: list[str] = []
    if not exclude_env:
        raw = os.environ.get("RUMBOD_NVIDIA_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
        if raw:
            keys.append(raw)
    for entry in all_keys():
        if entry.working is not False:
            keys.append(entry.key)
    return keys


def get_next_key(exclude_env: bool = False) -> str | None:
    global _RR_INDEX
    keys = get_working_keys(exclude_env=exclude_env)
    if not keys:
        return None
    with _RR_LOCK:
        if _RR_INDEX >= len(keys):
            _RR_INDEX = 0
        key = keys[_RR_INDEX]
        _RR_INDEX = (_RR_INDEX + 1) % len(keys)
    return key


def count_keys() -> int:
    return len(all_keys())


def set_key_working(index: int, working: bool, error: str | None = None):
    data = _read()
    if 0 <= index < len(data["keys"]):
        data["keys"][index]["working"] = working
        data["keys"][index]["error"] = error
        data["keys"][index]["last_tested"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _write(data)


def update_key_status(key: str, working: bool, error: str | None = None):
    data = _read()
    for k in data["keys"]:
        if k["key"] == key:
            k["working"] = working
            k["error"] = error
            k["last_tested"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            _write(data)
            return


def test_key(key_entry: ApiKeyEntry, model: str = "nvidia/llama-3.3-nemotron-super-49b-v1") -> tuple[bool, str | None]:
    import httpx, os
    from rumbod_cli.apiusage import record_usage

    if key_entry.key == _HIDDEN_KEY:
        actual_key = os.environ.get("RUMBOD_NVIDIA_API_KEY", "").strip().replace("\n", "").replace("\r", "").replace(" ", "")
    else:
        actual_key = key_entry.key

    if not actual_key:
        return False, "Empty key"

    import httpx
    with httpx.Client(timeout=30.0) as client:
        headers = {
            "Authorization": f"Bearer {actual_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": "ping. Reply only: pong"}],
            "max_tokens": 16,
            "stream": False,
        }
        try:
            resp = client.post(
                "https://integrate.api.nvidia.com/v1/chat/completions",
                headers=headers, json=payload,
            )
            if resp.status_code == 200:
                data = resp.json()
                usage = data.get("usage")
                if usage:
                    record_usage(
                        prompt_tokens=usage.get("prompt_tokens", 0),
                        completion_tokens=usage.get("completion_tokens", 0),
                        model=model,
                    )
                return True, None
            detail = resp.text[:150]
            if resp.status_code == 401:
                return False, "401 Unauthorized — invalid API key"
            elif resp.status_code == 402:
                return False, "402 Payment Required — quota exhausted"
            elif resp.status_code == 429:
                return False, "429 Rate Limited — try later"
            else:
                return False, f"{resp.status_code}: {detail}"
        except httpx.TimeoutException:
            return False, "Connection timed out"
        except Exception as e:
            return False, str(e)[:150]


def test_all_keys(model: str = "nvidia/llama-3.3-nemotron-super-49b-v1") -> list[dict]:
    results = []
    keys = all_keys()
    for i, entry in enumerate(keys):
        ok, err = test_key(entry, model)
        set_key_working(i, ok, err)
        results.append({"index": i, "label": entry.label, "working": ok, "error": err})
    return results


def reset_keys():
    _write({"keys": [], "round_robin_index": 0})
