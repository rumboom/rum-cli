import asyncio
import json
import os
import re
import subprocess
from pathlib import Path


from textual import work
from textual.app import App, ComposeResult
from textual.containers import  Horizontal, Vertical
from textual.widgets import Header, Input, RichLog, Label
from .command_menu import CommandMenu
from .model_menu import ModelMenu
from .constants import SLASH_COMMANDS, PONYTAIL_STATE_FILE, RUM_MONITOR, RUM_KB_PATH, RUM_KB_OPS, RUM_SKILLS, RUM_PONYTAIL

from rumbod_cli.config import get_config
from rumbod_cli.memory import load_conversation, append_message, clear_conversation, list_sessions
from rumbod_cli.models import get_provider, normalize_model, NVIDIA_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY, NIM_FREE_MODELS, OPENAI_MODELS, ANTHROPIC_MODELS, ToolCall
from rumbod_cli.context import scan_project, build_system_prompt
from rumbod_cli.spec import new_spec, list_specs, approve_spec, verify_spec
from rumbod_cli.tools.websearch import web_search, web_fetch
from rumbod_cli.tools.github_ import list_issues, list_prs, create_issue, list_repos, search_repos, get_repo
from rumbod_cli.tools.docker_ import ps as docker_ps, images as docker_images, logs as docker_logs, stats as docker_stats, info as docker_info
from rumbod_cli.tools.database import query_sqlite, list_tables, table_schema
from rumbod_cli.subagent import SubAgentConfig, spawn_agent
from rumbod_cli.apiusage import get_usage_summary
from rumbod_cli.apikeys import (
    all_keys, add_key, remove_key, remove_key_by_label,
    env_key_entry,
)
from rumbod_cli.providers import (
    all_providers, add_provider, remove_provider,
    get_providers_for_role, reset_providers,
    resolve_api_key,
)

PONYTAIL_STATE = os.path.expanduser(PONYTAIL_STATE_FILE)

def _read_ponytail_mode():
    try:
        return Path(PONYTAIL_STATE).read_text().strip()
    except Exception:
        return "off"

def _write_ponytail_mode(mode: str):
    Path(PONYTAIL_STATE).parent.mkdir(parents=True, exist_ok=True)
    Path(PONYTAIL_STATE).write_text(mode)

def _read_ponytail_skill():
    skill_path = Path(RUM_PONYTAIL).expanduser()
    if skill_path.exists():
        return skill_path.read_text()
    return None



PREAMBLE = """
[bold cyan]╭─ rumbod interactive ─────────────────────────────╮[/bold cyan]
[bold cyan]│[/bold cyan]  [dim]NVIDIA · OpenAI · Anthropic · type / for menu · /help[/dim]  [bold cyan]│[/bold cyan]
[bold cyan]╰──────────────────────────────────────────────────╯[/bold cyan]
"""


class RumbodInteractive(App):
    TITLE = "rumbod interactive"
    CSS = """
    Screen {
        background: #0d1117;
    }
    #chat-view {
        height: 1fr;
        min-height: 10;
        border: solid #30363d;
        background: #161b22;
        padding: 1 2;
        margin: 0;
    }
    #chat-view .user-line {
        color: #58a6ff;
        text-style: bold;
    }
    #chat-view .assistant-line {
        color: #7ee787;
    }
    #chat-view .sep-line {
        color: #30363d;
    }
    #chat-view .tool-line {
        color: #d2a8ff;
    }
    #bottom-dock {
        dock: bottom;
        height: 5;
        background: #0d1117;
        border-top: solid #30363d;
    }
    #input-container {
        height: 3;
        padding: 0 1;
        margin: 0;
    }
    #msg-input {
        width: 1fr;
        height: 3;
        background: #161b22;
        color: #c9d1d9;
        border: solid #30363d;
        padding: 0 1;
    }
    #msg-input:focus {
        border: solid #58a6ff;
    }
    #status-bar {
        height: 1;
        background: #161b22;
        color: #8b949e;
        text-style: bold;
        padding: 0 1;
    }
    #status-bar .thinking {
        color: #d2a8ff;
        text-style: bold italic;
    }
    #status-bar .ready {
        color: #7ee787;
    }
    RichLog {
        background: #161b22;
    }
    """

    def __init__(self):
        super().__init__()
        self._agent_status = "initializing..."
        self._loading_done = False
        self._menu_open = False
        self._cancel_requested = False
        self.messages = []
        self.conversation = []
        self.provider = None
        self.model_name = "loading..."
        self.cfg = None

    async def _lazy_init(self) -> None:
        """Defer slow init so UI renders instantly."""
        try:
            self.cfg = get_config()
            main_provs = get_providers_for_role("main")
            if main_provs:
                first = main_provs[0]
                self.model_name = normalize_model(first.model)
                self.provider = get_provider(self.model_name, api_key=await resolve_api_key(first.api_key_ref))
            else:
                self.provider = get_provider(self.cfg.model.default)
                self.model_name = self.cfg.model.default
            system_content = build_system_prompt(scan_project(Path.cwd()), "interactive")
            self.messages = [{"role": "system", "content": system_content}]
            for h in load_conversation():
                if h["role"] in ("user", "assistant"):
                    self.messages.append({"role": h["role"], "content": h["content"]})
                    self.conversation.append({"role": h["role"], "content": h["content"]})
            if len(self.messages) > 16:
                sys_msgs = [m for m in self.messages if m["role"] == "system"]
                non_sys = [m for m in self.messages if m["role"] != "system"]
                keep_non_sys = non_sys[-(15 - len(sys_msgs)):]
                self.messages = sys_msgs + keep_non_sys
                self.conversation = self.conversation[-(15 - len(sys_msgs)):]
            self._loading_done = True
            self._agent_status = "ready"
            self._update_status_bar()
            chat = self.query_one("#chat-view", RichLog)
            chat.write(f"[dim]Model: {self.model_name} | Key: {'[green]SET[/green]' if NVIDIA_API_KEY else '[red]NOT SET[/red]'}[/dim]")
            chat.write("")
        except Exception as e:
            self._agent_status = f"init error: {e}"

    def _update_status_bar(self) -> None:
        status = self.query_one("#status-bar", Label)
        model_part = self.model_name.split("/")[-1] if "/" in self.model_name else self.model_name
        status_text = f"  [{model_part}]  "
        if "think" in self._agent_status.lower():
            status_text += f"[#d2a8ff]{self._agent_status}[/#d2a8ff]"
        elif self._agent_status == "ready":
            status_text += "[#7ee787]● ready[/#7ee787]"
        else:
            status_text += self._agent_status
        status.update(status_text)

    def compose(self) -> ComposeResult:
        yield Header()
        yield RichLog(id="chat-view", markup=True, highlight=True, wrap=True)
        yield Vertical(
            Horizontal(
                Input(id="msg-input", placeholder="Type a message or /command ..."),
                id="input-container",
            ),
            Label(id="status-bar"),
            id="bottom-dock",
        )

    def on_mount(self) -> None:
        chat = self.query_one("#chat-view", RichLog)
        chat.write(PREAMBLE)
        chat.write("[dim]Loading model configuration...[/dim]")
        self._update_status_bar()
        self.query_one("#msg-input", Input).focus()
        self.set_timer(0.01, self._lazy_init)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "msg-input":
            return
        text = event.value.strip()
        if not text:
            return
        self.query_one("#msg-input", Input).clear()
        if text.startswith("/"):
            self.handle_slash(text)
        else:
            self.handle_message(text)

    def handle_slash(self, text: str) -> None:
        parts = text.split(maxsplit=1)
        if not parts:
            return
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        chat = self.query_one("#chat-view", RichLog)

        if cmd in ("/exit", "/quit"):
            self.exit()
        elif cmd == "/help":
            chat.write("")
            chat.write("[bold cyan]Available Commands:[/bold cyan]")
            for c, desc in SLASH_COMMANDS.items():
                chat.write(f"  [bold]{c:<20}[/bold] {desc}")
            chat.write("")
        elif cmd == "/model":
            if arg == "list":
                chat.write("")
                chat.write("[bold cyan]Available Models:[/bold cyan]")
                chat.write("")
                chat.write("[bold underline]NVIDIA NIM Free:[/bold underline]")
                for mid, ctx in NIM_FREE_MODELS.items():
                    chat.write(f"  [bold]{mid:<55}[/bold]  {ctx:,} context")
                chat.write("")
                chat.write("[bold underline]OpenAI:[/bold underline]")
                for mid, ctx in OPENAI_MODELS.items():
                    chat.write(f"  [bold]{mid:<55}[/bold]  {ctx:,} context")
                chat.write("")
                chat.write("[bold underline]Anthropic:[/bold underline]")
                for mid, ctx in ANTHROPIC_MODELS.items():
                    chat.write(f"  [bold]{mid:<55}[/bold]  {ctx:,} context")
                chat.write(f"[dim]Current: {self.model_name}[/dim]")
            elif arg:
                full = normalize_model(arg)
                try:
                    self.provider = get_provider(full)
                    self.model_name = full
                    self.cfg.model.default = full
                    chat.write(f"[green]Model switched to: {full}[/green]")
                    try:
                        self.cfg.save()
                    except AttributeError:
                        pass
                    self._update_status_bar()
                except Exception as e:
                    chat.write(f"[red]Failed to switch model: {e}[/red]")
            else:
                chat.write(f"[dim]Current model: {self.model_name}[/dim]")
        elif cmd == "/models":
            self._menu_open = True
            self.push_screen(ModelMenu(), self._model_menu_selected)
        elif cmd == "/context":
            ctx = scan_project(Path.cwd())
            chat.write("")
            chat.write("[bold cyan]Project Context:[/bold cyan]")
            chat.write(f"  [bold]Root:[/bold] {ctx.root}")
            chat.write(f"  [bold]Languages:[/bold] {', '.join(ctx.languages) or 'unknown'}")
            chat.write(f"  [bold]Key files:[/bold] {', '.join(ctx.key_files) or 'none'}")
            chat.write(f"  [bold]Git status:[/bold] {ctx.git_status[:300] or 'clean'}")
            chat.write(f"  [bold]Recent commits:[/bold] {'; '.join(ctx.recent_commits[:5]) or 'none'}")
            if ctx.tree:
                chat.write(f"[dim]{ctx.tree[:1000]}[/dim]")
            chat.write("")
        elif cmd == "/compact":
            self.messages = [self.messages[0]]
            self.conversation = []
            clear_conversation()
            chat.write("[yellow]Conversation cleared (memory + disk).[/yellow]")
        elif cmd == "/sessions":
            sessions = list_sessions()
            if not sessions:
                chat.write("[dim]No saved sessions.[/dim]")
            else:
                chat.write("[bold cyan]Sessions:[/bold cyan]")
                for s in sessions:
                    chat.write(
                        f"  {s['id']:<30} {s['messages']} msgs  {s['updated'][:19]}"
                    )
        elif cmd == "/doctor":
            chat.write("[bold cyan]Running diagnostics...[/bold cyan]")
            chat.write(f"  [bold]Config:[/bold] {self.cfg.model.default}")
            chat.write(f"  [bold]NVIDIA Key:[/bold] {'[green]SET[/green]' if NVIDIA_API_KEY else '[red]NOT SET[/red]'}")
            chat.write(f"  [bold]OpenAI Key:[/bold] {'[green]SET[/green]' if OPENAI_API_KEY else '[red]NOT SET[/red]'}")
            chat.write(f"  [bold]Anthropic Key:[/bold] {'[green]SET[/green]' if ANTHROPIC_API_KEY else '[red]NOT SET[/red]'}")
            self._run_doctor()
        elif cmd == "/clear":
            chat.clear()
        elif cmd == "/spec":
            self.handle_spec(arg, chat)
        elif cmd == "/web_search":
            if arg:
                chat.write(f"[bold cyan]Searching for:[/bold cyan] {arg}")
                self._run_web_search(arg, chat)
            else:
                chat.write("[yellow]Usage: /web_search <query>[/yellow]")
        elif cmd == "/web_fetch":
            if arg:
                chat.write(f"[bold cyan]Fetching:[/bold cyan] {arg}")
                self._run_web_fetch(arg, chat)
            else:
                chat.write("[yellow]Usage: /web_fetch <url>[/yellow]")
        elif cmd == "/spawn":
            if arg:
                self._run_spawn(arg, chat)
            else:
                chat.write("[yellow]Usage: /spawn <task description>[/yellow]")
        elif cmd == "/task":
            if arg:
                self._run_task_loop(arg, chat)
            else:
                chat.write("[yellow]Usage: /task <task description>[/yellow]")
        elif cmd == "/kb":
            self._run_kb(arg, chat)
        elif cmd == "/skill":
            self._run_skill(arg, chat)
        elif cmd == "/monitor":
            self._run_monitor(arg, chat)
        elif cmd == "/apiusage":
            data = get_usage_summary()
            chat.write("")
            chat.write("[bold cyan]API Usage (persistent across all sessions):[/bold cyan]")
            chat.write(f"  API calls:        {data['total_calls']}")
            chat.write(f"  Prompt tokens:    {data['total_prompt_tokens']:,}")
            chat.write(f"  Completion tokens: {data['total_completion_tokens']:,}")
            chat.write(f"  Total tokens:     {data['total_tokens']:,}")
            chat.write(f"  Since:            {data.get('since', 'N/A')}")
            models = data.get("models", {})
            if models:
                chat.write("")
                chat.write("[bold]Per-model:[/bold]")
                for m, stats in sorted(models.items()):
                    short = m.split("/")[-1] if "/" in m else m
                    chat.write(
                        f"  [dim]{short}: {stats['calls']} calls, "
                        f"{stats['prompt_tokens']:,}p + "
                        f"{stats['completion_tokens']:,}c = "
                        f"{stats['total_tokens']:,}t[/dim]"
                    )
            chat.write("")
        elif cmd == "/apikey":
            self.handle_apikey(arg, chat)
        elif cmd == "/provider":
            self.handle_provider(arg, chat)
        elif cmd == "/ponytail":
            self.handle_ponytail(arg, chat)
        elif cmd == "/upgrade":
            self._run_upgrade(chat)
        elif cmd == "/github":
            self._run_github(arg, chat)
        elif cmd == "/docker":
            self._run_docker(arg, chat)
        elif cmd == "/db":
            self._run_db(arg, chat)
        elif cmd == "/cancel":
            if self._agent_status not in ("ready", "initializing..."):
                self._cancel_requested = True
                chat.write("[yellow]Cancel requested — stopping after current operation...[/yellow]")
            else:
                chat.write("[dim]No operation in progress to cancel.[/dim]")
        else:
            chat.write(f"[red]Unknown command: {cmd}. Type /help for available commands.[/red]")

    @work(thread=False, exclusive=False)
    async def handle_apikey(self, arg: str, chat) -> None:
        parts = arg.split(maxsplit=1)
        sub = parts[0].lower() if parts else ""
        rest = parts[1] if len(parts) > 1 else ""
        env = env_key_entry()
        stored = all_keys()

        if sub == "list" or not arg:
            chat.write("")
            chat.write("[bold cyan]API Keys:[/bold cyan]")
            chat.write(f"  [bold]0[/bold] (env) {env.label}")
            chat.write(f"      masked: {env.masked} | working: {'[green]YES[/green]' if env.working else '[red]NO[/red]'}")
            for i, k in enumerate(stored, 1):
                status = "[green]OK[/green]" if k.working is True else "[yellow]untested[/yellow]" if k.working is None else f"[red]FAIL[/red]"
                err = f" — {k.error}" if k.error else ""
                chat.write(f"  [bold]{i}[/bold] {k.label}")
                chat.write(f"      masked: {k.masked} | {status}{err}")
            chat.write("")
        elif sub == "add":
            if rest:
                try:
                    entry = add_key(rest)
                    chat.write(f"[green]Added key: {entry.label}[/green]")
                except ValueError as e:
                    chat.write(f"[red]{e}[/red]")
            else:
                chat.write("[yellow]Usage: /apikey add <api_key>[/yellow]")
        elif sub == "remove":
            if rest:
                try:
                    idx = int(rest) - 1
                    if remove_key(idx):
                        chat.write(f"[green]Removed key #{rest}[/green]")
                    else:
                        chat.write(f"[red]Invalid index: {rest}[/red]")
                except ValueError:
                    if remove_key_by_label(rest):
                        chat.write(f"[green]Removed key: {rest}[/green]")
                    else:
                        chat.write(f"[red]Key not found: {rest}[/red]")
            else:
                chat.write("[yellow]Usage: /apikey remove <index or label>[/yellow]")
        elif sub == "test":
            chat.write("[bold cyan]Testing all stored API keys...[/bold cyan]")
            self._run_apikey_test(chat)
        else:
            chat.write("[yellow]Usage: /apikey [list|add <key>|remove <id>|test][/yellow]")

    def handle_provider(self, arg: str, chat) -> None:
        parts = arg.split(maxsplit=1)
        sub = parts[0].lower() if parts else ""
        rest = parts[1] if len(parts) > 1 else ""
        provs = all_providers()

        if sub == "list" or not arg:
            chat.write("")
            chat.write("[bold cyan]Provider Configurations:[/bold cyan]")
            if not provs:
                chat.write("  [dim]No providers configured. Use /provider set-main <model> or /provider add.[/dim]")
            else:
                for i, p in enumerate(provs):
                    status = "[green]OK[/green]" if p.working is True else "[yellow]untested[/yellow]" if p.working is None else f"[red]FAIL[/red]"
                    err = f" — {p.error}" if p.error else ""
                    chat.write(
                        f"  [bold]{i}[/bold] model={p.model} | key={p.api_key_ref} | role={p.role}"
                    )
                    chat.write(f"      {p.label} | {status}{err}")
            chat.write("")
            chat.write("[dim]Available models:[/dim]")
            from rumbod_cli.models import NIM_FREE_MODELS, OPENAI_MODELS, ANTHROPIC_MODELS
            for m, ctx in NIM_FREE_MODELS.items():
                chat.write(f"  [dim]{m} ({ctx:,} ctx)[/dim]")
            chat.write("  [dim]OpenAI:[/dim]")
            for m, ctx in OPENAI_MODELS.items():
                chat.write(f"  [dim]{m} ({ctx:,} ctx)[/dim]")
            chat.write("  [dim]Anthropic:[/dim]")
            for m, ctx in ANTHROPIC_MODELS.items():
                chat.write(f"  [dim]{m} ({ctx:,} ctx)[/dim]")
            chat.write("")
        elif sub == "add":
            parts2 = rest.split(maxsplit=2)
            if len(parts2) >= 1:
                model = parts2[0]
                api_key_ref = parts2[1] if len(parts2) > 1 else "env"
                role = parts2[2] if len(parts2) > 2 else "both"
                try:
                    entry = add_provider(model, api_key_ref, role)
                    chat.write(f"[green]Added provider: {entry.label}[/green]")
                except ValueError as e:
                    chat.write(f"[red]{e}[/red]")
            else:
                chat.write("[yellow]Usage: /provider add <model> [key_ref=env] [role=both][/yellow]")
        elif sub == "remove":
            if rest:
                try:
                    idx = int(rest)
                    if remove_provider(idx):
                        chat.write(f"[green]Removed provider #{rest}[/green]")
                    else:
                        chat.write(f"[red]Invalid index: {rest}[/red]")
                except ValueError:
                    chat.write("[yellow]Provide the index number to remove.[/yellow]")
            else:
                chat.write("[yellow]Usage: /provider remove <index>[/yellow]")
        elif sub == "set-main":
            if rest:
                try:
                    entry = add_provider(rest, "env", "main")
                    self.provider = get_provider(normalize_model(rest))
                    self.model_name = normalize_model(rest)
                    chat.write(f"[green]Main agent model set to: {rest}[/green]")
                    self._update_status_bar()
                except ValueError as e:
                    chat.write(f"[red]{e}[/red]")
            else:
                chat.write("[yellow]Usage: /provider set-main <model>[/yellow]")
        elif sub == "set-sub":
            if rest:
                try:
                    add_provider(rest, "env", "subagent")
                    chat.write(f"[green]Sub-agent model set to: {rest}[/green]")
                except ValueError as e:
                    chat.write(f"[red]{e}[/red]")
            else:
                chat.write("[yellow]Usage: /provider set-sub <model>[/yellow]")
        elif sub == "test":
            stored = all_providers()
            if not stored:
                chat.write("[yellow]No providers to test.[/yellow]")
            else:
                chat.write("[bold cyan]Testing all providers...[/bold cyan]")
                self._run_provider_test(chat)
        elif sub == "reset":
            reset_providers()
            chat.write("[yellow]All provider configurations cleared.[/yellow]")
        else:
            chat.write("[yellow]Usage: /provider [list|add|remove|set-main|set-sub|test|reset][/yellow]")

    @work(thread=False, exclusive=False)
    async def _run_provider_test(self, chat) -> None:
        from rumbod_cli.providers import test_provider, all_providers, set_provider_working
        provs = all_providers()
        for i, entry in enumerate(provs):
            chat.write(f"  Testing [bold]{entry.label}[/bold] ({entry.model}) ...")
            ok, err = await test_provider(entry)
            set_provider_working(i, ok, err)
            if ok:
                chat.write(f"    [green]✓ Working[/green]")
            else:
                chat.write(f"    [red]✗ {err}[/red]")
        chat.write("[bold green]All providers tested.[/bold green]")

    def handle_spec(self, arg: str, chat) -> None:
        parts = arg.split(maxsplit=1)
        sub = parts[0].lower() if parts else ""
        rest = (parts[1] if len(parts) > 1 else "").strip()
        if sub == "new" and rest:
            try:
                s = new_spec(rest)
                chat.write(f"[green]Created spec: {s.id} - {s.title}[/green]")
            except Exception as e:
                chat.write(f"[red]Failed: {e}[/red]")
        elif sub == "list":
            specs = list_specs()
            if specs:
                chat.write("[bold cyan]Specs:[/bold cyan]")
                for s in specs:
                    chat.write(f"  {s.id:<20} {s.title:<30} [{s.status}]  {s.updated[:10]}")
            else:
                chat.write("[dim]No specs found.[/dim]")
        elif sub == "approve" and rest:
            s = approve_spec(rest)
            if s:
                chat.write(f"[green]Approved: {s.id} - {s.title}[/green]")
            else:
                chat.write(f"[red]Spec not found: {rest}[/red]")
        elif sub == "verify" and rest:
            s = verify_spec(rest)
            if s:
                chat.write(f"[green]Verified: {s.id} - {s.title}[/green]")
            else:
                chat.write(f"[red]Spec not found: {rest}[/red]")
        else:
            chat.write("[yellow]Usage: /spec new <title>, /spec list, /spec approve <id>, /spec verify <id>[/yellow]")

    MAX_CONTEXT = 16  # system + 15 exchanges max; older gets pruned

    def _prune_context(self):
        if len(self.messages) > self.MAX_CONTEXT:
            keep_system = self.messages[:1]
            keep_recent = self.messages[-(self.MAX_CONTEXT - 1):]
            pruned_count = len(self.messages) - len(keep_system) - len(keep_recent)
            # Build a summary of what was trimmed by extracting user intents
            trimmed = self.messages[1:-len(keep_recent)]
            topics = set()
            for m in trimmed:
                if m.get("role") == "user":
                    content = m.get("content", "")
                    topics.add(content[:80].strip())
            summary = "; ".join(list(topics)[-5:]) if topics else "general discussion"
            self.messages = keep_system + keep_recent
            self.conversation = self.conversation[-(self.MAX_CONTEXT - 1):]
            note = {"role": "system", "content": f"[trimmed {pruned_count} older exchanges. Topics removed: {summary}]"}
            self.messages.insert(1, note)

    def handle_message(self, text: str) -> None:
        chat = self.query_one("#chat-view", RichLog)
        if not self.provider:
            chat.write("[red]Error: No provider configured. Use /provider set-main <model> first.[/red]")
            return
        chat.write("")
        chat.write(f"[bold white]▌ You:[/bold white] {text}")
        chat.write("[dim]│[/dim]")
        append_message("user", text)
        self.messages.append({"role": "user", "content": text})
        self.conversation.append({"role": "user", "content": text})
        self._prune_context()
        self._agent_status = "thinking..."
        self._update_status_bar()
        self._run_chat()

    @work(thread=False, exclusive=False)
    async def _run_apikey_test(self, chat) -> None:
        from rumbod_cli.apikeys import test_key, all_keys, set_key_working
        keys = all_keys()
        if not keys:
            chat.write("[yellow]No stored keys to test.[/yellow]")
            return
        for i, entry in enumerate(keys):
            chat.write(f"  Testing [bold]{entry.label}[/bold] ...")
            ok, err = test_key(entry)
            set_key_working(i, ok, err)
            if ok:
                chat.write(f"    [green]✓ Working[/green]")
            else:
                chat.write(f"    [red]✗ {err}[/red]")
        chat.write("[bold green]All keys tested.[/bold green]")

    @work(thread=False, exclusive=False)
    async def _run_web_search(self, query: str, chat) -> None:
        try:
            results = await web_search(query)
            chat.write("[bold green]Results:[/bold green]")
            for r in results:
                chat.write(f"  {r}")
        except Exception as e:
            chat.write(f"[bold red]Search failed: {e}[/bold red]")
        chat.write("")

    @work(thread=False, exclusive=False)
    async def _run_web_fetch(self, url: str, chat) -> None:
        try:
            content = await web_fetch(url)
            if len(content) > 2000:
                chat.write(f"[dim]{content[:2000]}...[/dim]\n[dim]... [truncated, full: {len(content)} chars][/dim]")
            else:
                chat.write(f"[dim]{content}[/dim]")
        except Exception as e:
            chat.write(f"[bold red]Fetch failed: {e}[/bold red]")
        chat.write("")

    @work(thread=False, exclusive=False)
    async def _run_spawn(self, task: str, chat) -> None:
        if self._cancel_requested:
            chat.write("[yellow]Cancelled.[/yellow]")
            return
        chat.write(f"[bold cyan]Spawning sub-agent...[/bold cyan]")
        chat.write(f"[dim]Task: {task}[/dim]")
        subchat = self.query_one("#chat-view", RichLog)
        self._cancel_requested = False

        def on_step(step: dict, expected: str) -> None:
            subchat.write(
                f"  [dim]step {step['step']}: "
                f"{step['tool']}({str(step.get('args', {}))[:60]}) → "
                f"{str(step['result'])[:100]}[/dim]"
            )

        try:
            result = await spawn_agent(
                task,
                SubAgentConfig(on_step=on_step),
            )
            if result.success:
                chat.write("")
                chat.write(f"[bold green]✓ Sub-agent complete[/bold green]")
                chat.write(f"  [bold]Summary:[/bold] {result.summary[:500]}")
                chat.write(f"  [dim]Iterations: {result.iterations}[/dim]")
                summary = f"Sub-agent completed task: {task}\n\nResult: {result.summary[:1000]}"
                append_message("assistant", f"[sub-agent] {summary}")
                self.messages.append({"role": "assistant", "content": summary})
                self.conversation.append({"role": "assistant", "content": summary})
            else:
                chat.write("")
                chat.write(f"[bold red]✗ Sub-agent failed[/bold red]")
                chat.write(f"  Error: {result.error}")
        except Exception as e:
            chat.write(f"[bold red]Sub-agent error: {e}[/bold red]")
        chat.write("")

    @work(thread=False, exclusive=False)
    async def _run_task_loop(self, task: str, chat) -> None:
        """Autonomous multi-step task loop — plans, executes, iterates without stopping."""
        from rumbod_cli.task_loop import run_task_loop
        chat.write(f"[bold cyan]Starting autonomous task loop:[/bold cyan] {task}")
        chat.write("[dim]The agent will plan, execute, and iterate until done.[/dim]")
        MAX_AUTONOMOUS_ITER = 15
        try:
            provider = getattr(self, 'provider', None)
            history = await run_task_loop(task, max_iter=MAX_AUTONOMOUS_ITER, provider=provider)
            chat.write("")
            chat.write("[bold green]✓ Task loop complete[/bold green]")
            for h in history[-5:]:
                step = h.get("step", {})
                res = str(h.get("result", ""))[:200]
                chat.write(f"  [dim]step {step.get('step', '?')}: {step.get('tool', '?')} → {res}[/dim]")
            summary = "\n".join(str(h.get("result", ""))[:300] for h in history if h.get("result"))
            append_message("assistant", f"[task-loop] {summary[:1000]}")
            self.messages.append({"role": "assistant", "content": f"Task loop completed for: {task}\n\n{summary[:1000]}"})
        except Exception as e:
            chat.write(f"[bold red]Task loop error: {e}[/bold red]")
        chat.write("")

    @work(thread=False, exclusive=False)
    async def _run_kb(self, arg: str, chat) -> None:
        """Query or add to the knowledge base."""
        parts = arg.split(maxsplit=3) if arg else []
        sub = parts[0].lower() if parts else ""

        KB_PATH = RUM_KB_PATH
        KB_OPS = RUM_KB_OPS

        if sub == "stats":
            try:
                proc = await asyncio.create_subprocess_exec(
                    "python3", KB_OPS, "stats",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
                chat.write("")
                chat.write("[bold cyan]Knowledge Base:[/bold cyan]")
                for line in (stdout.decode() or "No output").split("\n"):
                    chat.write(f"  [dim]{line}[/dim]")
                chat.write("")
            except Exception as e:
                chat.write(f"[red]KB stats error: {e}[/red]")
        elif sub == "add" and len(parts) >= 4:
            title = parts[1]
            cat = parts[2].upper()
            body = " ".join(parts[3:])
            try:
                proc = await asyncio.create_subprocess_exec(
                    "python3", KB_OPS, "add", "--title", title, "--cat", cat, "--body", body,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
                out = (stdout.decode() or stderr.decode() or "").strip()
                if out:
                    chat.write(f"  [dim]{out}[/dim]")
                else:
                    chat.write("[green]KB entry added[/green]")
            except Exception as e:
                chat.write(f"[red]KB add error: {e}[/red]")
        elif sub and sub not in ("stats", "add"):
            query = arg
            try:
                content = Path(KB_PATH).read_text() if os.path.exists(KB_PATH) else ""
                if not content:
                    chat.write("[dim]Knowledge base empty.[/dim]")
                    return
                lines = content.split("\n")
                results = []
                current = []
                q_words = query.lower().split()
                for line in lines:
                    if line.startswith("### "):
                        if current:
                            block_text = "\n".join(current).lower()
                            if all(w in block_text for w in q_words):
                                results.append("\n".join(current))
                        current = [line]
                    else:
                        current.append(line)
                if current:
                    block_text = "\n".join(current).lower()
                    if all(w in block_text for w in q_words):
                        results.append("\n".join(current))
                if results:
                    chat.write("")
                    chat.write(f"[bold cyan]KB matches for '{query}':[/bold cyan]")
                    for r in results[:5]:
                        for rl in r.split("\n")[:10]:
                            chat.write(f"  [dim]{rl}[/dim]")
                        chat.write("")
                else:
                    chat.write(f"[dim]No KB matches for '{query}'.[/dim]")
            except Exception as e:
                chat.write(f"[red]KB error: {e}[/red]")
        else:
            chat.write("[yellow]Usage: /kb stats | /kb add <title> <CAT> <body> | /kb <search terms>[/yellow]")

    def _run_skill(self, arg: str, chat) -> None:
        """List or load skills from RUM_SKILLS."""
        parts = arg.split(maxsplit=1) if arg else []
        sub = parts[0].lower() if parts else ""

        if sub == "list":
            skills_dir = RUM_SKILLS
            if not os.path.isdir(skills_dir):
                chat.write("[dim]No skills directory found.[/dim]")
                return
            chat.write("")
            chat.write("[bold cyan]Available Skills:[/bold cyan]")
            count = 0
            for entry in sorted(os.listdir(skills_dir)):
                skill_md = os.path.join(skills_dir, entry, "SKILL.md")
                if os.path.isfile(skill_md):
                    desc = ""
                    with open(skill_md) as f:
                        for line in f:
                            if line.startswith("description:"):
                                desc = line.split(":", 1)[1].strip()
                                break
                    chat.write(f"  [bold]{entry}[/bold] — [dim]{desc[:80]}[/dim]")
                    count += 1
            if count == 0:
                chat.write("  [dim]No skills found.[/dim]")
            chat.write("")
        elif sub == "load" and len(parts) > 1:
            name = parts[1]
            skill_path = os.path.join(RUM_SKILLS, name, "SKILL.md")
            if not os.path.isfile(skill_path):
                chat.write(f"[red]Skill not found: {name}[/red]")
                return
            content = Path(skill_path).read_text()
            skill_note = f"[Skill: {name} loaded]\n{content[:800]}"
            if hasattr(self, 'messages') and self.messages:
                if self.messages[0].get("role") == "system":
                    self.messages.insert(1, {"role": "system", "content": skill_note})
                else:
                    self.messages.insert(0, {"role": "system", "content": skill_note})
            chat.write(f"[green]Skill '{name}' loaded into context ({len(content)} bytes).[/green]")
        else:
            chat.write("[yellow]Usage: /skill list | /skill load <name>[/yellow]")

    @work(thread=False, exclusive=False)
    async def _run_doctor(self) -> None:
        chat = self.query_one("#chat-view", RichLog)
        try:
            resp = await self.provider.chat([{"role": "user", "content": "ping. Reply only: pong"}])
            chat.write(f"  [bold green]Provider Test: PASS[/bold green]")
            chat.write(f"  [dim]Response: {resp[:80]}[/dim]")
        except Exception as e:
            chat.write(f"  [bold red]Provider Test FAILED: {e}[/bold red]")
        chat.write("")

    @work(thread=False, exclusive=False)
    async def _run_db(self, arg: str, chat) -> None:
        parts = arg.split(maxsplit=2) if arg else []
        sub = parts[0].lower() if parts else ""
        if sub == "tables" and len(parts) >= 2:
            db_path = parts[1]
            chat.write(f"[bold cyan]Tables in {db_path}:[/bold cyan]")
            tables = await list_tables(db_path)
            if tables and "error" in tables[0]:
                chat.write(f"  [red]{tables[0]['error']}[/red]")
            else:
                for t in tables:
                    chat.write(f"  [bold]{t['name']}[/bold]")
        elif sub == "schema" and len(parts) >= 3:
            db_path = parts[1]
            table_name = parts[2]
            schema = await table_schema(db_path, table_name)
            if "error" in schema:
                chat.write(f"  [red]{schema['error']}[/red]")
            else:
                chat.write(f"[bold cyan]Schema for {table_name}:[/bold cyan]")
                for col in schema.get("columns", []):
                    nullable = "NULL" if col["notnull"] == 0 else "NOT NULL"
                    default = f" DEFAULT {col['dflt_value']}" if col["dflt_value"] else ""
                    pk = " PK" if col["pk"] else ""
                    chat.write(f"  [bold]{col['name']}[/bold] {col['type']} {nullable}{default}{pk}")
        elif sub == "query" and len(parts) >= 2:
            db_path = parts[1]
            sql = arg.split(maxsplit=2)[2] if len(arg.split(maxsplit=2)) > 2 else ""
            chat.write(f"[bold cyan]Querying {db_path}...[/bold cyan]")
            chat.write(f"  [dim]SQL: {sql[:200]}[/dim]")
            result = await query_sqlite(db_path, sql)
            if "error" in result:
                chat.write(f"  [red]{result['error']}[/red]")
            elif "rows" in result:
                if result["columns"]:
                    chat.write(f"  [bold]{' | '.join(result['columns'][:10])}[/bold]")
                for row in result["rows"][:20]:
                    vals = [str(v)[:60] for v in list(row.values())[:10]]
                    chat.write(f"  {' | '.join(vals)}")
                if result["count"] > 20:
                    chat.write(f"  [dim]... {result['count'] - 20} more rows[/dim]")
                chat.write(f"  [dim]({result['count']} rows)[/dim]")
            elif "changes" in result:
                chat.write(f"  [green]Query OK ({result['changes']} changes)[/green]")
        else:
            chat.write("[yellow]Usage: /db tables <path> | /db schema <path> <table> | /db query <path> <sql>[/yellow]")

    @work(thread=False, exclusive=False)
    async def _run_docker(self, arg: str, chat) -> None:
        parts = arg.split(maxsplit=1) if arg else []
        sub = parts[0].lower() if parts else ""
        if sub == "ps":
            all_containers = "-a" in arg
            result = await docker_ps(all=all_containers)
            if isinstance(result, list) and result and "error" in result[0]:
                chat.write(f"  [red]{result[0]['error']}[/red]")
            else:
                for c in result[:20]:
                    name = c.get("Names", "?")
                    status = c.get("Status", "?")
                    image = c.get("Image", "?")
                    ports = c.get("Ports", "")
                    chat.write(f"  [bold]{name}[/bold] [dim]{image}[/dim]")
                    chat.write(f"       {status}  Ports: {ports[:40]}")
        elif sub == "images":
            result = await docker_images()
            if isinstance(result, list) and result and "error" in result[0]:
                chat.write(f"  [red]{result[0]['error']}[/red]")
            else:
                for img in result[:20]:
                    repo = img.get("Repository", "?")
                    tag = img.get("Tag", "?")
                    size = img.get("Size", "?")
                    chat.write(f"  [bold]{repo}[/bold]:{tag} [dim]({size})[/dim]")
        elif sub == "logs" and len(parts) >= 2:
            container = parts[1]
            tail = 50
            if "--tail" in arg:
                try:
                    tail = int(arg.split("--tail")[1].strip().split()[0])
                except (ValueError, IndexError):
                    pass
            chat.write(f"[bold cyan]Logs for {container}:[/bold cyan]")
            logs = await docker_logs(container, tail)
            for line in logs.split("\n")[:40]:
                chat.write(f"  [dim]{line[:200]}[/dim]")
        elif sub == "stats":
            result = await docker_stats()
            if "error" in result:
                chat.write(f"  [red]{result['error']}[/red]")
            else:
                for c in result.get("containers", [])[:10]:
                    name = c.get("Name", "?")
                    cpu = c.get("CPUPerc", "?")
                    mem = c.get("MemPerc", "?")
                    mem_usage = c.get("MemUsage", "?")
                    net = c.get("NetIO", "?")
                    chat.write(f"  [bold]{name}[/bold] CPU:{cpu} Mem:{mem} ({mem_usage}) Net:{net[:40]}")
        elif sub == "info":
            result = await docker_info()
            if "error" in result:
                chat.write(f"  [red]{result['error']}[/red]")
            else:
                chat.write(f"  [bold]Containers:[/bold] {result.get('Containers', '?')} running, {result.get('ContainersRunning', '?')} running, {result.get('ContainersPaused', '?')} paused")
                chat.write(f"  [bold]Images:[/bold] {result.get('Images', '?')}")
                chat.write(f"  [bold]Server:[/bold] {result.get('ServerVersion', '?')}")
                chat.write(f"  [bold]OS/Arch:[/bold] {result.get('OperatingSystem', '?')} / {result.get('Architecture', '?')}")
                chat.write(f"  [bold]Memory:[/bold] {result.get('MemTotal', '?')}")
        else:
            chat.write("[yellow]Usage: /docker ps [-a] | /docker images | /docker logs <container> [--tail N] | /docker stats | /docker info[/yellow]")

    @work(thread=False, exclusive=False)
    async def _run_github(self, arg: str, chat) -> None:
        parts = arg.split(maxsplit=2) if arg else []
        sub = parts[0].lower() if parts else ""
        if sub == "issues" and len(parts) >= 2:
            repo = parts[1]
            state = parts[2] if len(parts) > 2 else "open"
            chat.write(f"[bold cyan]Fetching {state} issues for {repo}...[/bold cyan]")
            issues = await list_issues(repo, state)
            for i in issues[:15]:
                if "error" in i:
                    chat.write(f"  [red]{i['error']}[/red]")
                else:
                    chat.write(f"  [bold]#{i['number']}[/bold] {i['title']} [dim]({i['state']})[/dim]")
                    chat.write(f"       {i['url']}")
        elif sub == "prs" and len(parts) >= 2:
            repo = parts[1]
            state = parts[2] if len(parts) > 2 else "open"
            chat.write(f"[bold cyan]Fetching {state} PRs for {repo}...[/bold cyan]")
            prs = await list_prs(repo, state)
            for p in prs[:15]:
                if "error" in p:
                    chat.write(f"  [red]{p['error']}[/red]")
                else:
                    chat.write(f"  [bold]#{p['number']}[/bold] {p['title']} [dim]({p['state']})[/dim]")
                    chat.write(f"       {p['url']}")
        elif sub == "create-issue" and len(parts) >= 3:
            repo = parts[1]
            title = parts[2]
            chat.write(f"[bold cyan]Creating issue in {repo}...[/bold cyan]")
            result = await create_issue(repo, title)
            if "error" in result:
                chat.write(f"  [red]{result['error']}[/red]")
            else:
                chat.write(f"  [green]Created: {result.get('html_url', '')}[/green]")
        elif sub == "repos" and len(parts) >= 2:
            owner = parts[1]
            chat.write(f"[bold cyan]Fetching repos for {owner}...[/bold cyan]")
            repos = await list_repos(owner)
            for r in repos[:20]:
                if "error" in r:
                    chat.write(f"  [red]{r['error']}[/red]")
                else:
                    stars = f"[yellow]★{r['stars']}[/yellow]" if r['stars'] else ""
                    desc = f" — {r['description'][:60]}" if r['description'] else ""
                    chat.write(f"  [bold]{r['name']}[/bold] {stars}{desc}")
        elif sub == "search" and len(parts) >= 2:
            query = parts[1]
            chat.write(f"[bold cyan]Searching GitHub for '{query}'...[/bold cyan]")
            results = await search_repos(query)
            for r in results[:10]:
                if "error" in r:
                    chat.write(f"  [red]{r['error']}[/red]")
                else:
                    stars = f"[yellow]★{r['stars']}[/yellow]" if r['stars'] else ""
                    desc = f" — {r['description'][:60]}" if r['description'] else ""
                    chat.write(f"  [bold]{r['name']}[/bold] {stars}{desc}")
        elif sub == "repo" and len(parts) >= 2:
            repo = parts[1]
            info = await get_repo(repo)
            if "error" in info:
                chat.write(f"  [red]{info['error']}[/red]")
            else:
                chat.write(f"  [bold]{info.get('full_name')}[/bold]")
                chat.write(f"  [dim]{info.get('description', 'No description')}[/dim]")
                chat.write(f"  Stars: {info.get('stargazers_count', 0)} | Forks: {info.get('forks_count', 0)} | Issues: {info.get('open_issues_count', 0)}")
                chat.write(f"  Language: {info.get('language', 'N/A')} | License: {info.get('license', {}).get('spdx_id', 'N/A') if info.get('license') else 'N/A'}")
        else:
            chat.write("[yellow]Usage: /github issues <repo> [state] | /github prs <repo> [state] | /github create-issue <repo> <title> | /github repos <owner> | /github search <query> | /github repo <repo>[/yellow]")

    @work(thread=False, exclusive=False)
    async def _run_upgrade(self, chat) -> None:
        """Self-upgrade the rumbod-cli package via uv."""
        chat.write("[dim]Checking for updates...[/dim]")
        try:
            proc = await asyncio.create_subprocess_exec(
                "uv", "tool", "upgrade", "rumbod-cli",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
            out = (stdout.decode() or stderr.decode() or "").strip()
            if "Updated" in out or "updated" in out:
                chat.write(f"[green]✓ Package updated:[/green] {out[:200]}")
                chat.write("[yellow]Please restart rum-interactive-cli to use the new version.[/yellow]")
            elif "already" in out.lower() or "no newer" in out.lower():
                chat.write(f"[dim]{out[:200]}[/dim]")
                chat.write("[green]✓ Already up to date.[/green]")
            else:
                chat.write(f"[dim]{out[:300]}[/dim]")
        except asyncio.TimeoutError:
            chat.write("[yellow]Upgrade check timed out (120s). Try manually: uv tool upgrade rumbod-cli[/yellow]")
        except FileNotFoundError:
            chat.write("[yellow]uv not found. Install: curl -LsSf https://astral.sh/uv/install.sh | sh[/yellow]")
        except Exception as e:
            chat.write(f"[red]Upgrade error: {e}[/red]")
        chat.write("")

    @work(thread=False, exclusive=False)
    async def _run_monitor(self, arg: str, chat) -> None:
        """Run agent performance health checks."""
        monitor = RUM_MONITOR
        if not os.path.exists(monitor):
            chat.write(f"[red]Agent Monitor not found at {RUM_MONITOR}[/red]")
            return
        do_fix = "--fix" in arg
        try:
            cmd = ["python3", monitor]
            if do_fix:
                cmd.append("--fix")
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=60)
            out = (stdout.decode() or stderr.decode() or "").strip()
            if out:
                for line in out.split("\n"):
                    chat.write(f"  [dim]{line}[/dim]")
            if proc.returncode and proc.returncode != 0:
                chat.write(f"[yellow]Monitor found {proc.returncode} issue(s). Run /monitor --fix to auto-repair.[/yellow]")
            else:
                chat.write("[bold green]All systems healthy.[/bold green]")
        except asyncio.TimeoutError:
            chat.write("[red]Monitor timed out after 60s[/red]")
        except Exception as e:
            chat.write(f"[red]Monitor error: {e}[/red]")
        chat.write("")

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "msg-input":
            return
        val = event.value.strip()
        if val.startswith("/") and not self._menu_open:
            parts = val.split("/", 1)
            initial = parts[1] if len(parts) > 1 else ""
            self._menu_open = True
            inp = self.query_one("#msg-input", Input)
            inp.value = ""
            self.push_screen(CommandMenu(initial=initial), self._menu_selected)

    def _menu_selected(self, cmd: str | None) -> None:
        self._menu_open = False
        inp = self.query_one("#msg-input", Input)
        inp.value = ""
        inp.focus()
        if cmd:
            self.handle_slash(cmd)

    def _model_menu_selected(self, model: str | None) -> None:
        self._menu_open = False
        if model:
            try:
                self.provider = get_provider(model)
                self.model_name = model
                self.cfg.model.default = model
                try:
                    self.cfg.save()
                except AttributeError:
                    pass
                self._update_status_bar()
                chat = self.query_one("#chat-view", RichLog)
                chat.write(f"[green]Model switched to: {model}[/green]")
            except Exception as e:
                chat = self.query_one("#chat-view", RichLog)
                chat.write(f"[red]Failed to switch model: {e}[/red]")
        inp = self.query_one("#msg-input", Input)
        inp.focus()

    def action_exit(self) -> None:
        self.exit()

    def handle_ponytail(self, arg: str, chat) -> None:
        arg = arg.strip().lower()
        if arg in ("", "status"):
            mode = _read_ponytail_mode()
            chat.write("")
            chat.write("[bold cyan]Ponytail Status[/bold cyan]")
            chat.write(f"  Current mode: [bold]{mode}[/bold]")
            if mode != "off":
                skill = _read_ponytail_skill()
                if skill:
                    lines = skill.split("\n")
                    for l in lines[:15]:
                        chat.write(f"  [dim]{l}[/dim]")
                    chat.write("  [dim]...[/dim]")
            skill_path = Path(RUM_PONYTAIL).expanduser()
            chat.write(f"  [dim]Skill: {skill_path}[/dim]")
            chat.write("")
            chat.write("[dim]Set: /ponytail lite | full | ultra | off[/dim]")
            chat.write("")
        elif arg in ("lite", "full", "ultra", "off"):
            mode = arg
            _write_ponytail_mode(mode)
            chat.write(f"[green]Ponytail mode set to: {mode}[/green]")
            skill = _read_ponytail_skill()
            if skill and mode != "off":
                chat.write(f"[dim]Ponytail skill injected ({mode})[/dim]")
                self.messages.insert(1, {"role": "system", "content": f"[ponytail {mode} mode]\n{skill[:2000]}"})
        elif arg == "skill":
            skill = _read_ponytail_skill()
            if skill:
                chat.write("")
                chat.write("[bold cyan]Ponytail SKILL.md[/bold cyan]")
                for line in skill.split("\n"):
                    chat.write(f"  [dim]{line}[/dim]")
                chat.write("")
            else:
                chat.write("[red]Ponytail skill not found at ~/.rum/ponytail/SKILL.md[/red]")
        else:
            chat.write("[yellow]Usage: /ponytail [status|lite|full|ultra|off|skill][/yellow]")

    async def _execute_tool(self, tag: str, content: str) -> str:
        if tag == "shell":
            from rumbod_cli.tools.shell import run_shell
            result = await run_shell(content.strip())
            if "error" in result:
                return f"Error: {result['error']}"
            out = (result.get("stdout", "") or "")[:3000]
            stderr = (result.get("stderr", "") or "")[:1000]
            if stderr:
                out += f"\nstderr: {stderr}"
            rc = result.get("returncode", 0)
            if rc:
                out += f"\n[exit code: {rc}]"
            return out.strip() or f"(exit code {rc}, no output)"
        elif tag == "read":
            path = content.strip()
            try:
                p = Path(path).expanduser()
                if not p.exists():
                    return f"Error: {path} not found"
                text = p.read_text()
                if len(text) > 3000:
                    text = text[:3000] + "\n... [truncated]"
                return text
            except Exception as e:
                return f"Error: {e}"
        elif tag == "web_search":
            return str(await web_search(content.strip()))
        elif tag == "web_fetch":
            return str(await web_fetch(content.strip()))
        elif tag == "write":
            parts = content.strip().split("\n", 1)
            path = parts[0].strip()
            body = parts[1] if len(parts) > 1 else ""
            try:
                Path(path).expanduser().parent.mkdir(parents=True, exist_ok=True)
                Path(path).expanduser().write_text(body)
                return f"Written {len(body)} bytes to {path}"
            except Exception as e:
                return f"Error: {e}"
        elif tag in ("glob", "find"):
            import glob as glob_mod
            path = content.strip()
            try:
                matches = glob_mod.glob(path, recursive=True)
                if len(matches) > 100:
                    matches = matches[:100]
                    matches.append("... [truncated, too many results]")
                return "\n".join(matches) if matches else "No matches"
            except Exception as e:
                return f"Error: {e}"
        elif tag == "find_strategies":
            from rumbod_cli.tools.shell import run_shell
            result = await run_shell("ls /root/ECC/*strategy*.py 2>/dev/null")
            if "error" in result:
                return f"Error: {result['error']}"
            files = [l.strip() for l in result.get("stdout", "").split("\n") if l.strip()]
            if not files:
                return "No strategy files found."
            details = []
            for f in files:
                r2 = await run_shell(f"grep -m1 '^#' '{f}' 2>/dev/null || echo 'no header'")
                header = r2.get("stdout", "unknown").strip()
                details.append(f"{f}: {header}")
            return "\n".join(details)
        return f"Unknown tool: {tag}"

    _TOOL_RE = re.compile(r'<(\w+)>([\s\S]*?)<\/\1>', re.MULTILINE)
    _FENCE_RE = re.compile(r'```(\w+)\n([\s\S]*?)\n```', re.MULTILINE)
    _LANG_TO_TAG = {"shell": "shell", "bash": "shell", "sh": "shell", "zsh": "shell",
                     "python": "shell", "py": "shell", "python3": "shell",
                     "javascript": "shell", "js": "shell",
                     "json": "read", "yaml": "read", "toml": "read",
                     "console": "shell", "terminal": "shell"}

    TOOLS_DEFS = [
        {
            "type": "function",
            "function": {
                "name": "run_shell",
                "description": "Execute a shell command and return stdout/stderr. Use for ls, grep, find, cat, git, python, pip, etc.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Shell command to run (e.g. 'ls -la', 'grep -rni \"query\" /path/')"
                        },
                        "cwd": {
                            "type": "string",
                            "description": "Working directory (defaults to current)",
                        }
                    },
                    "required": ["command"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "read_file",
                "description": "Read the contents of a file",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Absolute path to the file"
                        }
                    },
                    "required": ["path"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "web_search",
                "description": "Search the web for current information on a topic",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query"
                        }
                    },
                    "required": ["query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "web_fetch",
                "description": "Fetch and read the contents of a URL",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "URL to fetch"
                        }
                    },
                    "required": ["url"]
                }
            }
        },
    ]


    async def _execute_tool_call(self, tc: ToolCall) -> str:
        name = tc.name
        args = tc.arguments
        if name == "run_shell":
            from rumbod_cli.tools.shell import run_shell
            result = await run_shell(args.get("command", ""), cwd=args.get("cwd", "."))
            if "error" in result:
                return f"Error: {result['error']}"
            out = (result.get("stdout", "") or "")[:5000]
            stderr = (result.get("stderr", "") or "")[:2000]
            if stderr:
                out += f"\nstderr: {stderr}"
            rc = result.get("returncode", 0)
            if rc:
                out += f"\n[exit code: {rc}]"
            return out.strip() or f"(exit code {rc}, no output)"
        elif name == "read_file":
            path = args.get("path", "")
            try:
                p = Path(path).expanduser()
                if not p.exists():
                    return f"Error: {path} not found"
                text = p.read_text()
                if len(text) > 5000:
                    text = text[:5000] + "\n... [truncated]"
                return text
            except Exception as e:
                return f"Error: {e}"
        elif name == "web_search":
            try:
                results = await web_search(args.get("query", ""))
                return str(results[:3000])
            except Exception as e:
                return f"Search error: {e}"
        elif name == "web_fetch":
            try:
                content = await web_fetch(args.get("url", ""))
                if len(content) > 3000:
                    content = content[:3000] + "... [truncated]"
                return content
            except Exception as e:
                return f"Fetch error: {e}"
        else:
            return f"Unknown tool: {name}"

    @work(thread=False, exclusive=True)
    async def _run_chat(self) -> None:
        chat = self.query_one("#chat-view", RichLog)
        self._cancel_requested = False
        try:
            max_tool_rounds = 10
            for round_idx in range(max_tool_rounds):
                if self._cancel_requested:
                    chat.write("[yellow]Operation cancelled by user.[/yellow]")
                    break
                self._agent_status = f"thinking ({round_idx + 1}/{max_tool_rounds})" if round_idx > 0 else "thinking..."
                self._update_status_bar()

                # Reinforce anti-hallucination before each LLM call
                if round_idx == 0:
                    self.messages.append({
                        "role": "system",
                        "content": "[reminder] Run REAL shell/python commands. NEVER fabricate file contents, command outputs, or search results. If a tool fails, report the error truthfully. Do NOT simulate checkmarks (✅/❌) or fake script output. Actual execution only.[/reminder]"
                    })
                elif round_idx > 0:
                    # Replace the reminder (last system message)
                    self.messages.append({
                        "role": "system",
                        "content": f"[reminder round {round_idx + 1}] Still working. Keep running real commands. No fabricated data.[/reminder]"
                    })

                text, calls = await self.provider.chat_with_tools(self.messages, self.TOOLS_DEFS)

                if not calls:
                    full = text or ""
                    # Anti-hallucination guard: flag text that simulates tool output
                    sim_patterns = ["✅", "❌", "⚠️", "doctor.sh", "./doctor.sh",
                                    "chmod +x doctor.sh", "PASS", "FAIL", "WARN",
                                    "─" * 20]
                    if any(p in full for p in sim_patterns) and len(full) > 100:
                        full += "\n\n[rum: ⚠️ Your response contains simulated output patterns. Run real commands via run_shell instead of fabricating results.]"
                    self.messages.append({"role": "assistant", "content": full})
                    self.conversation.append({"role": "assistant", "content": full})
                    chat.write(f"[bold #7ee787]▌ Rumbod:[/bold #7ee787] {full}")
                    append_message("assistant", full)
                    break

                self.messages.append({"role": "assistant", "content": text or "", "tool_calls": [{"id": c.id, "type": "function", "function": {"name": c.name, "arguments": json.dumps(c.arguments)}} for c in calls]})
                # Only show tool section header, NOT model text (which may be fabricated preamble)
                chat.write("[dim]│ tools ─────────────────────[/dim]")

                for tc in calls:
                    arg_preview = json.dumps(tc.arguments)[:80]
                    self._agent_status = f"⚡ {tc.name}({arg_preview})"
                    self._update_status_bar()
                    chat.write(f"  [bold #d2a8ff]◇ {tc.name}[/bold #d2a8ff] {arg_preview}")
                    result = await self._execute_tool_call(tc)
                    # Show truncated result
                    result_short = result[:300].replace("\n", " ⏎ ")
                    chat.write(f"  [dim]→ {result_short}[/dim]")
                    self.messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})

                if round_idx < max_tool_rounds - 1:
                    chat.write(f"[dim]│ round {round_idx + 1}/{max_tool_rounds} ────────────────[/dim]")
            else:
                chat.write("[yellow]Max tool rounds reached. Continuing without tools.[/yellow]")

            self._agent_status = "ready"
            self._update_status_bar()
            self.query_one("#msg-input", Input).focus()
        except Exception as e:
            self._agent_status = "error"
            self._update_status_bar()
            chat.write(f"[bold red]Error: {e}[/bold red]")
            import traceback
            chat.write(f"[dim]{traceback.format_exc()[:500]}[/dim]")

    async def _run_subagent(self, task: str, chat: RichLog, config: dict = None):
        """Run a sub-agent with progress indicators."""
        from rumbod_cli.subagent import spawn_agent, SubAgentConfig
        
        chat.write(f"[bold blue]Spawning sub-agent...[/bold blue]")
        chat.write(f"[dim]Task: {task}[/dim]")
        
        if config is None:
            config = SubAgentConfig()
        
        # Show progress indicators
        chat.write(f"[dim]│ Model: {config.model}[/dim]")
        chat.write(f"[dim]│ Max iterations: {config.max_iter}[/dim]")
        chat.write(f"[dim]│ Timeout: {config.timeout}s[/dim]")
        
        if config.tools:
            chat.write(f"[dim]│ Tools: {', '.join(config.tools)}[/dim]")
        
        chat.write(f"[dim]│ Starting execution...[/dim]")
        
        try:
            result = await spawn_agent(task, config)
            
            if result.success:
                chat.write(f"[bold green]✓ Sub-agent completed successfully![/bold green]")
                chat.write(f"[dim]│ Iterations: {result.iterations}[/dim]")
                chat.write(f"[dim]│ Summary: {result.summary}[/dim]")
                if result.history:
                    chat.write(f"[dim]│ Steps performed: {len(result.history)}[/dim]")
            else:
                chat.write(f"[bold red]✗ Sub-agent failed[/bold red]")
                chat.write(f"[dim]│ Error: {result.error}[/dim]")
                chat.write(f"[dim]│ Iterations: {result.iterations}[/dim]")
            
            chat.write(f"[dim]│ Execution finished[/dim]")
            
        except Exception as e:
            chat.write(f"[bold red]✗ Sub-agent execution error: {e}[/bold red]")
            import traceback
            chat.write(f"[dim]{traceback.format_exc()[:500]}[/dim]")

    async def _run_web_search(self, query: str, chat: RichLog):
        """Run web search with progress indicators."""
        from rumbod_cli.tools.websearch import web_search
        
        chat.write(f"[bold blue]Searching web...[/bold blue]")
        chat.write(f"[dim]Query: {query}[/dim]")
        
        try:
            result = await web_search(query)
            chat.write(f"[bold green]✓ Web search completed![/bold green]")
            chat.write(f"[dim]│ Results: {len(result) if isinstance(result, list) else 'N/A'}[/dim]")
        except Exception as e:
            chat.write(f"[bold red]✗ Web search error: {e}[/bold red]")
            import traceback
            chat.write(f"[dim]{traceback.format_exc()[:500]}[/dim]")


def run_interactive():
    from rumbod_cli.hooks import engine
    engine.start()
    app = RumbodInteractive()
    app.run()