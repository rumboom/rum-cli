"""rumbod-cli: Kiro-inspired agent CLI with NVIDIA-first routing."""

__version__ = "0.1.0"