from pathlib import Path
from dataclasses import dataclass, field
import os
import subprocess
from rumbod_cli.constants import RUM_HOME, RUM_KB_PATH

KB_PATH = RUM_KB_PATH

_IGNORE = {".git", "__pycache__", "node_modules", "venv", ".venv", ".rumbod"}


def _walk(root: Path, max_dirs: int = 2000) -> list[Path]:
    """Fast directory walk that skips ignored dirs. Stops at max_dirs."""
    out: list[Path] = []
    try:
        for ent in os.scandir(root):
            if len(out) > max_dirs:
                break
            try:
                if ent.is_dir(follow_symlinks=False):
                    if ent.name not in _IGNORE:
                        out.append(Path(ent.path))
                        out.extend(_walk(Path(ent.path), max_dirs - len(out)))
                else:
                    out.append(Path(ent.path))
            except OSError:
                continue
    except PermissionError:
        pass
    return out


@dataclass
class ProjectContext:
    root: Path
    languages: list[str] = field(default_factory=list)
    key_files: list[str] = field(default_factory=list)
    git_status: str = ""
    git_diff: str = ""
    recent_commits: list[str] = field(default_factory=list)
    tree: str = ""


def scan_project(root: Path) -> ProjectContext:
    ctx = ProjectContext(root=root)
    # languages — scan first-level files only for speed
    seen_exts: set[str] = set()
    _LANG_EXTS = {"py", "rs", "go", "js", "ts", "java", "kt", "cpp", "c", "h"}
    try:
        for ent in os.scandir(root):
            if ent.is_file(follow_symlinks=False):
                ext = Path(ent.name).suffix.lstrip(".")
                if ext in _LANG_EXTS:
                    seen_exts.add(ext)
            elif ent.is_dir(follow_symlinks=False) and ent.name not in _IGNORE:
                try:
                    for sub in os.scandir(ent.path):
                        if sub.is_file(follow_symlinks=False):
                            ext = Path(sub.name).suffix.lstrip(".")
                            if ext in _LANG_EXTS:
                                seen_exts.add(ext)
                    if len(seen_exts) == len(_LANG_EXTS):
                        break
                except OSError:
                    continue
    except OSError:
        pass
    ctx.languages = sorted(seen_exts)
    # key files
    for f in ["pyproject.toml", "Cargo.toml", "go.mod", "package.json", "pom.xml", "build.gradle", "README.md", "README.rst"]:
        if (root / f).exists():
            ctx.key_files.append(f)
    # git
    try:
        ctx.git_status = subprocess.run(["git", "status", "--short"], cwd=root, capture_output=True, text=True, timeout=3).stdout
        ctx.git_diff = subprocess.run(["git", "diff", "--stat"], cwd=root, capture_output=True, text=True, timeout=3).stdout
        ctx.recent_commits = subprocess.run(["git", "log", "--oneline", "-10"], cwd=root, capture_output=True, text=True, timeout=3).stdout.strip().split("\n")
    except Exception:
        pass
    # tree
    try:
        ctx.tree = subprocess.run(["tree", "-L", "2", "-I", ".git|__pycache__|node_modules|venv|.venv|.rumbod|*.pyc"], cwd=root, capture_output=True, text=True, timeout=3).stdout
    except Exception:
        pass
    if not ctx.tree:
        all_files = _walk(root, max_dirs=500)
        ctx.tree = "\n".join(
            str(p.relative_to(root)) for p in all_files
            if not any(x in str(p) for x in _IGNORE)
        )[:1500]
    return ctx

def _load_kb_context() -> str:
    try:
        if not os.path.exists(KB_PATH):
            return ""
        raw = Path(KB_PATH).read_text().strip()
        if not raw:
            return ""
        sections = raw.split("\n## ")[:6]
        summary = sections[0].split("\n")[0].strip("# ")
        cats = []
        for s in sections[1:]:
            h = s.split("\n")[0].strip()
            count = sum(1 for line in s.split("\n") if line.startswith("### "))
            cats.append(f"{h} ({count} entries)")
        return f"Knowledge Base: {summary} | Categories: {', '.join(cats)}\n"
    except Exception:
        return ""

def _discover_skills() -> str:
    """Discover available skills and return as context snippet."""
    from rumbod_cli.constants import RUM_SKILLS
    if not os.path.isdir(RUM_SKILLS):
        return ""
    found = []
    for entry in sorted(os.listdir(RUM_SKILLS)):
        skill_md = os.path.join(RUM_SKILLS, entry, "SKILL.md")
        if os.path.isfile(skill_md):
            desc = ""
            with open(skill_md) as f:
                for line in f:
                    if line.startswith("description:"):
                        desc = line.split(":", 1)[1].strip()
                        break
            found.append(f"{entry}: {desc[:60]}")
    if not found:
        return ""
    return f"Skills available: {' | '.join(found)}\n"

def build_system_prompt(ctx: ProjectContext, mode: str, extras: str = "") -> str:
    from rumbod_cli.constants import RUM_HOME
    kb = _load_kb_context()
    skills = _discover_skills()
    base = f"""You are Rumbod, a senior software engineer and agentic coding assistant.
{kb}{skills}Project: {ctx.root.name}
Languages: {', '.join(ctx.languages) or 'unknown'}
Key files: {', '.join(ctx.key_files) or 'none'}
Git status: {ctx.git_status[:500] or 'clean'}
Recent commits: {'; '.join(ctx.recent_commits[:5]) or 'none'}
Directory tree (truncated):
{ctx.tree[:1500]}

Mode: {mode}
{extras}

You have access to these functions: run_shell, read_file, web_search, web_fetch, write_file, glob_files, git_status, git_diff, run_tests, and 20+ more. Use them when you need to find information.

CRITICAL RULES:
- NEVER fabricate data. NEVER make up file paths, command outputs, CLI tools, or search results.
- If a tool call fails (non-zero exit, error), report the error truthfully. Do NOT invent fake results.
- If you cannot find real data, say "No results found". Do NOT produce simulated markdown tables.
- Run REAL commands only. Do NOT invent tools like "doctor.sh", "ai search", or "claude search".
- Rum home: {RUM_HOME}. This is YOUR data directory. Search there for skills, knowledge, and configuration.
- Use run_shell to execute real commands via subprocess. Every command actually runs on this machine.
- COST AWARENESS: Every API call costs tokens. Prefer single comprehensive searches over many small ones.
- Claude Code stores project data at ~/.claude/projects/ and /root/ECC/. Strategies (FVG, box, EMA/Stoch, POC, session) are Python files in /root/ECC/ named *_strategy.py. To search: run_shell("grep -rni 'fvg' /root/ECC --include='*.py' 2>/dev/null")
"""
    return base
