import typer
import json
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rumbod_cli.config import get_config
from rumbod_cli.context import scan_project, build_system_prompt
from rumbod_cli.memory import (
    load_conversation,
    append_message,
    clear_conversation,
    list_sessions,
)
from rumbod_cli.models import get_provider, NVIDIA_API_KEY, NIM_FREE_MODELS
from rumbod_cli.task_loop import run_task_loop
from rumbod_cli.spec import new_spec, list_specs, approve_spec, verify_spec
from rumbod_cli.apiusage import get_usage_summary, format_usage, reset_usage
from rumbod_cli.apikeys import (
    all_keys, add_key, remove_key, env_key_entry, test_all_keys, reset_keys,
)
from rumbod_cli.providers import (
    all_providers, remove_provider,
    test_all_providers, reset_providers,
)

app = typer.Typer(name="rumbod", help="Kiro-inspired agent CLI")
console = Console()


@app.command()
def chat(
    message: str = typer.Argument(...),
    model: str = typer.Option(None, "-m", "--model"),
    new: bool = typer.Option(False, "--new", help="Start a fresh conversation"),
    session: str = typer.Option(None, "--session", help="Conversation session ID"),
):
    import asyncio
    cfg = get_config()
    provider = get_provider(model or cfg.model.default)
    ctx = scan_project(Path.cwd())
    system_prompt = build_system_prompt(ctx, "cli")
    messages = [{"role": "system", "content": system_prompt}]
    if not new:
        history = load_conversation(session)
        for h in history:
            if h["role"] in ("user", "assistant"):
                messages.append({"role": h["role"], "content": h["content"]})
    messages.append({"role": "user", "content": message})
    append_message("user", message, session)
    resp = asyncio.run(provider.chat(messages))
    append_message("assistant", resp, session)
    console.print(resp)


@app.command()
def task(description: str, spec_id: str = typer.Option(None, "--spec")):
    import asyncio
    history = asyncio.run(run_task_loop(description, spec_id))
    for h in history:
        console.print(json.dumps(h, indent=2))


@app.command()
def spec_new(title: str):
    from rumbod_cli.spec import new_spec
    s = new_spec(title)
    console.print(f"Created spec: {s.id} - {s.title}")


@app.command()
def spec_list():
    table = Table()
    table.add_column("ID")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Updated")
    for s in list_specs():
        table.add_row(s.id, s.title, s.status, s.updated[:10])
    console.print(table)


@app.command()
def spec_approve(spec_id: str):
    spec = approve_spec(spec_id)
    if spec:
        console.print(f"Approved spec: {spec.id} - {spec.title}")
    else:
        console.print(f"Spec not found: {spec_id}")


@app.command()
def spec_verify(spec_id: str):
    spec = verify_spec(spec_id)
    if spec:
        console.print(f"Verified spec: {spec.id} - {spec.title}")
    else:
        console.print(f"Spec not found: {spec_id}")


@app.command()
def doctor():
    console.print(f"[bold cyan]System Check[/bold cyan]")
    console.print(f"  Python: OK")
    
    cfg = get_config()
    console.print(f"  Config: {cfg.model.default}")
    console.print(f"  NIM Key: {'SET' if NVIDIA_API_KEY else 'NOT SET'}")
    if NVIDIA_API_KEY:
        console.print(f"  Key length: {len(NVIDIA_API_KEY)} chars")
    
    import asyncio
    console.print(f"  Testing NIM connectivity...")
    provider = get_provider(cfg.model.default)
    try:
        resp = asyncio.run(provider.chat([{"role": "user", "content": "ping. Reply: pong"}]))
        console.print(f"  NIM Test: {resp[:50]}")
        console.print(f"  [green]✓ All checks passed[/green]")
    except Exception as e:
        console.print(f"  [red]✗ NIM Test FAILED: {e}[/red]")
        console.print(f"  [dim]Check your RUMBOD_NVIDIA_API_KEY environment variable[/dim]")


@app.command()
def init():
    dirs = [".rumbod/specs", ".rumbod/hooks", ".rumbod/steering", ".rumbod/powers", ".rumbod/logs"]
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)
    console.print("Initialized .rumbod/")


@app.command()
def models():
    table = Table()
    table.add_column("Model")
    table.add_column("Context Window")
    for model_id, ctx in NIM_FREE_MODELS.items():
        table.add_row(model_id, f"{ctx:,}")
    console.print(table)


@app.command()
def apiusage(
    reset: bool = typer.Option(False, "--reset", help="Reset the usage counter"),
):
    """Show API token usage across all sessions and sub-agents."""
    if reset:
        reset_usage()
        console.print("[yellow]API usage counter reset.[/yellow]")
        return
    data = get_usage_summary()
    console.print(format_usage(data))


    import asyncio
    if action == "list":
        env = env_key_entry()
        console.print(f"[bold]0[/bold] (env) {env.label} — {env.masked} | working={'yes' if env.working else 'no'}")
        results = asyncio.run(all_keys())
        for i, k in enumerate(results, 1):
            status = "ok" if k.working is True else "untested" if k.working is None else "fail"
            err = f" — {k.error}" if k.error else ""
            console.print(f"[bold]{i}[/bold] {k.label} — {k.masked} | {status}{err}")
    elif action == "add":
        if not value:
            console.print("[red]Usage: rum-cli apikey add <api_key>[/red]")
            return
        try:
            entry = asyncio.run(add_key(value))
            console.print(f"[green]Added key: {entry.label} ({entry.masked})[/green]")
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
    elif action == "remove":
        if not value:
            console.print("[red]Usage: rum-cli apikey remove <index or label>[/red]")
            return
        try:
            idx = int(value) - 1
            if asyncio.run(remove_key(idx)):
                console.print(f"[green]Removed key #{value}[/green]")
            else:
                console.print(f"[red]Invalid index: {value}[/red]")
        except ValueError:
            from rumbod_cli.apikeys import remove_key_by_label
            if asyncio.run(remove_key_by_label(value)):
                console.print(f"[green]Removed key: {value}[/green]")
            else:
                console.print(f"[red]Key not found: {value}[/red]")
    elif action == "test":
        console.print("[bold cyan]Testing all stored API keys...[/bold cyan]")
        results = asyncio.run(test_all_keys())
        for r in results:
            if r["working"]:
                console.print(f"  [bold]{r['label']}[/bold] [green]✓ Working[/green]")
            else:
                console.print(f"  [bold]{r['label']}[/bold] [red]✗ {r['error']}[/red]")
    elif action == "reset":
        asyncio.run(reset_keys())
        console.print("[yellow]All stored keys cleared.[/yellow]")
    else:
        console.print("[yellow]Actions: list, add <key>, remove <id|label>, test, reset[/yellow]")


@app.command()
def provider(
    action: str = typer.Argument("list", help="list / add / remove / set-main / set-sub / test / reset"),
    model: str = typer.Argument(None, help="Model name (for add/set-main/set-sub)"),
    api_key_ref: str = typer.Option("env", "--key", "-k", help="API key ref: env or key:N"),
    role: str = typer.Option("both", "--role", "-r", help="Role: main, subagent, both"),
):
    """Manage provider configurations for main and sub-agent roles."""
    import asyncio
    from rumbod_cli.providers import add_provider as _add, get_providers_for_role

    if action == "list":
        provs = all_providers()
        env_provs = get_providers_for_role("main")
        sub_provs = get_providers_for_role("subagent")
        console.print(f"[bold]Providers configured:[/bold] {len(provs)}")
        console.print(f"  [dim]Main agent: {len(env_provs)} providers[/dim]")
        console.print(f"  [dim]Sub-agent: {len(sub_provs)} providers[/dim]")
        if provs:
            console.print("")
            for i, p in enumerate(provs):
                status = "ok" if p.working is True else "untested" if p.working is None else "fail"
                err = f" — {p.error}" if p.error else ""
                console.print(f"  [bold]{i}[/bold] model={p.model} key={p.api_key_ref} role={p.role} [{status}]{err}")
        console.print("")
        console.print("[dim]Available models:[/dim]")
        for m, ctx in NIM_FREE_MODELS.items():
            console.print(f"  {m} ({ctx:,} ctx)")
    elif action == "add":
        if not model:
            console.print("[red]Usage: rum-cli provider add <model> [--key env|key:N] [--role main|subagent|both][/red]")
            return
        try:
            entry = _add(model, api_key_ref, role)
            console.print(f"[green]Added provider: {entry.label}[/green]")
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
    elif action == "remove":
        if model is None:
            console.print("[red]Usage: rum-cli provider remove <index>[/red]")
            return
        try:
            idx = int(model)
            if remove_provider(idx):
                console.print(f"[green]Removed provider #{model}[/green]")
            else:
                console.print(f"[red]Invalid index: {model}[/red]")
        except ValueError:
            console.print("[red]Index must be a number.[/red]")
    elif action == "set-main":
        if not model:
            console.print("[red]Usage: rum-cli provider set-main <model>[/red]")
            return
        try:
            entry = _add(model, api_key_ref, "main")
            console.print(f"[green]Main agent provider: {entry.label}[/green]")
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
    elif action == "set-sub":
        if not model:
            console.print("[red]Usage: rum-cli provider set-sub <model>[/red]")
            return
        try:
            entry = _add(model, api_key_ref, "subagent")
            console.print(f"[green]Sub-agent provider: {entry.label}[/green]")
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
    elif action == "test":
        provs = all_providers()
        if not provs:
            console.print("[yellow]No providers to test.[/yellow]")
            return
        console.print("[bold cyan]Testing all providers...[/bold cyan]")
        results = asyncio.run(test_all_providers())
        for r in results:
            if r["working"]:
                console.print(f"  [bold]{r['label']}[/bold] [green]✓ Working[/green]")
            else:
                console.print(f"  [bold]{r['label']}[/bold] [red]✗ {r['error']}[/red]")
    elif action == "reset":
        reset_providers()
        console.print("[yellow]All provider configurations cleared.[/yellow]")
    else:
        console.print("[yellow]Actions: list, add, remove, set-main, set-sub, test, reset[/yellow]")


@app.command()
def spawn(
    task_description: str = typer.Argument(..., help="Task for the sub-agent"),
    model: str = typer.Option(None, "-m", "--model", help="Model for sub-agent"),
    max_iter: int = typer.Option(10, "--max-iter", help="Max iterations"),
):
    """Spawn a sub-agent to work on a task."""
    import asyncio
    from rumbod_cli.subagent import SubAgentConfig, spawn_agent

    console.print(f"[bold cyan]Spawning sub-agent...[/bold cyan]")
    console.print(f"  Task: {task_description[:100]}{'...' if len(task_description) > 100 else ''}")
    console.print(f"  Model: {model or 'auto'}")
    console.print(f"  Max iterations: {max_iter}")
    console.print()
    
    cfg_config = SubAgentConfig(
        model=model or "auto",
        max_iter=max_iter,
        on_step=lambda s, e: console.print(f"    [dim]Step {s['step']}: {s['tool']} → {str(s['result'])[:80]}[/dim]"),
    )
    
    console.print(f"[dim]Starting execution...[/dim]")
    result = asyncio.run(spawn_agent(task_description, cfg_config))
    
    if result.success:
        console.print(f"[bold green]✓ Sub-agent complete[/bold green]")
        console.print(f"  Iterations: {result.iterations}")
        console.print(f"  Summary: {result.summary[:500]}")
        if result.history:
            console.print(f"  Steps performed: {len(result.history)}")
    else:
        console.print(f"[bold red]✗ Sub-agent failed[/bold red]")
        console.print(f"  Error: {result.error}")
        console.print(f"  Iterations: {result.iterations}")


@app.command()
def interactive():
    """Launch the interactive TUI mode with slash commands."""
    from rumbod_cli.interactive import run_interactive
    run_interactive()


@app.command()
def conversation(
    action: str = typer.Argument("list", help="list / show / clear"),
    session: str = typer.Option(None, "--session", help="Session ID"),
):
    if action == "list":
        sessions = list_sessions()
        if not sessions:
            console.print("[dim]No conversations found.[/dim]")
            return
        table = Table()
        table.add_column("Session")
        table.add_column("Messages")
        table.add_column("Last Updated")
        for s in sessions:
            table.add_row(s["id"], str(s["messages"]), s["updated"][:19])
        console.print(table)
    elif action == "clear":
        clear_conversation(session)
        console.print(f"[yellow]Cleared conversation: {session or '(project default)'}[/yellow]")
    elif action == "show":
        history = load_conversation(session)
        if not history:
            console.print("[dim]No messages.[/dim]")
            return
        for h in history[-20:]:
            label = f"[bold cyan]{h['role']}:[/bold cyan]"
            text = h["content"][:200]
            console.print(f"{label} {text}")
    else:
        console.print(f"[red]Unknown action: {action}. Use list/show/clear[/red]")


if __name__ == "__main__":
    from rumbod_cli.hooks import engine
    engine.start()
    app()