import asyncio
import json
from pathlib import Path
from rumbod_cli.context import scan_project, build_system_prompt
from rumbod_cli.tools.shell import run_shell
from rumbod_cli.tools.git import git_status, git_diff
from rumbod_cli.tools.tests import run_tests
from rumbod_cli.tools.websearch import web_search, web_fetch
from rumbod_cli.tools.filesystem import read_file, write_file, list_files, glob_files
from rumbod_cli.tools.file import (
    read_json_file,
    write_json_file,
    find_files,
    get_file_info,
    copy_file,
    move_file,
    delete_file,
    create_directory,
    list_directory,
    search_text_in_files,
)
from rumbod_cli.tools.process import (
    run_process,
    list_processes,
    get_process_info,
    kill_process,
    monitor_process,
    run_script,
    check_port,
    get_system_info,
)
from rumbod_cli.tools.network import (
    check_host,
    ping_host,
    resolve_dns,
    http_request,
    https_check,
    port_scan,
    get_ip_info,
    test_connectivity,
)

TOOLS = {
    # Original tools
    "shell": {"fn": run_shell, "desc": "Run shell command"},
    "git_status": {"fn": git_status, "desc": "Git status"},
    "git_diff": {"fn": git_diff, "desc": "Git diff"},
    "run_tests": {"fn": run_tests, "desc": "Run test suite"},
    "web_search": {"fn": web_search, "desc": "Web search"},
    "web_fetch": {"fn": web_fetch, "desc": "Fetch and read a URL"},
    "read_file": {"fn": read_file, "desc": "Read file"},
    "write_file": {"fn": write_file, "desc": "Write file"},
    "list_files": {"fn": list_files, "desc": "List files"},
    "glob_files": {"fn": glob_files, "desc": "Glob files"},
    # New file tools
    "read_json_file": {"fn": read_json_file, "desc": "Read JSON file"},
    "write_json_file": {"fn": write_json_file, "desc": "Write JSON file"},
    "find_files": {"fn": find_files, "desc": "Find files matching pattern"},
    "get_file_info": {"fn": get_file_info, "desc": "Get file information"},
    "copy_file": {"fn": copy_file, "desc": "Copy file"},
    "move_file": {"fn": move_file, "desc": "Move file"},
    "delete_file": {"fn": delete_file, "desc": "Delete file"},
    "create_directory": {"fn": create_directory, "desc": "Create directory"},
    "list_directory": {"fn": list_directory, "desc": "List directory contents"},
    "search_text_in_files": {"fn": search_text_in_files, "desc": "Search text in files"},
    # New process tools
    "run_process": {"fn": run_process, "desc": "Run process with timeout"},
    "list_processes": {"fn": list_processes, "desc": "List running processes"},
    "get_process_info": {"fn": get_process_info, "desc": "Get process information"},
    "kill_process": {"fn": kill_process, "desc": "Kill process"},
    "monitor_process": {"fn": monitor_process, "desc": "Monitor process in real-time"},
    "run_script": {"fn": run_script, "desc": "Run Python script"},
    "check_port": {"fn": check_port, "desc": "Check if port is in use"},
    "get_system_info": {"fn": get_system_info, "desc": "Get system information"},
    # New network tools
    "check_host": {"fn": check_host, "desc": "Check if host is reachable"},
    "ping_host": {"fn": ping_host, "desc": "Ping host"},
    "resolve_dns": {"fn": resolve_dns, "desc": "Resolve DNS for host"},
    "http_request": {"fn": http_request, "desc": "Make HTTP request"},
    "https_check": {"fn": https_check, "desc": "Check HTTPS URL"},
    "port_scan": {"fn": port_scan, "desc": "Scan ports on host"},
    "get_ip_info": {"fn": get_ip_info, "desc": "Get IP address information"},
    "test_connectivity": {"fn": test_connectivity, "desc": "Test connectivity to host"},
}

async def run_task_loop(task: str, spec_id: str = None, max_iter: int = 20, provider=None):
    ctx = scan_project(Path.cwd())
    if provider is None:
        from rumbod_cli.models import get_provider
        provider = get_provider("auto")
    history = []
    system = build_system_prompt(ctx, "task")
    if spec_id:
        from rumbod_cli.spec import get_spec
        sp = get_spec(spec_id)
        if sp:
            system += f"\n\nActive Spec: {sp.title}\n{sp.content}"

    cancel_event: asyncio.Event | None = None
    for i in range(max_iter):
        if cancel_event and cancel_event.is_set():
            break
        # PLAN
        plan_prompt = system + f"\n\nTask: {task}\nHistory: {json.dumps(history[-3:])}\n\nReturn JSON plan: [{{\"step\": 1, \"tool\": \"tool_name\", \"args\": {{}}, \"expected\": \"...\"}}]"
        try:
            plan_text = await asyncio.wait_for(
                provider.chat([{"role": "system", "content": system}, {"role": "user", "content": plan_prompt}]),
                timeout=60,
            )
        except (asyncio.TimeoutError, Exception) as e:
            history.append({"error": f"plan chat failed: {e}"})
            continue
        try:
            plan = json.loads(plan_text)
            if isinstance(plan, dict):
                plan = [plan]
            if not isinstance(plan, list):
                raise ValueError("plan is not a list")
        except Exception:
            plan = [{"step": 1, "tool": "shell", "args": {"cmd": "echo 'parsing failed'"}, "expected": "fallback"}]

        for step in plan:
            if not isinstance(step, dict):
                continue
            tool_name = step.get("tool", "")
            args = step.get("args", {})
            if tool_name in TOOLS:
                try:
                    result = await asyncio.wait_for(TOOLS[tool_name]["fn"](**args), timeout=120)
                    history.append({"step": step, "result": str(result)[:2000]})
                except (asyncio.TimeoutError, Exception) as e:
                    history.append({"step": step, "error": str(e)})
                if step.get("done"):
                    return history
    return history
# Parallel processing support
async def run_parallel_tasks(tasks: list[dict], max_concurrent: int = None):
    """Run multiple tasks in parallel."""
    if not PARALLEL_CONFIG["enabled"]:
        # Run tasks sequentially if parallel processing is disabled
        results = []
        for task in tasks:
            try:
                result = await asyncio.wait_for(
                    TOOLS[task["tool"]]["fn"](**task["args"]),
                    timeout=PARALLEL_CONFIG["task_timeout"],
                )
                results.append({"step": task["step"], "result": result})
            except Exception as e:
                results.append({"step": task["step"], "error": str(e)})
        return results
    
    # Run tasks in parallel
    semaphore = asyncio.Semaphore(max_concurrent or PARALLEL_CONFIG["max_concurrent_tasks"])
    
    async def run_task_with_semaphore(task):
        async with semaphore:
            try:
                result = await asyncio.wait_for(
                    TOOLS[task["tool"]]["fn"](**task["args"]),
                    timeout=PARALLEL_CONFIG["task_timeout"],
                )
                return {"step": task["step"], "result": result}
            except Exception as e:
                if PARALLEL_CONFIG["retry_on_failure"]:
                    # Retry failed tasks
                    for retry in range(PARALLEL_CONFIG["retry_count"]):
                        try:
                            result = await asyncio.wait_for(
                                TOOLS[task["tool"]]["fn"](**task["args"]),
                                timeout=PARALLEL_CONFIG["task_timeout"],
                            )
                            return {"step": task["step"], "result": result}
                        except Exception:
                            continue
                return {"step": task["step"], "error": str(e)}
    
    # Create tasks
    task_objects = [run_task_with_semaphore(task) for task in tasks]
    
    # Run tasks in parallel
    results = await asyncio.gather(*task_objects, return_exceptions=True)
    
    # Process results
    processed_results = []
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            processed_results.append({"step": tasks[i]["step"], "error": str(result)})
        else:
            processed_results.append(result)
    
    return processed_results

# Configuration for parallel processing
PARALLEL_CONFIG = {
    "enabled": True,
    "max_concurrent_tasks": 5,
    "task_timeout": 60,
    "retry_on_failure": True,
    "retry_count": 3,
}