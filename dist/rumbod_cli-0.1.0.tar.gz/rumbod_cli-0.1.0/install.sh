#!/usr/bin/env bash
# rumbod-cli — one-liner install
# Usage: curl -sL https://rumbod.dev/install.sh | bash
# Or:    wget -qO- https://rumbod.dev/install.sh | bash
set -euo pipefail

RUM_VERSION="0.1.0"
REPO="rumbod-cli"

echo ""
echo "  ╭─────────────────────────────────────╮"
echo "  │        rumbod-cli installer         │"
echo "  ╰─────────────────────────────────────╯"
echo ""

# ── Detect OS ──
OS="$(uname -s)"
ARCH="$(uname -m)"
case "$OS" in
    Linux)  OS="linux" ;;
    Darwin) OS="macos" ;;
    *)      echo "✗ Unsupported OS: $OS"; exit 1 ;;
esac

# ── Ensure curl/wget ──
HAS_CURL=0; HAS_WGET=0
command -v curl &>/dev/null && HAS_CURL=1
command -v wget &>/dev/null && HAS_WGET=1
if [ "$HAS_CURL" = 0 ] && [ "$HAS_WGET" = 0 ]; then
    echo "✗ Need curl or wget. Install one and retry."
    exit 1
fi

# ── Ensure uv ──
if ! command -v uv &>/dev/null; then
    echo "→ Installing uv package manager..."
    if [ "$HAS_CURL" = 1 ]; then
        curl -LsSf https://astral.sh/uv/install.sh | sh
    else
        wget -qO- https://astral.sh/uv/install.sh | sh
    fi
    export PATH="$HOME/.local/bin:$PATH"
fi

# ── Install from PyPI or GitHub ──
echo "→ Installing rumbod-cli..."
pip install rumbod-cli --break-system-packages -q 2>/dev/null || \
uv tool install --force rumbod-cli 2>/dev/null || {
    # Fallback: install from GitHub release
    TMPDIR="$(mktemp -d)"
    cd "$TMPDIR"
    if [ "$HAS_CURL" = 1 ]; then
        curl -sL "https://github.com/anomalyco/rumbod-cli/archive/refs/heads/main.tar.gz" -o repo.tar.gz
    else
        wget -qO repo.tar.gz "https://github.com/anomalyco/rumbod-cli/archive/refs/heads/main.tar.gz"
    fi
    tar xzf repo.tar.gz
    cd rumbod-cli-*
    uv tool install --force . 2>/dev/null || pip install . --break-system-packages
    cd / && rm -rf "$TMPDIR"
}

# ── Create ~/.rum/ ──
mkdir -p ~/.rum/{skills,agent-monitor,ponytail,hooks,steering,logs,sessions}
touch ~/.rum/knowledge-base.md 2>/dev/null || true

# ── Interactive API key setup ──
if [ -z "${RUMBOD_NVIDIA_API_KEY:-}" ] && [ -z "${RUMBOD_OPENAI_API_KEY:-}" ] && [ -z "${RUMBOD_ANTHROPIC_API_KEY:-}" ]; then
    echo ""
    echo "→ API Key Setup (one-time — press Enter to skip any)"
    echo ""
    read -rp "  NVIDIA NIM API Key: " nk
    [ -n "$nk" ] && echo "export RUMBOD_NVIDIA_API_KEY='$nk'" >> ~/.bashrc && export RUMBOD_NVIDIA_API_KEY="$nk"
    read -rp "  OpenAI API Key: " ok
    [ -n "$ok" ] && echo "export RUMBOD_OPENAI_API_KEY='$ok'" >> ~/.bashrc && export RUMBOD_OPENAI_API_KEY="$ok"
    read -rp "  Anthropic API Key: " ak
    [ -n "$ak" ] && echo "export RUMBOD_ANTHROPIC_API_KEY='$ak'" >> ~/.bashrc && export RUMBOD_ANTHROPIC_API_KEY="$ak"
    echo ""
fi

# ── Verify ──
echo "→ Verifying..."
if command -v rum-interactive-cli &>/dev/null; then
    echo "  ✓ rum-interactive-cli ready"
else
    echo "  ⚠ Not in PATH. Run: source ~/.bashrc"
fi

echo ""
echo "  ╭─────────────────────────────────────╮"
echo "  │  Done!                              │"
echo "  │                                     │"
echo "  │  rum-interactive-cli                │"
echo "  │  rum-cli chat 'hello'               │"
echo "  │  rum-cli apikey add nvapi-...       │"
echo "  ╰─────────────────────────────────────╯"
echo ""
